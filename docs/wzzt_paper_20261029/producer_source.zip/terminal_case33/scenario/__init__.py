"""Scenario construction and validation."""

