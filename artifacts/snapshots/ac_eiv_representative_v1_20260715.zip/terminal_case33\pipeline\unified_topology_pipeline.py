"""Unified FFT, hierarchy, GTLS, AC, and quartet topology identification.

The pipeline keeps estimator roles separate. FFT preprocessing and perturbation
tests propose stable rooted clades, one-layer aggregation improves the backbone
fit, GTLS expands and scores the finite RNJ candidate set, held-out AC power
flow ranks physical candidates, and quartet tests validate individual hidden
splits. Correlated scores are combined by explicit gates, not by multiplying
them as if they were independent probabilities.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np

from terminal_case33.graph.quartet_significance import (
    QuartetCladeEvidence,
    bootstrap_quartet_significance,
)
from terminal_case33.graph.rooted_hierarchy import rooted_tree_from_clades
from terminal_case33.models.network import TerminalizedNetwork
from terminal_case33.pipeline.ac_likelihood import (
    representative_validation_count,
    split_representative_scenarios,
)
from terminal_case33.pipeline.rnj_candidates import RNJCandidate
from terminal_case33.pipeline.fft_aggregation_selection import hierarchy_gate_passes
from terminal_case33.pipeline.fft_rnj_hierarchy import (
    FrequencySelection,
    FullPipelineResult,
    run_fft_rnj_hierarchy,
)
from terminal_case33.pipeline.gtls_topology_posterior import (
    GTLSTopologyPosterior,
    infer_gtls_topology_posterior,
)
from terminal_case33.pipeline.topology_validation import (
    ValidatedTopologyResult,
    select_and_validate_topology,
)


Clade = frozenset[int]


@dataclass(frozen=True)
class UnifiedTopologyConfig:
    """Label-free thresholds for the unified noisy-measurement pipeline."""

    validation_scenario_count: int | None = None
    gtls_validation_scenario_count: int = 1
    quartet_replicates: int = 20
    quartet_confidence: float = 0.90
    quartet_positive_support: float = 0.80
    quartet_minimum_effect: float = 0.002
    aggregation_bootstrap_replicates: int = 6
    gtls_shrinkage_to_ols: float = 0.99
    gtls_temporal_block_length: int = 12
    gtls_posterior_temperature: float = 1.0
    gtls_map_probability_threshold: float = 0.50
    fft_harmonic_candidates: tuple[int, ...] | None = None
    distance_mode: str = "RX_75R_25X"
    rnj_tolerance_factor: float = 0.16
    fft_clade_confirmation_threshold: float = 0.80
    gtls_clade_confirmation_threshold: float = 0.50
    aggregation_max_cluster_size: int = 5
    aggregation_deembedding_weight: float = 0.15
    aggregation_local_tolerance_factor: float = 0.40
    aggregation_block_fraction: float = 0.70
    quartet_contradiction_effect: float = 0.05
    minimum_clade_confidence: float = 0.85
    minimum_frequency_stability: float = 0.90
    minimum_fit_r2: float = 0.80
    maximum_condition_number: float = 1e5
    stable_base_minimum_clade_confidence: float = 0.99
    stable_base_minimum_frequency_stability: float = 0.99
    stable_base_minimum_fit_r2: float = 0.90
    stable_base_maximum_condition_number: float = 1e4


@dataclass(frozen=True)
class UnifiedCladeEvidence:
    """Auditable multi-method evidence for one rooted terminal clade."""

    clade: Clade
    gtls_marginal: float
    fft_stability: float
    quartet_estimate: float
    quartet_lower_bound: float
    quartet_upper_bound: float
    quartet_positive_support: float
    quartet_accepted: bool
    in_ac_raw: bool
    in_ac_validated: bool
    in_gtls_map: bool
    in_fft_base: bool
    in_fft_final: bool
    source_support_count: int
    diagnostic_support_score: float
    materially_contradicted: bool
    stable_for_aggregation: bool

    def to_dict(self) -> dict:
        """Return a JSON-serializable evidence record."""

        record = asdict(self)
        record["clade"] = sorted(self.clade)
        return record


@dataclass(frozen=True)
class UnifiedTopologyResult:
    """Final clades plus every branch needed to audit the decision."""

    final_clades: frozenset[Clade]
    pre_quartet_clades: frozenset[Clade]
    selection_source: str
    ac_validated: ValidatedTopologyResult
    gtls_posterior: GTLSTopologyPosterior
    hierarchy: FullPipelineResult
    clade_evidence: dict[Clade, UnifiedCladeEvidence]
    proposed_aggregation_clades: frozenset[Clade]
    stable_aggregation_clades: frozenset[Clade]
    applied_aggregation_clades: frozenset[Clade]
    rejected_aggregation_reasons: dict[int, tuple[str, ...]]
    aggregation_rerun: bool
    fft_aggregation_trusted: bool
    fft_base_trusted: bool
    gtls_map_trusted: bool
    mean_fft_clade_confidence: float
    selected_frequency_stability: float
    selected_frequency_admissible: bool

    def summary(self) -> dict:
        """Return compact JSON-compatible selection diagnostics."""

        return {
            "selection_source": self.selection_source,
            "final_clades": [
                sorted(clade) for clade in sorted_clades(self.final_clades)
            ],
            "pre_quartet_clades": [
                sorted(clade) for clade in sorted_clades(self.pre_quartet_clades)
            ],
            "proposed_aggregation_clades": [
                sorted(clade)
                for clade in sorted_clades(self.proposed_aggregation_clades)
            ],
            "stable_aggregation_clades": [
                sorted(clade)
                for clade in sorted_clades(self.stable_aggregation_clades)
            ],
            "applied_aggregation_clades": [
                sorted(clade)
                for clade in sorted_clades(self.applied_aggregation_clades)
            ],
            "aggregation_rerun": self.aggregation_rerun,
            "hierarchy_aggregation_accepted": (
                self.hierarchy.aggregation_accepted
            ),
            "fft_aggregation_trusted": self.fft_aggregation_trusted,
            "fft_base_trusted": self.fft_base_trusted,
            "gtls_map_trusted": self.gtls_map_trusted,
            "mean_fft_clade_confidence": self.mean_fft_clade_confidence,
            "selected_frequency_stability": self.selected_frequency_stability,
            "selected_frequency_admissible": self.selected_frequency_admissible,
            "gtls_map_probability": (
                self.gtls_posterior.selected.posterior_probability
            ),
            "ac_training_scenario_count": (
                self.ac_validated.ac_rerank.training_scenario_count
            ),
            "ac_validation_scenario_count": (
                self.ac_validated.ac_rerank.validation_scenario_count
            ),
            "ac_refinement_accepted": (
                self.ac_validated.ac_rerank.selected.edge_fit.ac_refinement_accepted
            ),
            "ac_training_rmse_before": (
                self.ac_validated.ac_rerank.selected.edge_fit.training_ac_rmse_before
            ),
            "ac_training_rmse_after": (
                self.ac_validated.ac_rerank.selected.edge_fit.training_ac_rmse_after
            ),
            "ac_predictive_nll": (
                self.ac_validated.ac_rerank.selected.standardized_negative_log_likelihood
            ),
            "rejected_aggregation_reasons": {
                str(key): list(value)
                for key, value in self.rejected_aggregation_reasons.items()
            },
        }


def sorted_clades(clades: set[Clade] | frozenset[Clade]) -> list[Clade]:
    """Return clades in deterministic size and node order."""

    return sorted(clades, key=lambda value: (len(value), tuple(sorted(value))))


def _finite_or_zero(value: float) -> float:
    """Return a finite scalar or zero."""

    return float(value) if np.isfinite(value) else 0.0


def build_clade_evidence(
    clades: set[Clade],
    *,
    ac_raw_clades: set[Clade],
    ac_validated_clades: set[Clade],
    gtls_map_clades: set[Clade],
    gtls_marginals: dict[Clade, float],
    fft_base_clades: set[Clade],
    fft_final_clades: set[Clade],
    fft_stability: dict[Clade, float],
    quartet_evidence: dict[Clade, QuartetCladeEvidence],
    fft_confirmation_threshold: float = 0.80,
    gtls_confirmation_threshold: float = 0.50,
    quartet_contradiction_effect: float = 0.05,
) -> dict[Clade, UnifiedCladeEvidence]:
    """Fuse clade diagnostics without pretending they are independent.

    The diagnostic support score is only a sortable summary. The aggregation
    decision uses explicit rules: FFT stability, at least one confirmation from
    GTLS/AC/quartets, and no materially negative quartet upper bound.
    """

    if not 0.0 <= fft_confirmation_threshold <= 1.0:
        raise ValueError("fft_confirmation_threshold must be in [0, 1]")
    if not 0.0 <= gtls_confirmation_threshold <= 1.0:
        raise ValueError("gtls_confirmation_threshold must be in [0, 1]")
    if quartet_contradiction_effect < 0.0:
        raise ValueError("quartet_contradiction_effect must be nonnegative")

    fused: dict[Clade, UnifiedCladeEvidence] = {}
    for clade in sorted_clades(clades):
        quartet = quartet_evidence.get(clade)
        gtls = float(np.clip(gtls_marginals.get(clade, 0.0), 0.0, 1.0))
        fft = float(np.clip(fft_stability.get(clade, 0.0), 0.0, 1.0))
        q_estimate = _finite_or_zero(quartet.estimate) if quartet else 0.0
        q_lower = (
            _finite_or_zero(quartet.lower_confidence_bound) if quartet else 0.0
        )
        q_upper = (
            _finite_or_zero(quartet.upper_confidence_bound) if quartet else 0.0
        )
        q_support = (
            float(np.clip(quartet.positive_support, 0.0, 1.0))
            if quartet is not None
            else 0.0
        )
        q_accepted = bool(quartet is not None and quartet.accepted)
        contradicted = bool(
            quartet is not None
            and np.isfinite(quartet.upper_confidence_bound)
            and quartet.upper_confidence_bound < -quartet_contradiction_effect
        )
        ac_raw = clade in ac_raw_clades
        ac_validated = clade in ac_validated_clades
        fft_confirmed = fft >= fft_confirmation_threshold
        gtls_confirmed = gtls >= gtls_confirmation_threshold
        source_count = sum(
            (
                fft_confirmed,
                gtls_confirmed,
                ac_validated,
                q_accepted,
            )
        )
        ac_score = 1.0 if ac_validated else 0.5 if ac_raw else 0.0
        support_score = (
            0.35 * fft
            + 0.30 * gtls
            + 0.20 * q_support
            + 0.15 * ac_score
        )
        fused[clade] = UnifiedCladeEvidence(
            clade=clade,
            gtls_marginal=gtls,
            fft_stability=fft,
            quartet_estimate=q_estimate,
            quartet_lower_bound=q_lower,
            quartet_upper_bound=q_upper,
            quartet_positive_support=q_support,
            quartet_accepted=q_accepted,
            in_ac_raw=ac_raw,
            in_ac_validated=ac_validated,
            in_gtls_map=clade in gtls_map_clades,
            in_fft_base=clade in fft_base_clades,
            in_fft_final=clade in fft_final_clades,
            source_support_count=int(source_count),
            diagnostic_support_score=float(support_score),
            materially_contradicted=contradicted,
            stable_for_aggregation=bool(
                fft_confirmed and source_count >= 2 and not contradicted
            ),
        )
    return fused


def _selected_frequency(hierarchy: FullPipelineResult) -> FrequencySelection:
    """Return the diagnostics for the selected FFT harmonic."""

    harmonic = int(hierarchy.selected_recipe["hi"])
    matches = [
        candidate
        for candidate in hierarchy.frequency_candidates
        if candidate.max_harmonic == harmonic
    ]
    if not matches:
        raise RuntimeError("selected FFT harmonic is missing from diagnostics")
    return matches[0]


def _candidate_clade_union(
    posterior: GTLSTopologyPosterior,
    hierarchy: FullPipelineResult,
) -> set[Clade]:
    """Collect every hidden split proposed before quartet validation."""

    clades: set[Clade] = set(hierarchy.base_clades) | set(hierarchy.final_clades)
    for score in posterior.ranked:
        clades.update(score.projection.candidate.clades)
    for cluster in hierarchy.proposed_clusters:
        clades.add(cluster.members)
        clades.update(cluster.frozen_clades)
    for local in hierarchy.local_clades.values():
        clades.update(local)
    terminal_count = len(hierarchy.terminals)
    return {clade for clade in clades if 1 < len(clade) < terminal_count}


def _confirmed_clusters(
    hierarchy: FullPipelineResult,
    evidence: dict[Clade, UnifiedCladeEvidence],
) -> tuple[set[Clade], dict[int, tuple[str, ...]]]:
    """Confirm every structural clade frozen inside each proposed cluster."""

    accepted: set[Clade] = set()
    rejected: dict[int, tuple[str, ...]] = {}
    for cluster in hierarchy.proposed_clusters:
        required = {cluster.members, *cluster.frozen_clades}
        reasons = []
        for clade in sorted_clades(required):
            record = evidence.get(clade)
            label = "{" + ",".join(str(node) for node in sorted(clade)) + "}"
            if record is None:
                reasons.append(f"{label}: no fused evidence")
            elif record.materially_contradicted:
                reasons.append(f"{label}: quartet contradiction")
            elif not record.stable_for_aggregation:
                reasons.append(
                    f"{label}: only {record.source_support_count} confirming source(s)"
                )
        if reasons:
            rejected[cluster.pseudo_id] = tuple(reasons)
        else:
            accepted.add(cluster.members)
    return accepted, rejected


def _hierarchy_extra_candidates(
    hierarchy: FullPipelineResult,
    posterior: GTLSTopologyPosterior,
) -> list[RNJCandidate]:
    """Expose GTLS, FFT-base, and gated hierarchy trees to one AC ranker."""

    candidates = [score.projection.candidate for score in posterior.ranked]
    candidates.append(
        RNJCandidate(
            tree=hierarchy.base_tree,
            distance_mode="fft_base",
            tolerance_factor=hierarchy.base_tree.group_tolerance,
            clades=hierarchy.base_clades,
        )
    )
    root_neighbors = {
        int(right) if int(left) == hierarchy.root_bus else int(left)
        for left, right, _weight in hierarchy.base_tree.edges
        if hierarchy.root_bus in {int(left), int(right)}
    }
    include_hidden_root_stem = bool(
        len(root_neighbors) == 1
        and next(iter(root_neighbors)) not in set(hierarchy.terminals)
    )
    hierarchy_tree = rooted_tree_from_clades(
        hierarchy.final_clades,
        hierarchy.terminals,
        hierarchy.root_bus,
        include_hidden_root_stem=include_hidden_root_stem,
    )
    candidates.append(
        RNJCandidate(
            tree=hierarchy_tree,
            distance_mode="fft_aggregation",
            tolerance_factor=0.0,
            clades=hierarchy.final_clades,
        )
    )
    return candidates


def _selected_ac_source(
    selected_clades: set[Clade],
    hierarchy: FullPipelineResult,
    posterior: GTLSTopologyPosterior,
) -> str:
    """Describe which proposal family contains the AC-selected topology."""

    if (
        hierarchy.aggregation_accepted
        and hierarchy.clusters
        and selected_clades == set(hierarchy.final_clades)
    ):
        return "ac_fft_aggregation"
    if selected_clades == set(hierarchy.base_clades):
        return "ac_fft_base"
    if any(
        selected_clades == set(score.projection.candidate.clades)
        for score in posterior.ranked
    ):
        return "ac_gtls_ols_pool"
    return "ac_rnj_grid"


def _no_material_contradictions(
    clades: set[Clade] | frozenset[Clade],
    evidence: dict[Clade, UnifiedCladeEvidence],
) -> bool:
    return not any(
        evidence.get(clade) is not None
        and evidence[clade].materially_contradicted
        for clade in clades
    )


def _validate_config(config: UnifiedTopologyConfig, scenario_count: int) -> None:
    validation_count = (
        representative_validation_count(scenario_count)
        if config.validation_scenario_count is None
        else config.validation_scenario_count
    )
    if not 1 <= validation_count < scenario_count:
        raise ValueError(
            "validation_scenario_count must lie between 1 and len(scenarios)-1"
        )
    if config.quartet_replicates <= 0:
        raise ValueError("quartet_replicates must be positive")
    if not 0.0 < config.quartet_confidence < 1.0:
        raise ValueError("quartet_confidence must be in (0, 1)")
    if not 0.0 <= config.quartet_positive_support <= 1.0:
        raise ValueError("quartet_positive_support must be in [0, 1]")
    if config.quartet_minimum_effect < 0.0:
        raise ValueError("quartet_minimum_effect must be nonnegative")
    training_scenario_count = scenario_count - validation_count
    if not 1 <= config.gtls_validation_scenario_count < training_scenario_count:
        raise ValueError(
            "gtls_validation_scenario_count must leave at least one outer-training scenario"
        )
    if config.aggregation_bootstrap_replicates <= 0:
        raise ValueError("aggregation_bootstrap_replicates must be positive")
    if not 0.0 <= config.gtls_shrinkage_to_ols <= 1.0:
        raise ValueError("gtls_shrinkage_to_ols must be in [0, 1]")
    if not 0.0 <= config.gtls_map_probability_threshold <= 1.0:
        raise ValueError("gtls_map_probability_threshold must be in [0, 1]")
    if config.rnj_tolerance_factor < 0.0:
        raise ValueError("rnj_tolerance_factor must be nonnegative")
    if config.aggregation_max_cluster_size < 2:
        raise ValueError("aggregation_max_cluster_size must be at least two")
    if not 0.0 <= config.aggregation_deembedding_weight <= 1.0:
        raise ValueError("aggregation_deembedding_weight must be in [0, 1]")
    if config.aggregation_local_tolerance_factor < 0.0:
        raise ValueError("aggregation_local_tolerance_factor must be nonnegative")
    if not 0.5 <= config.aggregation_block_fraction < 1.0:
        raise ValueError("aggregation_block_fraction must be in [0.5, 1)")


def identify_topology_unified(
    scenarios: list[dict],
    reference_net: TerminalizedNetwork,
    pq_noise_relative_std: float,
    voltage_noise_relative_std: float,
    config: UnifiedTopologyConfig | None = None,
    seed: int = 0,
) -> UnifiedTopologyResult:
    """Run the unified noisy-AC topology-identification workflow.

    The order is deliberate:

    1. GTLS and adaptive FFT-RNJ independently propose rooted hidden clades.
    2. Block-bootstrap quartet tests and GTLS marginals confirm which stable
       peripheral FFT clusters may be contracted.
    3. The hierarchy is rerun with only confirmed clusters; pseudo P/Q/V are
       never formed for an FFT-only cluster.
    4. Ordered RNJ, GTLS, FFT-base, and aggregated hierarchy trees enter one
       fixed-tree nonnegative R/X and held-out AC-likelihood candidate pool.
    5. Quartet contradictions and near-zero fitted hidden edges contract the
       AC-selected topology. No proposal branch bypasses physical reranking.
    """

    if len(scenarios) < 3:
        raise ValueError(
            "unified topology identification requires at least three scenarios"
        )
    selected_config = config or UnifiedTopologyConfig()
    _validate_config(selected_config, len(scenarios))
    training, validation, _validation_indices = split_representative_scenarios(
        scenarios,
        selected_config.validation_scenario_count,
    )
    validation_count = len(validation)

    posterior = infer_gtls_topology_posterior(
        training,
        root_bus=reference_net.root_bus,
        pq_noise_relative_std=pq_noise_relative_std,
        voltage_noise_relative_std=voltage_noise_relative_std,
        validation_scenario_count=(
            selected_config.gtls_validation_scenario_count
        ),
        shrinkage_to_ols=selected_config.gtls_shrinkage_to_ols,
        temporal_block_length=selected_config.gtls_temporal_block_length,
        posterior_temperature=selected_config.gtls_posterior_temperature,
    )
    hierarchy_arguments = {
        "harmonic_candidates": (
            list(selected_config.fft_harmonic_candidates)
            if selected_config.fft_harmonic_candidates is not None
            else None
        ),
        "distance_mode": selected_config.distance_mode,
        "tolerance_factor": selected_config.rnj_tolerance_factor,
        "bootstrap_replicates": (
            selected_config.aggregation_bootstrap_replicates
        ),
        "stability_threshold": (
            selected_config.fft_clade_confirmation_threshold
        ),
        "max_cluster_size": selected_config.aggregation_max_cluster_size,
        "deembedding_weight": (
            selected_config.aggregation_deembedding_weight
        ),
        "local_tolerance_factor": (
            selected_config.aggregation_local_tolerance_factor
        ),
        "pq_extra_noise_rel": min(0.5 * pq_noise_relative_std, 0.0025),
        "voltage_extra_noise_rel": min(
            0.5 * voltage_noise_relative_std,
            0.0001,
        ),
        "block_fraction": selected_config.aggregation_block_fraction,
        "minimum_rank_ratio": 0.90,
        "max_fft_condition_number": 1e8,
        "predictive_plateau_ratio": 0.10,
        "fft_stability_weight": 0.60,
        "seed": seed,
    }
    proposal_hierarchy = run_fft_rnj_hierarchy(
        training,
        reference_net.root_bus,
        aggregation_cluster_allowlist=set(),
        **hierarchy_arguments,
    )
    proposed_clades = _candidate_clade_union(posterior, proposal_hierarchy)
    if proposed_clades:
        _accepted, preliminary_quartet = bootstrap_quartet_significance(
            training,
            proposed_clades,
            reference_net.root_bus,
            distance_mode=selected_config.distance_mode,
            replicates=selected_config.quartet_replicates,
            confidence_level=selected_config.quartet_confidence,
            minimum_positive_support=(
                selected_config.quartet_positive_support
            ),
            minimum_effect=selected_config.quartet_minimum_effect,
            preprocess_recipe=proposal_hierarchy.selected_recipe,
            seed=seed,
        )
    else:
        preliminary_quartet = {}
    gtls_map_clades = set(posterior.selected.projection.candidate.clades)
    preliminary_evidence = build_clade_evidence(
        proposed_clades,
        ac_raw_clades=set(),
        ac_validated_clades=set(),
        gtls_map_clades=gtls_map_clades,
        gtls_marginals=posterior.clade_marginals,
        fft_base_clades=set(proposal_hierarchy.base_clades),
        fft_final_clades=set(proposal_hierarchy.final_clades),
        fft_stability=proposal_hierarchy.clade_confidence,
        quartet_evidence=preliminary_quartet,
        fft_confirmation_threshold=(
            selected_config.fft_clade_confirmation_threshold
        ),
        gtls_confirmation_threshold=(
            selected_config.gtls_clade_confirmation_threshold
        ),
        quartet_contradiction_effect=(
            selected_config.quartet_contradiction_effect
        ),
    )
    stable_clusters, rejected_clusters = _confirmed_clusters(
        proposal_hierarchy,
        preliminary_evidence,
    )
    proposed_clusters = {
        cluster.members for cluster in proposal_hierarchy.proposed_clusters
    }
    aggregation_rerun = bool(stable_clusters)
    if aggregation_rerun:
        hierarchy = run_fft_rnj_hierarchy(
            training,
            reference_net.root_bus,
            aggregation_cluster_allowlist=stable_clusters,
            **hierarchy_arguments,
        )
    else:
        hierarchy = proposal_hierarchy

    final_proposed_clades = _candidate_clade_union(posterior, hierarchy)
    ac_validated = select_and_validate_topology(
        scenarios,
        reference_net,
        quartet_candidate_clades=proposed_clades | final_proposed_clades,
        extra_candidates=_hierarchy_extra_candidates(hierarchy, posterior),
        precomputed_quartet_evidence=preliminary_quartet,
        pq_noise_relative_std=pq_noise_relative_std,
        voltage_noise_relative_std=voltage_noise_relative_std,
        quartet_replicates=selected_config.quartet_replicates,
        quartet_confidence=selected_config.quartet_confidence,
        quartet_positive_support=(
            selected_config.quartet_positive_support
        ),
        quartet_minimum_effect=selected_config.quartet_minimum_effect,
        quartet_distance_mode=selected_config.distance_mode,
        quartet_preprocess_recipe=hierarchy.selected_recipe,
        quartet_contradiction_effect=(
            selected_config.quartet_contradiction_effect
        ),
        validation_scenario_count=validation_count,
        seed=seed,
    )
    all_clades = (
        proposed_clades
        | final_proposed_clades
        | set(ac_validated.raw_clades)
    )
    evidence = build_clade_evidence(
        all_clades,
        ac_raw_clades=set(ac_validated.raw_clades),
        ac_validated_clades=set(ac_validated.validated_clades),
        gtls_map_clades=gtls_map_clades,
        gtls_marginals=posterior.clade_marginals,
        fft_base_clades=set(hierarchy.base_clades),
        fft_final_clades=set(hierarchy.final_clades),
        fft_stability=hierarchy.clade_confidence,
        quartet_evidence=ac_validated.quartet_evidence,
        fft_confirmation_threshold=(
            selected_config.fft_clade_confirmation_threshold
        ),
        gtls_confirmation_threshold=(
            selected_config.gtls_clade_confirmation_threshold
        ),
        quartet_contradiction_effect=(
            selected_config.quartet_contradiction_effect
        ),
    )
    applied_clusters = {cluster.members for cluster in hierarchy.clusters}

    confidence = np.array(
        [
            hierarchy.clade_confidence.get(clade, 0.0)
            for clade in hierarchy.base_clades
        ],
        dtype=float,
    )
    mean_confidence = float(np.mean(confidence)) if confidence.size else 1.0
    frequency = _selected_frequency(hierarchy)
    common_gate_arguments = {
        "mean_clade_confidence": mean_confidence,
        "frequency_stability": frequency.clade_stability,
        "fit_r2": hierarchy.fit_r2_score,
        "condition_number": hierarchy.condition_number,
        "minimum_clade_confidence": selected_config.minimum_clade_confidence,
        "minimum_frequency_stability": (
            selected_config.minimum_frequency_stability
        ),
        "minimum_fit_r2": selected_config.minimum_fit_r2,
        "maximum_condition_number": selected_config.maximum_condition_number,
        "stable_base_minimum_clade_confidence": (
            selected_config.stable_base_minimum_clade_confidence
        ),
        "stable_base_minimum_frequency_stability": (
            selected_config.stable_base_minimum_frequency_stability
        ),
        "stable_base_minimum_fit_r2": (
            selected_config.stable_base_minimum_fit_r2
        ),
        "stable_base_maximum_condition_number": (
            selected_config.stable_base_maximum_condition_number
        ),
    }
    fft_aggregation_trusted = bool(
        frequency.admissible
        and hierarchy.aggregation_accepted
        and applied_clusters
        and applied_clusters <= stable_clusters
        and hierarchy_gate_passes(
            aggregation_accepted=True,
            **common_gate_arguments,
        )
        and _no_material_contradictions(hierarchy.final_clades, evidence)
    )
    fft_base_trusted = bool(
        frequency.admissible
        and hierarchy_gate_passes(
            aggregation_accepted=False,
            **common_gate_arguments,
        )
        and _no_material_contradictions(hierarchy.base_clades, evidence)
    )
    gtls_map_trusted = bool(
        posterior.selected.posterior_probability
        >= selected_config.gtls_map_probability_threshold
        and _no_material_contradictions(gtls_map_clades, evidence)
    )
    selected = set(ac_validated.raw_clades)
    final = frozenset(ac_validated.validated_clades)
    source = _selected_ac_source(selected, hierarchy, posterior)
    return UnifiedTopologyResult(
        final_clades=final,
        pre_quartet_clades=frozenset(selected),
        selection_source=source,
        ac_validated=ac_validated,
        gtls_posterior=posterior,
        hierarchy=hierarchy,
        clade_evidence=evidence,
        proposed_aggregation_clades=frozenset(proposed_clusters),
        stable_aggregation_clades=frozenset(stable_clusters),
        applied_aggregation_clades=frozenset(applied_clusters),
        rejected_aggregation_reasons=rejected_clusters,
        aggregation_rerun=aggregation_rerun,
        fft_aggregation_trusted=fft_aggregation_trusted,
        fft_base_trusted=fft_base_trusted,
        gtls_map_trusted=gtls_map_trusted,
        mean_fft_clade_confidence=mean_confidence,
        selected_frequency_stability=float(frequency.clade_stability),
        selected_frequency_admissible=bool(frequency.admissible),
    )
