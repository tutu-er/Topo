"""Small deterministic nonnegative ridge solver."""

from __future__ import annotations

import numpy as np


def solve_nonnegative_ridge(
    design: np.ndarray,
    target: np.ndarray,
    ridge: float = 1e-10,
    max_iterations: int = 5000,
    tolerance: float = 1e-9,
) -> tuple[np.ndarray, int]:
    """Solve nonnegative ridge regression with accelerated projection."""

    column_scale = np.maximum(np.linalg.norm(design, axis=0), 1e-12)
    normalized = design / column_scale
    initial, *_ = np.linalg.lstsq(normalized, target, rcond=None)
    current = np.maximum(initial, 0.0)
    extrapolated = current.copy()
    momentum = 1.0
    gram = normalized.T @ normalized
    right_hand_side = normalized.T @ target
    step = 1.0 / max(float(np.linalg.eigvalsh(gram).max() + ridge), 1e-12)
    for iteration in range(1, max_iterations + 1):
        gradient = gram @ extrapolated - right_hand_side + ridge * extrapolated
        proposal = np.maximum(0.0, extrapolated - step * gradient)
        relative_change = np.linalg.norm(proposal - current)
        relative_change /= max(np.linalg.norm(current), 1e-12)
        next_momentum = 0.5 * (1.0 + np.sqrt(1.0 + 4.0 * momentum**2))
        extrapolated = proposal + ((momentum - 1.0) / next_momentum) * (
            proposal - current
        )
        current = proposal
        momentum = next_momentum
        if relative_change <= tolerance:
            break
    return current / column_scale, iteration
