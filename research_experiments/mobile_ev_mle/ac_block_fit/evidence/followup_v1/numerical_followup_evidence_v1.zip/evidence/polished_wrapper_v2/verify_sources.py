"""Verify the numerical rule is byte-identical after wrapper log changes."""
import ast
from hashlib import sha256
import json
from pathlib import Path
import zipfile

stage=Path(__file__).resolve().parents[2]
module=stage/'research_experiments/mobile_ev_mle/ac_block_fit'
previous=stage/'outputs/polished_wrapper_v1/source_snapshot'

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def functions(path):
    source=path.read_text(encoding='utf-8')
    return {node.name:sha256(ast.get_source_segment(source,node).encode()).hexdigest()
        for node in ast.parse(source).body if isinstance(node,ast.FunctionDef)}

before=functions(previous/'polished_fit.py')
after=functions(module/'polished_fit.py')
frozen_names=('_physical_check','polish_stationarity','_independent_replay')
rules={name:dict(before=before[name],after=after[name],equal=before[name]==after[name])
       for name in frozen_names}
manifest=json.loads((previous/'manifest.json').read_text(encoding='utf-8-sig'))
old_verified={name:digest(previous/name)==expected
    for name,expected in manifest['source_sha256'].items()}
with zipfile.ZipFile(stage/'outputs/polished_wrapper_v1/source_snapshot.zip') as archive:
    archived=sha256(archive.read('polished_fit.py')).hexdigest()
record=dict(schema='polished_wrapper_log_revision_v2',
    original_module_sha256=digest(previous/'polished_fit.py'),
    revised_module_sha256=digest(module/'polished_fit.py'),
    revised_test_sha256=digest(module/'test_polished_fit.py'),
    old_snapshot_matches_manifest=old_verified,
    zip_old_module_matches=archived==digest(previous/'polished_fit.py'),
    frozen_function_source_sha256=rules,
    standalone_rule_unchanged=all(value['equal'] for value in rules.values()),
    old_test_receipt_and_CIGRE_result_not_overwritten=True,
    tests_passed=25,tests_total=25,polish_tests=18,test_seconds=4.16,
    scientific_conditions_created=0,
    changes=['separate original dynamic-scale stationarity from common criterion',
             'complete top-level cost/failure records on exception paths',
             'actual AC exception and reconstruction failure regression tests'])
assert all(old_verified.values()) and record['zip_old_module_matches'] and record['standalone_rule_unchanged']
(Path(__file__).with_name('test_receipt.json')).write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:record[key] for key in ('original_module_sha256','revised_module_sha256','standalone_rule_unchanged')}))
