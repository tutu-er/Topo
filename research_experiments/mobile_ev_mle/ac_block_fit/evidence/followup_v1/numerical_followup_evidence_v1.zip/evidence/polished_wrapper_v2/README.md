# Wrapper record revision

The standalone three-step polish rule and CPU full-AC replay implementation
are unchanged. Only wrapper records and their tests change after the original
32-endpoint audit completed. `verify_sources.py` compares exact function
source hashes and checks the archived v1 file against its original manifest
and ZIP bytes. Old v1 receipts, CIGRE output and endpoint output are retained.

The top-level stationarity fields now describe the common original-scale PG
test at the declared polish target. Original dynamic-scale solver fields are
preserved as `normal_stationarity_pass`, `normal_stationarity_tolerance` and
inside `normal_fit`. If an exception prevents independent verification,
`common_stationarity_verified=false` and the wrapper remains unsuccessful.
Fixed-line source-only fits retain their original method and criterion.

Every returned path records full elapsed time, normal and additional actual AC
calls, cumulative optimization residual trials, external counter snapshots
and counter differences. Independent replay exceptions retain the original
finite fitted state, original failure reason, and all already consumed polish
costs in top-level fields. Optimization budget failures still receive no new
trials.

25/25 regression tests passed in 4.16 seconds, including 18 polish/wrapper
tests. New tests raise actual exceptions from the entry AC and independent
replay AC calls, verify replay failure after consumed optimization trials,
exercise a reconstruction failure, and check the path without an external
counter. No scientific batch or numerical comparison is rerun.
