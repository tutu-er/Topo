"""One observed-history H192 wrapper diagnostic, no scientific new batch."""
from hashlib import sha256
from pathlib import Path
from time import perf_counter
import json
import traceback

from research_experiments.mobile_ev_mle.ac_block_fit.gpu_fit_benchmark import reconstruct
from research_experiments.mobile_ev_mle.ac_block_fit import benchmark as bm
from research_experiments.mobile_ev_mle.ac_block_fit.polished_fit import fit_rx_blocks_polished

stage=Path(__file__).resolve().parents[2]
record=dict(scope='observed-history H192 numerical solver diagnostic; no policy evaluation',
            future_used=False,truth_used=False,scientific_conditions_created=0)
clock=perf_counter()
try:
    c,obs,model,options,initial,declaration=reconstruct('cigre',stage/'outputs/history_only_v1.json.gz')
    options.update(max_nfev=250,tol=1e-8,multistart=1)
    settings=dict(scale_mode='jac',inner_tol=1e-10,inner_maxiter=2000,inner_acceptance='certified_gap')
    record.update(declaration=declaration,options=options,settings=settings,
        initial_sha256=sha256(bm._bytes(initial)).hexdigest(),n=c.n,m=c.m,t=obs.t)
    counts={};started=perf_counter()
    result=fit_rx_blocks_polished(c,obs,model,initial=initial,call_counter=counts,**options,**settings)
    record.update(status='returned',wrapper_seconds=perf_counter()-started,
                  fit=result.summary(),counters=counts,
                  state=dict(r=result.r,x=result.x,source_p=result.source_p,source_q=result.source_q))
except Exception as error:
    record.update(status='exception',error=repr(error),traceback=traceback.format_exc())
record['total_seconds']=perf_counter()-clock
bm._write(Path(__file__).with_name('cigre_H192.json'),record)
print(json.dumps(bm._serial({key:record[key] for key in ('status','total_seconds')})))
