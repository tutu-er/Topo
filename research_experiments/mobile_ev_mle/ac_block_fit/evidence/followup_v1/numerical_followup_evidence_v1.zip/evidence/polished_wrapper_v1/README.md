# Budgeted AC stationarity polish

This is a numerical solver diagnostic on arrived historical data. No EV
strategy, simulated truth, future meter reading or scientific calibration
threshold is changed.

The optional wrapper first calls the original block-QR fitter. For an original
successful free-line fit, at most three bounded QR steps use the remaining
optimization residual budget. The entry Jacobian inverse column norms and
lambda=1e-4 are frozen. Every accepted step has positive predicted linear
model decrease, passes the original AC/domain/source/voltage checks, stays
below the single entry objective bound
`F0 + 256*eps*max(1,F0)`, and strictly lowers the original-scale projected
gradient. This numerical band is not a proved bound on the nonlinear model.

Wrapper success requires original normal success, an independent CPU full-AC
replay, and original-scale projected gradient <= 1e-5. Original budget failures
are retained. Fixed-line source-only fits keep their original path. Coordinate
stationarity at a collapsed R/alpha corner is not a physical R/X cone KKT
certificate.

Tests: 21/21 across `test_polished_fit.py` and unchanged `test_nonlinear.py`,
3.25 seconds in the recorded invocation; JUnit evidence is `tests.xml`.
Fourteen tests exercise the polish/wrapper specifically.

The single CIGRE H192 complete wrapper run used the observed-history allowlist
and the public linear initializer. Its normal fit stopped by relative loss
with 6 optimization residual evaluations and common PG 1.097489e-3. Two
polish trials lowered common PG to 2.830015e-6. SSE changed from
1184.8688577805742 to 1184.8688577801124. Full physical checks passed. This
uses 8/250 optimization evaluations and 10 actual full AC calls: normal 6,
entry audit 1, polish trials 2, independent replay 1. Wrapper elapsed time was
0.2638 seconds in this single run; it is not a performance estimate.

Reproduction: run `run_cigre.py` from the isolated stage with its stage and
`rnj_wzzt_core` on PYTHONPATH, using the recorded Topo Python environment and
one BLAS thread. `cigre_H192.json` contains the initial-data hashes, domain,
state, loss, full trace, source hashes and cost records.
