"""Seal retained failure plus the one explicitly authorized passing replay.

No source algorithm, test assertion, saved result or numerical run is changed.
This completion path deliberately does not claim failure-free test stability.
"""
from hashlib import sha256
import json
from pathlib import Path
from time import perf_counter
from datetime import datetime, timezone

from research_experiments.mobile_ev_mle.ac_block_fit import followup_package as p

started=perf_counter()
work=p.STAGE/'outputs/followup_pack_work_v1'
output=p.MODULE/'evidence/followup_v1'
target=output/'numerical_followup_evidence_v1.zip'
preliminary=work/'preliminary_archive.zip'
assert target.is_file() and not preliminary.exists()
before=p.verify_archive(target)
preliminary_sha=p._digest(target)
target.rename(preliminary)
assert p._digest(preliminary)==preliminary_sha
p._write(work/'preliminary_archive_receipt.json',dict(status='initial_restore_test_failed',
    sha256=preliminary_sha,bytes=preliminary.stat().st_size,members=len(before),
    retained_file=str(preliminary),not_duplicated_in_final_archive=True))
p._write(work/'preliminary_manifest.json',before)

stage_tests=p._read(work/'preparation/stage_cpu_tests/test_receipt.json')
first=p._read(work/'restored_cpu_tests/test_receipt.json')
repeat=p._read(work/'restored_cpu_tests_repeat1/test_receipt.json')
assert stage_tests['status']=='passed' and stage_tests['test_counts']['tests']==156
assert first['pytest_exit_code']!=0 and first['test_counts']['tests']==156
assert first['test_counts']['failures']==1 and first['test_counts']['errors']==0
assert repeat['status']=='passed' and repeat['test_counts']['tests']==156
assert repeat['test_counts']['failures']==0 and repeat['test_counts']['errors']==0
assert all(record['every_project_import_from_declared_root'] for record in (stage_tests,first,repeat))
assert not list(work.glob('restored_cpu_tests_repeat[2-9]*'))

freeze_path,freeze=p.assert_original_unchanged()
prepared=p._read(work/'preparation/prepared.json')
assert prepared['closure']['dependency_files']==58
old_path=p.MODULE/'evidence/numerical_evidence_v1.zip'
old_receipt=p._read(p.MODULE/'evidence/package_receipt.json')
assert p._digest(old_path)==old_receipt['sha256']
gates=p._completion_gates()
members=p._member_map(prepared['dependencies'],work/'preparation',freeze_path)

# Every imported numerical/test file must retain exactly the tested bytes.
# Final report/checkpoint text updates after the failed first seal are recorded
# separately; they are not executed code and are not silently folded into an
# assertion that all old document bytes stayed identical.
for record in (stage_tests,first,repeat):
    for row in record['local_imports']:
        member='source/'+row['path']
        assert member in members,member
        assert p._digest(members[member])==row['sha256'],member
for name,path in members.items():
    if name.startswith('source/') and Path(name).suffix=='.py':
        assert name in before and before[name]['sha256']==p._digest(path),name
document_updates=[]
for name,path in members.items():
    if name.startswith('source/') and name in before and p._digest(path)!=before[name]['sha256']:
        assert Path(name).suffix in ('.md','.json'),name
        document_updates.append(dict(member=name,before=before[name]['sha256'],after=p._digest(path)))

for phase in ('restored_cpu_tests','restored_cpu_tests_repeat1'):
    for path in sorted((work/phase).iterdir()):
        if path.is_file():members['verification/'+phase+'/'+path.name]=path
for name in ('diagnose_restore_linear.py','linear_stage_diagnostic.json','linear_restore_diagnostic.json',
             'empty_einsum_diagnostic.json','restore_instability.md','preliminary_archive_receipt.json',
             'preliminary_manifest.json','publish_instability.py'):
    members['verification/packaging_completion/'+name]=work/name
layout=p.STAGE/'outputs/linear_restore_diagnosis_v1'
assert layout.is_dir()
for path in sorted(layout.rglob('*')):
    if path.is_file() and '__pycache__' not in path.parts:
        members['evidence/linear_restore_diagnosis_v1/'+path.relative_to(layout).as_posix()]=path

manifest=p._zip(target,members)
for record in (first,repeat):
    for row in record['local_imports']:
        assert manifest['source/'+row['path']]['sha256']==row['sha256']
p.assert_original_unchanged()
assert p._digest(old_path)==old_receipt['sha256']

status='completed_with_unexplained_restore_test_instability'
receipt=dict(status=status,created_utc=datetime.now(timezone.utc).isoformat(),
    archive=target.name,sha256=p._digest(target),bytes=target.stat().st_size,members=len(manifest),
    archive_hashpass=True,all_members_reopened_and_hash_verified=True,
    importoriginpass=True,all_imported_code_matches_final_archive=True,
    original_code_bytes_unchanged_from_tested_preliminary=True,
    post_test_document_updates=document_updates,
    stage_fulltests=stage_tests['test_counts'],first_restored_fulltests=first['test_counts'],
    first_restored_passed_tests=155,repeat_restored_fulltests=repeat['test_counts'],
    repeat_fulltests_pass=True,unexplained_first_testfailure=True,
    failed_test='test_linear.py::test_fixed_lines_equals_independent_two_dimensional_sources[0.1]',
    full_restore_attempts=2,additional_full_retests_after_authorized_repeat=0,
    independent_restore_root=first['root'],dependency_closure=prepared['closure'],
    original_frozen_files_unchanged=len(freeze['source_sha256']),
    original_policy=freeze['identity'],old_numerical_evidence_v1_modified=False,
    old_evidence_sha256=old_receipt['sha256'],preliminary_archive_retained=str(preliminary),
    preliminary_archive_included_again=False,GPU_binaries_included=False,
    completion_gates=gates,QR_default_adoption=False,scientific_conditions_created=0,
    seconds=perf_counter()-started)
p._write(output/'package_receipt.json',receipt)
p._write(output/'replay_receipt.json',dict(status=status,archive=target.name,archive_sha256=receipt['sha256'],
    archive_hashpass=True,importoriginpass=True,all_imported_code_matches_final_archive=True,
    stage_fulltests=stage_tests['test_counts'],first_restored_fulltests=first['test_counts'],
    first_restored_passed_tests=155,repeat_restored_fulltests=repeat['test_counts'],
    repeat_fulltests_pass=True,unexplained_first_testfailure=True,
    full_restore_attempts=2,QR_default_adoption=False,source_numerical_code_modified=False,
    all_members_hash_verified=True,original_frozen_scientific_sources_unchanged=len(freeze['source_sha256']),
    scientific_conditions_created=0))
print(json.dumps(receipt,ensure_ascii=False))
