"""Retained diagnostic of one isolated restore CPU unit failure; no fitting."""
import json
from pathlib import Path
import sys
from hashlib import sha256
import numpy as np
from scipy.optimize import lsq_linear

root=Path(sys.argv[1]).resolve();output=Path(sys.argv[2]).resolve()
sys.path[:0]=[str(root/'rnj_wzzt_core'),str(root)]
from research_experiments.mobile_ev_mle.ac_block_fit.linear import solve_block_step
from research_experiments.mobile_ev_mle.ac_block_fit.test_linear import dense_problem
rows=[]
for repeat in range(6):
    rng=np.random.default_rng(7)
    r,g,s=rng.normal(size=(5,4)),np.empty((5,4,0)),rng.normal(size=(5,4,2))
    lo,hi=-.2*np.ones(10),.3*np.ones(10)
    out=solve_block_step(r,g,s,lo,hi,damping=.1,kkt_tol=1e-9)
    matrix,target=dense_problem(r,g,s,.1)
    oracle=lsq_linear(matrix,target,bounds=(lo,hi),method='bvls',tol=1e-12,max_iter=1000)
    rows.append({key:(value.tolist() if hasattr(value,'tolist') else value) for key,value in out.items()})
    rows[-1].update(repeat=repeat,oracle_step=oracle.x.tolist(),oracle_objective=float(oracle.cost),
        objective_excess=float(out['objective']-oracle.cost),r_address=r.ctypes.data,s_address=s.ctypes.data)
record=dict(root=str(root),module_file=str(Path(sys.modules[solve_block_step.__module__].__file__)),
    module_sha256=sha256(Path(sys.modules[solve_block_step.__module__].__file__).read_bytes()).hexdigest(),
    rows=rows,successes=sum(row['success'] for row in rows),repeats=len(rows))
output.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(root=str(root),successes=record['successes'],repeats=record['repeats'],
    kkts=[row['kkt'] for row in rows],iterations=[row['iterations'] for row in rows])))
