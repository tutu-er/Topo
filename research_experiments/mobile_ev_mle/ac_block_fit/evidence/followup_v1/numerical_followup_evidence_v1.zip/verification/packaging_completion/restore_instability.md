# Retained CPU restore test instability

The first independent archive extraction ran all CPU tests with an isolated
pytest configuration and project-import origin checks. It returned 155 passed
and one failed test:

`test_linear.py::test_fixed_lines_equals_independent_two_dimensional_sources[0.1]`

The bounded linear solver returned `active-set iteration budget exhausted`.
The source bytes matched the archive; all project imports came from the
extracted root. This failed invocation and its complete logs/receipt remain in
`restored_cpu_tests/`.

The parent explicitly authorized one complete repeat. The same extracted
source bytes, test runner, tolerances, single-thread environment and import
checks returned 156 passed and no failures. This invocation has a separate
`restored_cpu_tests_repeat1/` receipt. The repeat did not change code or relax
an assertion. No further complete test retries were performed.

A separate short diagnostic called the exact failing seeded convex problem
six times in each of two fresh interpreters, one using the stage source and
one using the extracted source. All twelve solves completed in nine iterations
with KKT residual 3.9031e-16. This diagnostic does not explain the failed full
test. The empty-shared-block einsum probe returned exact zeros in 10,000
allocations and did not reproduce that proposed cause.

The failure's cause remains unresolved. The evidence supports a later passing
CPU replay, while retaining an observed process-context instability. It does
not establish failure-free solver stability. The original solver and frozen
scientific experiment remain unchanged; QR adoption remains on hold.
