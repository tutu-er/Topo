# fresh 配对 pilot 核查

仅按根代理授权生成941101、941102两条pilot；正式cal32/eval48尚未启动。原C/D输入和结果未修改。新wrapper/cfg/runtime于22:50:40 UTC冻结，policy_id为`1c0c785609ccc1c6d60b6a725918f9c1eaed2314b701f4250bd9a5fa86930d8a`，冻结JSON SHA-256为`2d18b011df19b72dfe45bff5bd553346ee4f36276a8c2e9756f16dd78a94b9af`；绑定51个实际加载/可能延迟加载的原项目与core源码，以及新runner/contracts/protocol。

25项pure/static/mock tests通过（6.01s）。实际两条pilot均为strong cherry，分别17.14354s、16.59848s，均值16.87101s，满足预声明≤45s预算条件。Windows进程由runner实际设置并核验BelowNormal，BLAS/OMP/MKL均为1。两条完整的共享H14+rolling新H20+openloop新H20必要12fit全部成功，无选择回退、实际电压失败或配对轨迹失败。

重建原H0/H14/H20全部计量通道逐值exact一致；原check_plan、执行前缀/SOC/site/剩余网电任务检查通过。两个方法首两格相同，后续完整动作不同；最终评价均只使用相同H14候选R/X初值、相同candidate seed与同预算，不以真值调初值。16个保存final fit的Gaussian目标独立回放全部verified，最大loss差2.274e-13，无重新优化。

| seed | truth层 | rolling signed margin | openloop signed margin |
|---|---|---:|---:|
|941101|strong cherry 02|1600.4481|1693.2072|
|941102|strong cherry 01|1440.3530|1390.8675|

signed margin是最小错误候选取得的局部AC损失减真候选损失。两例差异方向一负一正；pilot只能支持读取/重放/共同初值和数值记录契约，不能证明反馈收益、总体恢复率或全局MLE。pilot不进入正式校准/评价分母；后续正式阶段仍须根代理明确授权并保持冻结源码/协议不变。
