# 线路响应不确定性：冻结流程统计

阶段：evaluation；记录128/128；状态分母：{"complete": 88, "inference_failure": 40}。
每项指标先在同一历史内平均计量噪声，再跨历史等权汇总。regular/shift分别报告；两者的平均仍以同一历史为单位。

## 全部计划：联合线路模型评价

|方法|情景|可用历史|MAP正确|Brier|真标签负log概率|90%集合排真|未决|平均最大后验|电压90%区间覆盖|
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
|constant|regular|88|53.6%|0.8844|16.21|43.0%|13.1%|95.8%|54.6%|
|constant|shift|88|53.7%|0.8784|16.4|42.6%|10.3%|96.6%|40.0%|
|fixed_bc__fixed_bidir|regular|88|62.8%|0.7258|22.05|35.8%|4.1%|98.7%|41.4%|
|fixed_bc__fixed_bidir|shift|88|63.7%|0.7052|21.78|34.4%|4.2%|98.6%|35.1%|
|fixed_bc__fixed_charge|regular|88|60.4%|0.7623|17.83|37.0%|6.7%|97.9%|56.7%|
|fixed_bc__fixed_charge|shift|88|60.4%|0.7591|18.06|36.7%|6.2%|98.0%|44.9%|
|fixed_bc__mobile_bidir|regular|88|69.0%|0.6039|15.96|29.7%|3.8%|98.8%|42.2%|
|fixed_bc__mobile_bidir|shift|88|70.2%|0.5763|15.69|28.0%|3.9%|98.7%|35.9%|
|fixed_bc__mobile_charge|regular|88|61.7%|0.7422|16.82|36.2%|5.8%|98.1%|55.6%|
|fixed_bc__mobile_charge|shift|88|63.3%|0.7071|16.67|34.3%|5.8%|98.2%|43.8%|
|highlow|regular|88|57.3%|0.8175|15.71|39.5%|8.6%|97.2%|53.3%|
|highlow|shift|88|58.9%|0.7852|16.12|37.8%|8.3%|97.4%|41.3%|
|joint_bc__fixed_bidir|regular|88|62.1%|0.7412|21.95|36.5%|3.5%|98.8%|43.4%|
|joint_bc__fixed_bidir|shift|88|63.0%|0.7205|21.61|35.3%|3.8%|98.7%|36.0%|
|joint_bc__fixed_charge|regular|88|60.4%|0.7622|17.58|37.0%|6.6%|98.0%|56.6%|
|joint_bc__fixed_charge|shift|88|60.2%|0.7624|17.74|37.0%|6.2%|98.0%|44.8%|
|joint_bc__mobile_bidir|regular|88|71.6%|0.557|15.46|27.5%|3.3%|99.0%|44.3%|
|joint_bc__mobile_bidir|shift|88|72.8%|0.5258|15.07|25.7%|3.6%|98.8%|36.8%|
|joint_bc__mobile_charge|regular|88|61.5%|0.7439|16.6|36.2%|5.9%|98.1%|55.5%|
|joint_bc__mobile_charge|shift|88|63.2%|0.7036|16.28|34.0%|6.2%|98.0%|43.8%|
|joint_oldbc__fixed_bidir|regular|88|61.2%|0.7605|21.95|37.4%|3.6%|98.8%|44.2%|
|joint_oldbc__fixed_bidir|shift|88|62.0%|0.7396|21.61|36.2%|3.8%|98.8%|36.2%|
|joint_oldbc__fixed_charge|regular|88|60.2%|0.7649|17.83|37.1%|7.0%|97.8%|56.6%|
|joint_oldbc__fixed_charge|shift|88|60.0%|0.7662|17.97|37.1%|6.2%|98.0%|44.7%|
|joint_oldbc__mobile_bidir|regular|88|70.6%|0.5768|15.98|28.3%|3.7%|98.9%|44.1%|
|joint_oldbc__mobile_bidir|shift|88|71.6%|0.5525|15.58|27.2%|3.4%|98.9%|36.6%|
|joint_oldbc__mobile_charge|regular|88|61.5%|0.7448|16.83|36.2%|6.1%|98.0%|55.7%|
|joint_oldbc__mobile_charge|shift|88|63.0%|0.7117|16.56|34.6%|5.9%|98.1%|44.1%|
|none|regular|88|47.6%|0.9478|17.27|44.0%|26.4%|91.4%|67.9%|
|none|shift|88|51.4%|0.8848|17.31|41.4%|24.5%|91.9%|54.3%|
|ranked__fixed_bidir|regular|88|62.1%|0.7412|21.78|36.5%|3.5%|98.8%|44.1%|
|ranked__fixed_bidir|shift|88|63.0%|0.7205|21.49|35.3%|3.8%|98.7%|36.3%|
|ranked__fixed_charge|regular|88|60.4%|0.7622|17.58|37.0%|6.6%|98.0%|56.6%|
|ranked__fixed_charge|shift|88|60.2%|0.7624|17.74|37.0%|6.2%|98.0%|44.7%|
|ranked__mobile_bidir|regular|88|71.5%|0.5589|15.83|27.5%|3.6%|98.9%|43.8%|
|ranked__mobile_bidir|shift|88|72.5%|0.534|15.47|26.3%|3.3%|98.9%|36.7%|
|ranked__mobile_charge|regular|88|61.5%|0.7446|16.76|36.2%|6.0%|98.0%|55.6%|
|ranked__mobile_charge|shift|88|63.0%|0.7104|16.46|34.4%|5.9%|98.1%|43.8%|
|square__fixed_bidir|regular|88|63.3%|0.7171|22.34|35.3%|3.7%|98.8%|41.3%|
|square__fixed_bidir|shift|88|64.3%|0.6954|22.19|34.1%|3.7%|98.8%|34.6%|
|square__fixed_charge|regular|88|60.4%|0.7617|17.82|37.0%|6.7%|98.0%|56.7%|
|square__fixed_charge|shift|88|60.2%|0.7628|18|37.0%|6.2%|98.0%|44.9%|
|square__mobile_bidir|regular|88|72.9%|0.5279|15.88|25.9%|3.5%|98.9%|41.3%|
|square__mobile_bidir|shift|88|74.0%|0.5023|15.89|24.4%|3.6%|98.8%|34.9%|
|square__mobile_charge|regular|88|61.4%|0.7446|16.72|36.2%|5.9%|98.1%|55.3%|
|square__mobile_charge|shift|88|63.6%|0.6982|16.37|33.8%|5.9%|98.1%|43.4%|
|square_budget__fixed_bidir|regular|88|63.3%|0.7171|22.34|35.3%|3.7%|98.8%|41.3%|
|square_budget__fixed_bidir|shift|88|64.3%|0.6954|22.19|34.1%|3.7%|98.8%|34.6%|
|square_budget__fixed_charge|regular|88|60.4%|0.7617|17.82|37.0%|6.7%|98.0%|56.7%|
|square_budget__fixed_charge|shift|88|60.2%|0.7628|18|37.0%|6.2%|98.0%|44.9%|
|square_budget__mobile_bidir|regular|88|72.9%|0.5279|15.88|25.9%|3.5%|98.9%|41.3%|
|square_budget__mobile_bidir|shift|88|74.0%|0.5023|15.89|24.4%|3.6%|98.8%|34.9%|
|square_budget__mobile_charge|regular|88|65.3%|0.6711|15.93|32.7%|4.2%|98.6%|55.1%|
|square_budget__mobile_charge|shift|88|68.9%|0.5994|15.4|29.0%|5.0%|98.4%|43.8%|

## 相同动作的推断对照

fixed为旧固定线路模型；joint保留线路及其与源/负荷的共同不确定性。其余模型使用同一保存动作作概率消融。

|方法|推断模型|情景|MAP正确|Brier|负log概率|排真|电压区间覆盖|
|---|---|---|---:|---:|---:|---:|---:|
|constant|evidence_only|regular|49.9%|0.9426|16.91|45.6%|54.6%|
|constant|fixed|regular|52.1%|0.83|10.55|37.0%|66.7%|
|constant|joint|regular|53.6%|0.8844|16.21|43.0%|54.6%|
|constant|line_known|regular|45.3%|1.061|34.72|52.8%|51.6%|
|constant|no_cross|regular|53.7%|0.884|16.19|43.0%|54.6%|
|joint_bc__mobile_bidir|evidence_only|regular|71.6%|0.5569|15.64|27.1%|44.3%|
|joint_bc__mobile_bidir|fixed|regular|58.2%|0.8168|51.44|40.4%|56.1%|
|joint_bc__mobile_bidir|joint|regular|71.6%|0.557|15.46|27.5%|44.3%|
|joint_bc__mobile_bidir|line_known|regular|50.9%|0.9708|72.11|48.1%|40.6%|
|joint_bc__mobile_bidir|no_cross|regular|71.6%|0.5562|15.43|27.4%|44.3%|
|square__mobile_bidir|evidence_only|regular|72.7%|0.5267|16.05|25.4%|41.3%|
|square__mobile_bidir|fixed|regular|58.9%|0.796|56.58|38.9%|51.5%|
|square__mobile_bidir|joint|regular|72.9%|0.5279|15.88|25.9%|41.3%|
|square__mobile_bidir|line_known|regular|50.8%|0.9729|79.1|48.2%|37.6%|
|square__mobile_bidir|no_cross|regular|72.9%|0.5271|15.85|25.8%|41.4%|

区间覆盖采用真候选的条件预测均值和方差，另于拓扑后验集合覆盖。固定线路策略fixed_bc原本按fixed风险规划，其joint重评与fixed原模型结果分别保存。

## 统计与费用口径

summary.json保留按银行、训练长度、激励、创新与训练边界分组的指标、历史bootstrap区间、可估计时的格内分层标准误，以及缺失结果的范围。校准每格一条时，格内方差无法估计。bootstrap区间描述本实验条件混合分布；它不构成所有配电网的覆盖保证。
paired.csv先按同一历史计算策略或推断差，再进行历史层汇总。旧/新预测模型的风险值分属不同分布，不直接解释为同目标改进。
costs.csv保留各family的观测耗时及依赖费用之和；不同family共用缓存，因此这些数值不称冷启动独立成本。proposals.csv保留MILP失败、接受及求解上下界。
声明Gaussian内部积分直接读取冻结independent_score，涉及随机候选混合分布；物理校准读取固定真结构与轨迹下的新计量噪声。未保存的内部90%集合/分箱保持缺失，后续独立审计可补齐。

数据问题0项；未启动新拟合、规划、潮流或物理仿真。
