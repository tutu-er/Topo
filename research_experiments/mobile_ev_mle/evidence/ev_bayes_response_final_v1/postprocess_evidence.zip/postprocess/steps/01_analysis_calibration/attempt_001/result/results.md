# 线路响应不确定性：冻结流程统计

阶段：calibration；记录64/64；状态分母：{"complete": 45, "inference_failure": 19}。
每项指标先在同一历史内平均计量噪声，再跨历史等权汇总。regular/shift分别报告；两者的平均仍以同一历史为单位。

## 全部计划：联合线路模型评价

|方法|情景|可用历史|MAP正确|Brier|真标签负log概率|90%集合排真|未决|平均最大后验|电压90%区间覆盖|
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
|constant|regular|45|39.4%|1.156|28.23|57.2%|14.8%|95.1%|47.6%|
|constant|shift|45|34.0%|1.289|31.62|64.5%|7.5%|97.5%|36.4%|
|fixed_bc__fixed_bidir|regular|45|50.9%|0.9695|47.66|47.8%|2.6%|99.2%|36.4%|
|fixed_bc__fixed_bidir|shift|45|51.7%|0.9576|48.63|47.5%|2.3%|99.2%|32.4%|
|fixed_bc__fixed_charge|regular|45|42.9%|1.126|37.25|55.8%|4.3%|98.5%|53.3%|
|fixed_bc__fixed_charge|shift|45|42.9%|1.122|39.97|55.3%|4.9%|98.6%|44.3%|
|fixed_bc__mobile_bidir|regular|45|57.8%|0.8307|40.53|41.0%|2.3%|99.3%|38.4%|
|fixed_bc__mobile_bidir|shift|45|57.9%|0.8328|41.84|41.3%|2.0%|99.3%|34.0%|
|fixed_bc__mobile_charge|regular|45|44.4%|1.093|35.03|54.0%|5.4%|98.3%|52.5%|
|fixed_bc__mobile_charge|shift|45|43.5%|1.102|37.15|54.2%|5.1%|98.4%|43.3%|
|highlow|regular|45|38.5%|1.202|32.92|60.1%|6.7%|97.9%|48.5%|
|highlow|shift|45|40.9%|1.163|36.43|58.5%|5.9%|98.2%|39.9%|
|joint_bc__fixed_bidir|regular|45|50.9%|0.9654|49.95|47.6%|3.7%|98.8%|36.2%|
|joint_bc__fixed_bidir|shift|45|50.6%|0.9761|50.79|48.4%|3.3%|99.0%|32.5%|
|joint_bc__fixed_charge|regular|45|44.1%|1.106|41.1|54.8%|4.5%|98.4%|52.4%|
|joint_bc__fixed_charge|shift|45|41.7%|1.148|43.67|56.7%|4.6%|98.7%|43.6%|
|joint_bc__mobile_bidir|regular|45|55.2%|0.8802|41.78|43.5%|2.8%|99.1%|38.8%|
|joint_bc__mobile_bidir|shift|45|57.0%|0.8496|42.58|42.2%|2.6%|99.2%|34.5%|
|joint_bc__mobile_charge|regular|45|43.1%|1.121|39.7|55.8%|4.2%|98.5%|52.1%|
|joint_bc__mobile_charge|shift|45|42.5%|1.13|41.37|56.2%|4.0%|98.6%|42.9%|
|joint_oldbc__fixed_bidir|regular|45|50.9%|0.9667|48.88|47.7%|3.6%|98.8%|35.7%|
|joint_oldbc__fixed_bidir|shift|45|50.6%|0.9765|49.69|48.4%|3.3%|99.0%|32.3%|
|joint_oldbc__fixed_charge|regular|45|46.4%|1.058|40.5|52.3%|4.7%|98.2%|52.0%|
|joint_oldbc__fixed_charge|shift|45|44.5%|1.095|43|54.1%|5.0%|98.6%|43.4%|
|joint_oldbc__mobile_bidir|regular|45|55.2%|0.8823|42.31|43.5%|2.4%|99.2%|38.9%|
|joint_oldbc__mobile_bidir|shift|45|57.0%|0.8519|43.2|42.2%|2.0%|99.3%|34.4%|
|joint_oldbc__mobile_charge|regular|45|43.6%|1.111|40.27|54.8%|4.5%|98.4%|52.2%|
|joint_oldbc__mobile_charge|shift|45|42.9%|1.121|42.02|55.5%|3.5%|98.8%|42.8%|
|none|regular|45|44.0%|1.013|20.74|46.4%|28.3%|90.7%|66.4%|
|none|shift|45|45.6%|1.004|21.43|48.9%|25.1%|92.2%|54.7%|
|ranked__fixed_bidir|regular|45|50.9%|0.9667|48.82|47.7%|3.6%|98.8%|36.1%|
|ranked__fixed_bidir|shift|45|50.6%|0.9765|49.67|48.4%|3.3%|99.0%|32.4%|
|ranked__fixed_charge|regular|45|46.3%|1.063|40.97|52.6%|4.4%|98.4%|52.2%|
|ranked__fixed_charge|shift|45|44.0%|1.104|43.52|54.5%|5.3%|98.5%|43.4%|
|ranked__mobile_bidir|regular|45|55.2%|0.8802|41.95|43.5%|2.8%|99.1%|38.7%|
|ranked__mobile_bidir|shift|45|57.0%|0.8496|43.04|42.2%|2.6%|99.2%|34.3%|
|ranked__mobile_charge|regular|45|43.2%|1.117|40.3|55.3%|4.8%|98.4%|52.1%|
|ranked__mobile_charge|shift|45|42.5%|1.126|42.22|55.8%|4.3%|98.5%|42.7%|
|square__fixed_bidir|regular|45|51.3%|0.9591|49.42|47.3%|2.8%|99.2%|36.3%|
|square__fixed_bidir|shift|45|52.6%|0.9382|50.55|46.5%|2.4%|99.2%|32.4%|
|square__fixed_charge|regular|45|42.4%|1.139|38.65|56.7%|4.6%|98.4%|53.1%|
|square__fixed_charge|shift|45|42.0%|1.14|41.43|56.5%|4.6%|98.6%|44.2%|
|square__mobile_bidir|regular|45|58.3%|0.8193|40.07|40.5%|2.8%|99.1%|36.7%|
|square__mobile_bidir|shift|45|59.8%|0.7955|41.05|39.4%|2.0%|99.3%|32.9%|
|square__mobile_charge|regular|45|43.1%|1.114|36.04|55.1%|5.6%|98.2%|52.3%|
|square__mobile_charge|shift|45|42.4%|1.127|38.17|55.9%|3.9%|98.6%|42.7%|
|square_budget__fixed_bidir|regular|45|51.3%|0.9591|49.42|47.3%|2.8%|99.2%|36.3%|
|square_budget__fixed_bidir|shift|45|52.6%|0.9382|50.55|46.5%|2.4%|99.2%|32.4%|
|square_budget__fixed_charge|regular|45|42.4%|1.139|38.65|56.7%|4.6%|98.4%|53.1%|
|square_budget__fixed_charge|shift|45|42.0%|1.14|41.43|56.5%|4.6%|98.6%|44.2%|
|square_budget__mobile_bidir|regular|45|58.3%|0.8193|40.07|40.5%|2.8%|99.1%|36.7%|
|square_budget__mobile_bidir|shift|45|59.8%|0.7955|41.05|39.4%|2.0%|99.3%|32.9%|
|square_budget__mobile_charge|regular|45|50.1%|0.9706|29.53|47.9%|7.8%|97.7%|51.5%|
|square_budget__mobile_charge|shift|45|49.5%|0.9797|31.54|48.4%|6.1%|98.1%|42.9%|

## 相同动作的推断对照

fixed为旧固定线路模型；joint保留线路及其与源/负荷的共同不确定性。其余模型使用同一保存动作作概率消融。

|方法|推断模型|情景|MAP正确|Brier|负log概率|排真|电压区间覆盖|
|---|---|---|---:|---:|---:|---:|---:|
|constant|evidence_only|regular|35.4%|1.22|29.87|60.1%|47.6%|
|constant|fixed|regular|48.6%|0.935|20.33|43.4%|64.1%|
|constant|joint|regular|39.4%|1.156|28.23|57.2%|47.6%|
|constant|line_known|regular|34.2%|1.255|51.64|61.9%|43.9%|
|constant|no_cross|regular|39.4%|1.154|28.19|57.2%|47.6%|
|joint_bc__mobile_bidir|evidence_only|regular|55.6%|0.8741|42.41|43.3%|38.8%|
|joint_bc__mobile_bidir|fixed|regular|42.4%|1.133|138.3|56.5%|49.3%|
|joint_bc__mobile_bidir|joint|regular|55.2%|0.8802|41.78|43.5%|38.8%|
|joint_bc__mobile_bidir|line_known|regular|34.1%|1.311|140|64.9%|35.8%|
|joint_bc__mobile_bidir|no_cross|regular|55.3%|0.8801|41.81|43.5%|38.8%|
|square__mobile_bidir|evidence_only|regular|58.8%|0.812|40.5|40.2%|36.7%|
|square__mobile_bidir|fixed|regular|50.4%|0.9747|129.4|48.5%|48.8%|
|square__mobile_bidir|joint|regular|58.3%|0.8193|40.07|40.5%|36.7%|
|square__mobile_bidir|line_known|regular|34.5%|1.301|140.3|64.4%|33.7%|
|square__mobile_bidir|no_cross|regular|58.5%|0.8181|40.2|40.3%|36.7%|

区间覆盖采用真候选的条件预测均值和方差，另于拓扑后验集合覆盖。固定线路策略fixed_bc原本按fixed风险规划，其joint重评与fixed原模型结果分别保存。

## 统计与费用口径

summary.json保留按银行、训练长度、激励、创新与训练边界分组的指标、历史bootstrap区间、可估计时的格内分层标准误，以及缺失结果的范围。校准每格一条时，格内方差无法估计。bootstrap区间描述本实验条件混合分布；它不构成所有配电网的覆盖保证。
paired.csv先按同一历史计算策略或推断差，再进行历史层汇总。旧/新预测模型的风险值分属不同分布，不直接解释为同目标改进。
costs.csv保留各family的观测耗时及依赖费用之和；不同family共用缓存，因此这些数值不称冷启动独立成本。proposals.csv保留MILP失败、接受及求解上下界。
声明Gaussian内部积分直接读取冻结independent_score，涉及随机候选混合分布；物理校准读取固定真结构与轨迹下的新计量噪声。未保存的内部90%集合/分箱保持缺失，后续独立审计可补齐。

数据问题0项；未启动新拟合、规划、潮流或物理仿真。
