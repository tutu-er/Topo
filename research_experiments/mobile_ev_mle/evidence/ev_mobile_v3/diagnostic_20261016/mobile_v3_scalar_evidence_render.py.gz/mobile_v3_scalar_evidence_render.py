"""Render the arithmetic audit without reading another raw record or solving AC."""
from pathlib import Path
import json

out=Path(__file__).resolve().parent
x=json.loads((out/'mobile_v3_scalar_evidence_audit.json').read_text(encoding='utf8'))
target=out/'mobile_v3_scalar_evidence_audit.md'
# The parent requested regeneration of this task's mathematical draft.
lines=[
'# 标量移动方法：既有证据核查',
'',
'结论：主规则 joint_total + label_AIC 下，N3 的 2 条退步、N4 的 1 条改善都来自动作改变后的完整 AC 损失排序。两方法全部候选的校准阈值均为 0，交换阈值不改变任何一条主规则结论。',
'',
'本核查保留 N3/N4 各 48 条独立评价历史，读取全部小投影，另只读三条判别变化的完整 raw。没有重新拟合、重新规划或选择新评价种子。完整逐历史记录、三种拟合口径、四格阈值交换、输入 SHA256 见同名 JSON。',
'',
'## 指标和比较口径',
'',
'令 $u$ 为已保存的 EV 时空功率曲线，正值为充电。$L_k(u)$ 是候选 $k$ 在历史、验证和新增 EV 计量上共享一组线路 R/X 后的标准化残差平方和。$d_k=2m_k$，$m_k$ 是实际线路条数；同接口源的逐时参数在候选间维度相同。',
'',
r'$$S_k(u)=L_k(u)+2d_k,\qquad R_k(u)=S_k(u)-\min_j S_j(u).$$',
'',
r'候选 $k$ 在 $R_k(u)\le c_{k}$ 时保留。这里的维度惩罚是预声明工作指标，阈值由独立校准历史给出。本次主规则所有 $c_k=0$，实际保留最小工作分数的候选。',
'',
r'$$M(u)=\min_{k\ne k_*}L_k(u)-L_{k_*}(u).$$',
'',
'$k_*$ 是评价时使用的真候选。$M$ 越大，完整 AC 拟合下真候选与最接近错误候选的差距越大；它使用全平方和，且没有维度惩罚。',
'',
'标量规划使用另一项预测分数：',
'',
r'$$q_{ab}(u)=\frac12\min_{s_b}\|W[\mu_b(\widehat\theta_b,\widehat P+u,\widehat Q,s_b)-\mu_a(\widehat\theta_a,\widehat P+u,\widehat Q,\widehat s_a)]\|^2,\quad \phi(u)=\frac1K\sum_a\min_{b\ne a}q_{ab}(u).$$',
'',
r'$\widehat\theta_k$ 为每拓扑一组训练 R/X；$\mu_k$ 输出末端电压和根表 P/Q；$W$ 按计量标准差白化；$s_b$ 是竞争者可逐时调整的同接口未计量源。$q$ 使用半平方和，预测未来、固定线路；$M$ 使用实际带噪计量、共享线路重拟合。两者的数值与排序需要分别检查。',
'',
'## 全部评价历史',
'',
'|银行|历史数|实际移动|同固定曲线|预测分数升而实际 M 降|平均 ΔM|主规则固定→移动唯一正确|固定→移动误拒|',
'|---|---:|---:|---:|---:|---:|---:|---:|',
]
for bank,b in x['banks'].items():
    a=b['overall'];m=a['modes']['joint_total']
    lines.append(f"|{bank.upper()}|{a['denominator']}|{a['moved']}|{a['equal_power']}|{a['prediction_actual_M_reversals']}|{a['delta_M']['mean']:.3f}|{m['fixed_categories'].get('unique_correct',0)}→{m['mobile_categories'].get('unique_correct',0)}|{m['fixed_false_reject']}→{m['mobile_false_reject']}|")
lines.extend(['',r'排序反转定义为 $\Delta\phi>10^{-7}$ 且 $\Delta M<-10^{-7}$。N3 有 8/18 个移动计划反转，N4 有 4/34 个；没有预测持平而实际 M 改变的记录。未移动的 44 条保留在总分母中。','',
'四格交换分别用固定/移动损失与固定/移动阈值。主规则的损失贡献正好等于全部结果变化，阈值贡献为 0。固定线路口径的阈值则不同：N3 两种固定线路口径均有 13 条“损失相同、保留集因阈值改变”的记录。故该结论限定于当前主规则；同名 JSON 保留其余两口径的完整分解。','',
'## 按场景、真值和训练长度分层','',
'|银行/分层|分组|历史数|移动数|反转数|平均 M：固定→移动|平均 ΔM|','|---|---|---:|---:|---:|---:|---:|'])
for bank,b in x['banks'].items():
    for group,title in [('by_case','场景'),('by_truth','真值'),('by_H','训练长度')]:
        for key,a in b[group].items():
            lines.append(f"|{bank.upper()}/{title}|{key}|{a['denominator']}|{a['moved']}|{a['prediction_actual_M_reversals']}|{a['fixed_M']['mean']:.3f}→{a['mobile_M']['mean']:.3f}|{a['delta_M']['mean']:.3f}|")
lines.extend(['','上述真值分层仅用于评价归因，规划器接触不到真标签。每组样本较少，保留各组分母，不据此挑选下一轮评价种子。','',
'## 三条主规则判别变化',''])
for b in x['banks'].values():
    for r in b['rows']:
        if 'focus_raw_evidence' not in r:continue
        e=r['focus_raw_evidence'];truth=r['true_name'];f=e['methods']['scalar_fixed'];m=e['methods']['scalar_mobile']
        lines.extend([f"### {r['key']}（index {r['index']}，真值 {truth}，H={r['H']}）",'',
            rf"预测均分 $\phi$：{f['selected_score']:.6f}→{m['selected_score']:.6f}；实际 $M$：{r['fixed_M']:.6f}→{r['mobile_M']:.6f}。计划来源 {f['selected_origin']}→{m['selected_origin']}。",'',
            f"真候选作为参考时的最近预测距离也从 {f['full_AC_predictive']['nearest'][truth]['half_SSE']:.6f} 升到 {m['full_AC_predictive']['nearest'][truth]['half_SSE']:.6f}。",'',
            '|方法|时段功率 kW（节点:功率；0 为零功率）|','|---|---|'])
        for name,p in [('固定',f),('移动',m)]:
            curve=[]
            for row in p['power_kw']:
                nonzero=[f'{j}:{v:.4f}' for j,v in enumerate(row) if abs(v)>1e-8]
                curve.append(','.join(nonzero) or '0')
            lines.append(f"|{name}|{' / '.join(curve)}|")
        lines.extend(['','两计划均从节点 0 开始。移动计划到节点 2，驾驶和接线各占一槽；驾驶能耗 0.2 kWh，工作人员时间合计 30 分钟。时段长度 15 分钟。','',
            '|错误竞争者|固定：训练 / 验证 / EV 损失差|移动：训练 / 验证 / EV 损失差|总差固定→移动|',
            '|---|---:|---:|---:|'])
        for rival,g in f['actual_joint_pair_gaps'].items():
            h=m['actual_joint_pair_gaps'][rival]
            def text(v):return ' / '.join(f"{v[k]:.3f}" for k in ('training','validation','future'))
            lines.append(f"|{rival}|{text(g['blocks'])}|{text(h['blocks'])}|{g['total']:.3f}→{h['total']:.3f}|")
        if r['key']=='remote8_H8:101220010':
            lines.extend(['','固定计划中 clade_12 的原始损失略低于 star，但 star 少 2 个线路参数，工作分数低 3.462。移动后 clade_01 比 star 低 5.825 个原始损失单位，抵扣 4 个维度惩罚单位后仍低 1.825，因而误拒 star。该变化来自损失；阈值全为 0。'])
        elif r['key']=='train8:101220021':
            lines.extend(['','移动后真 clade_01 的原始损失仍比 star 低 0.903，但额外线路带来 4 个工作惩罚单位，所以 star 的工作分数低 3.097。原固定计划对 star 的损失差是 190.015；主要下降来自 EV 段 179.849→0.457。'])
        else:
            lines.extend(['','困难对 clade_01 与 clade_01_23 的总损失差增加 24.789，其中 EV 段增加 20.298，训练与验证段合计增加 4.491。EV 段的差值变化几乎全部来自电压通道。移动同时改变地点、充放电顺序并补充驾驶电量；现有这条记录缺少同曲线搬回原地点的反事实，空间单独贡献仍待诊断。'])
        lines.append('')
lines.extend([
r'三条记录合计 72 个保存的有向源 profile 均成功，源坐标没有命中上下界；最大标准化源 KKT 余量约 $4.2\times10^{-8}$。这支持已求得驻点的数值质量，仍保留局部优化的范围。N3 两条的真参考预测距离也增大，说明“平均目标偏爱容易任务”不足以单独解释它们的退步。',
'',
'## 预测与 AC 接受实际使用的信息',
'',
'1. 训练计量先扣除已校准 P/Q 偏差；有功负荷及功率因数分别做 AR(1) 预测，再由预测有功和功率因数恢复 Q。验证段只作为四步间隔跨过。每候选训练得到的源 P/Q 也分别预测；根电压固定为 1 pu。',
'2. 参考 a 使用自己的预测源生成无噪 AC 响应；竞争 b 固定自己训练的 R/X，仅逐时重拟合同接口源 P/Q，公共源域为 [-0.5,0.5] pu。EV 有功只加入末端总 P 一次；本批 EV 不提供无功。',
'3. scalar 调用没有传入 history_losses，因而没有显式历史似然偏移。训练历史通过 R/X 与预测进入规划。MILP 提案经过全有向对非线性 AC 源拟合，再要求平均最近距离严格提高，才接受。',
'4. 最终 joint_total 同时使用训练、验证和 EV 计量，对线路与源重新联合拟合。预测接受与最终评价是两个不同的模型距离问题；固定参数误差、负荷/源预测误差及重拟合补偿都可能改变动作排序。当前审计明确了差异，尚未分摊各项原因。',
'',
'源码入口（相对本 D-stage）：ev_mobile_v2_design.py:608 调用；ev_systematic_design.py:272–372 标量接受；ev_gradient_flow_design.py:148–212 源 profile；ev_fixed_gradient.py:15–153 源拟合；ev_dynamic_loads.py:161–250 预测；ev_reliability_v2.py:127–141、216–231 工作分数与保留规则。输入及源码 SHA256 已保存于 JSON。',
'',
'## 下一步的预声明诊断规则',
'',
'先在完整旧开发银行的 28 槽上诊断（N3 index 0..19，五种场景/训练长度×四真值；N4 index 0..7，四真值×两种子），保留其原有配对聚类。对已保存的固定和移动曲线，依次拆分线路响应、负荷预测与参考源预测，并比较固定线路与共享线路下的排序。真实轨迹只进入离线归因，选择器仍只用训练。',
'',
'根代理随后另授权最小归因算例：固定使用两银行预先声明的 index 0/12/24/36 共八条代表，再额外保留本报告三条变化例，共 11 个诊断槽。三条变化例仅解释已见错误，不用于新策略的无偏效果估计。分别以训练/真实线路、预测/真实背景、预测/真实参考源形成八种 AC 响应；用三个因素的 Shapley 平均分摊消除替换顺序影响。动作全部取已保存方案，不作真实信息下的最优动作选择。新策略验收仍需重新冻结后使用新的独立校准和评价历史。',
])
target.write_text('\n'.join(lines)+'\n',encoding='utf8')
print(target)
