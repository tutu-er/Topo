"""Arithmetic-only V-channel/compensation supplement to saved v3 diagnostics."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import statistics

OUT=Path(__file__).resolve().parent
paths={k:OUT/v for k,v in dict(response='mobile_v3_error_decomposition.json',parent='mobile_v3_parent_initial_audit.json',scalar='mobile_v3_scalar_evidence_audit.json').items()}
x={k:json.loads(p.read_text(encoding='utf8')) for k,p in paths.items()}
target=OUT/'mobile_v3_response_summary.json'
if target.exists():raise FileExistsError(target)


def stats(v):
    v=list(v)
    return dict(n=len(v),mean=statistics.mean(v),median=statistics.median(v),min=min(v),max=max(v)) if v else dict(n=0)


comp={(r['bank'],r['index']):r for r in x['parent']['training_compensation_diagnostic']}
scalar={(bank,r['index']):r for bank,b in x['scalar']['banks'].items() for r in b['rows']}
rows=[]
for h in x['response']['histories']:
    r=dict(bank=h['physical_bank'],index=h['index'],seed=h['seed'],case_id=h['case_id'],truth=h['true_name'],role=h['role'],actions=[])
    for a in h['actions']:
        if not a['success']:
            r['actions'].append(dict(name=a['name'],success=False,failure=a.get('failure')));continue
        E=a['states']['000']['increment_error']['channels']['v'];N=a['states']['111']['increment_strength']['channels']['v']
        contributions=a['attribution']['increment_error']['v']['contributions']
        assert abs(sum(contributions.values())-E)<=1e-9*(1+abs(E))
        k=dict(name=a['name'],success=True,V_increment_error_SSE=E,V_true_increment_strength_SSE=N,
            V_relative_squared_error=E/N if N else None,V_relative_RMS_error=(E/N)**.5 if N else None,
            V_Sh=contributions,full_V_error_SSE=a['states']['000']['full_response_error']['channels']['v'])
        saved=scalar[r['bank'],r['index']]
        if 'focus_raw_evidence' in saved and a['name'].startswith('scalar'):
            q=saved['focus_raw_evidence']['methods'][a['name']]['full_AC_predictive']['nearest'][r['truth']]['half_SSE']
            k['saved_true_reference_nearest_half_SSE']=q
            k['V_response_error_to_predictive_pair_full_SSE_ratio']=E/(2*q) if q else None
            k['scale_comparison_scope']='Increment reference-response error vs complete future predictive pair distance: same whitened SSE units, different objects; not a distance-error bound.'
        r['actions'].append(k)
    c=comp[r['bank'],r['index']]
    r['training_compensation']=c
    r['V_response_ranking_counts']=h.get('ranking',{}).get('v',{}).get('counts',{})
    rows.append(r)
summary={}
for role in ('predeclared_representative','observed_decision_change_explanation'):
    selected=[r for r in rows if r['role']==role]
    summary[role]=dict(histories=len(selected),methods={})
    for name in ('scalar_fixed','scalar_mobile','square_fixed','square_mobile'):
        actions=[a for r in selected for a in r['actions'] if a['name']==name and a['success']]
        summary[role]['methods'][name]=dict(denominator=len(selected),complete=len(actions),
            V_increment_error_SSE=stats(a['V_increment_error_SSE'] for a in actions),
            V_relative_squared_error=stats(a['V_relative_squared_error'] for a in actions if a['V_relative_squared_error'] is not None),
            V_Sh={f:stats(a['V_Sh'][f] for a in actions) for f in ('lines','background','source')})
edges=[e for r in rows for e in r['training_compensation'].get('edges',[])]
result=dict(schema='mobile_v3_V_response_compensation_supplement_v1',history_denominator=11,action_denominator=44,
    scope='Arithmetic on saved 2^3 AC responses and calibrated training PQ. No new AC/fit/planning/raw read.',
    interpretation='V-only normalization excludes rootP direct EV power, shared across topologies. True-reference response error is not the cause decomposition of wrong-topology refits.',
    source_caution='Small physical source effect on true-model incremental response does not establish weak nuisance-source compensation in competing model fits.',
    compensation=dict(edge_denominator=len(edges),opposite_sign=sum(e['opposite_sign'] for e in edges),
        opposite_sign_and_cancellation_below_point1=sum(e['opposite_sign'] and e['cancellation_ratio'] is not None and e['cancellation_ratio']<.1 for e in edges),
        branchwise_scope='Descriptive 11-history sample, including 3 posthoc explanation cases; no network-independent rate.'),
    summary=summary,rows=rows,inputs={k:dict(path=str(p),sha256=sha256(p.read_bytes()).hexdigest()) for k,p in paths.items()},
    tool_sha256=sha256(Path(__file__).read_bytes()).hexdigest())
target.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,allow_nan=False,indent=2),encoding='utf8')

lines=['# 电压增量响应与训练 R/X 补偿','',
'重点结论使用电压单通道。根有功中 EV 的直接功率在各拓扑近乎相同，会放大总响应平方的分母。因此原 JSON 中 error/total-response² 只保留作核查，不据其小值判断拓扑响应预测准确。','',
r'令 $E_V=\|W_V[\Delta V_{\rm pred}(u)-\Delta V_{\rm true}(u)]\|^2$，$N_V=\|W_V\Delta V_{\rm true}(u)\|^2$；报告 $E_V/N_V$ 及其平方根。两者只比较真候选的增量响应，竞争模型重拟合造成的距离排序仍需单独分析。','',
'|银行/index/真值|方案|电压误差平方 E_V|电压真实响应平方 N_V|E_V/N_V|线路 / 负荷 / 源的电压误差贡献|','|---|---|---:|---:|---:|---:|']
for r in rows:
    for a in r['actions']:
        if not a['success']:continue
        v=a['V_Sh'];lines.append(f"|{r['bank']}/{r['index']}/{r['truth']}|{a['name']}|{a['V_increment_error_SSE']:.5g}|{a['V_true_increment_strength_SSE']:.5g}|{a['V_relative_squared_error']:.5g}|{v['lines']:.5g} / {v['background']:.5g} / {v['source']:.5g}|")
lines.extend(['','八条预声明代表与三条判别变化例的统计分开保存于 JSON，全部 44 动作均保留。三个因素的贡献是六种纠正顺序的平均误差下降，负值代表误差抵消。','',
'在三条判别变化例中，将电压增量误差与预测最近模型的完整平方距离比较，可检查它们是否处于相近量级。它们对应不同的对象，比例仅作量级参照，不构成误差界：','',
'|历史|方案|E_V|预测最近距离 2q|E_V/(2q)|','|---|---|---:|---:|---:|'])
for r in rows:
    for a in r['actions']:
        if 'saved_true_reference_nearest_half_SSE' not in a:continue
        q=a['saved_true_reference_nearest_half_SSE'];lines.append(f"|{r['bank']}/{r['index']}|{a['name']}|{a['V_increment_error_SSE']:.5g}|{2*q:.5g}|{a['V_response_error_to_predictive_pair_full_SSE_ratio']:.5g}|")
lines.extend(['','源因素在真模型电压增量误差中的贡献较小。这涉及源对真实电压增量的物理影响；竞争模型可以重新调源来抵消电压和根表误差，其补偿作用仍可能显著。当前三因素归因没有给出错误模型重拟合排序的因果分摊。','',
'## 训练 R/X 补偿的直接检查','',
r'在径向一阶压降关系中，单支路有 $\Delta(RP+XQ)=P(\delta R+\kappa\delta X)$，其中 $\kappa=Q/P$，$\delta R=R_{\rm train}-R_{\rm true}$，$\delta X=X_{\rm train}-X_{\rm true}$。当训练功率因数变化窄时，$\kappa$ 接近常数，异号的 R/X 误差可能相互抵消。',
'',
r'以每支路训练 $Q/P$ 的中位数为 $\kappa$，记录 $|\delta R+\kappa\delta X|/(|\delta R|+|\kappa\delta X|)$。其值接近零表示当前负荷方向上的压降误差抵消；它不保证 EV 改变 P 后的响应仍准确。',
'',
'各支路 P/Q 使用扣除已校准偏差的训练读数作下游求和，暂略线路损耗；根支路再加该真候选训练得到的同接口源。逐支路 δR、δX、κ 范围、组合量与功率因数范围均保存在 JSON。','',
'|银行/index|训练末端功率因数最小→最大|支路数|异号 R/X 误差|异号且抵消比<0.1|','|---|---:|---:|---:|---:|'])
for r in rows:
    c=r['training_compensation'];e=c.get('edges',[]);pf=c.get('terminal_measured_PF_ranges',[])
    prange=f"{min(v[0] for v in pf):.5f}→{max(v[1] for v in pf):.5f}" if pf else '缺失'
    lines.append(f"|{r['bank']}/{r['index']}|{prange}|{len(e)}|{sum(v['opposite_sign'] for v in e)}|{sum(v['opposite_sign'] and v['cancellation_ratio'] is not None and v['cancellation_ratio']<.1 for v in e)}|")
lines.append('')
target.with_suffix('.md').write_text('\n'.join(lines),encoding='utf8')
print(json.dumps(dict(output=str(target),compensation=result['compensation'],summary=result['summary']),ensure_ascii=False),flush=True)
