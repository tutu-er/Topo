"""Read-only arithmetic on the frozen v2 results; no fitter or solver call."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
from hashlib import sha256
import gzip
import json
from pathlib import Path
import statistics
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent.parent))

from research_experiments.mobile_ev_mle import ev_reliability_v2 as rel
from research_experiments.mobile_ev_mle import ev_systematic_analyze as base


ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'outputs'
TARGET=OUT/'mobile_v3_scalar_evidence_audit.json'
MARKDOWN=OUT/'mobile_v3_scalar_evidence_audit.md'
TOL=1e-7
METHODS=('scalar_fixed','scalar_mobile')
MODES=('fixed_total','fixed_holdout','joint_total')
RULE='label_AIC'
inputs=[]


def read(path):
    path=Path(path);data=path.read_bytes();inputs.append(dict(path=str(path),bytes=len(data),sha256=sha256(data).hexdigest()))
    return json.loads(gzip.decompress(data) if path.suffix=='.gz' else data)


def stats(values):
    values=[float(v) for v in values if v is not None]
    return dict(n=len(values),mean=statistics.mean(values) if values else None,
        median=statistics.median(values) if values else None,min=min(values) if values else None,max=max(values) if values else None)


def decision_view(row):
    return {k:row[k] for k in ('category','false_reject','retained')}


def same_decision(left,right):
    return left['category']==right['category'] and left['false_reject']==right['false_reject'] and set(left['retained'])==set(right['retained'])


def event_effect(cells,event):
    def good(row):return int(row['category']=='unique_correct') if event=='unique_correct' else int(not row['false_reject'])
    ff,mf,fm,mm=[good(cells[k]) for k in ('fixed_loss_fixed_cut','mobile_loss_fixed_cut','fixed_loss_mobile_cut','mobile_loss_mobile_cut')]
    return dict(total_good_change=mm-ff,loss_effect_at_fixed_cut=mf-ff,loss_effect_at_mobile_cut=mm-fm,
        cut_effect_on_fixed_loss=fm-ff,cut_effect_on_mobile_loss=mm-mf,interaction=mm-mf-fm+ff)


def summarize(rows):
    result=dict(denominator=len(rows),complete=sum(r['complete'] for r in rows),
        moved=sum(bool(r['mobile']['moves']) for r in rows),
        equal_power=sum(r['power_matrix_max_difference_kw']<=TOL for r in rows),
        mean_prediction_increases=sum(r['delta_predictive_mean_half_SSE'] is not None and r['delta_predictive_mean_half_SSE']>TOL for r in rows),
        prediction_actual_M_reversals=sum(r['prediction_actual_M_reversal'] for r in rows),
        predicted_tie_actual_M_changes=sum(r['predicted_tie_actual_M_change'] for r in rows),
        fixed_M=stats(r['fixed_M'] for r in rows),mobile_M=stats(r['mobile_M'] for r in rows),
        delta_M=stats(r['delta_M'] for r in rows),delta_predictive_mean_half_SSE=stats(r['delta_predictive_mean_half_SSE'] for r in rows),
        modes={})
    for mode in MODES:
        selected=[r['modes'][mode] for r in rows]
        result['modes'][mode]=dict(denominator=len(rows),
            fixed_categories=dict(Counter(s['cells']['fixed_loss_fixed_cut']['category'] for s in selected)),
            mobile_categories=dict(Counter(s['cells']['mobile_loss_mobile_cut']['category'] for s in selected)),
            fixed_false_reject=sum(s['cells']['fixed_loss_fixed_cut']['false_reject'] for s in selected),
            mobile_false_reject=sum(s['cells']['mobile_loss_mobile_cut']['false_reject'] for s in selected),
            retained_set_changes=sum(set(s['cells']['fixed_loss_fixed_cut']['retained'])!=set(s['cells']['mobile_loss_mobile_cut']['retained']) for s in selected),
            same_relative_scores_cut_only_changes=sum(s['same_relative_scores'] and not same_decision(s['cells']['fixed_loss_fixed_cut'],s['cells']['mobile_loss_mobile_cut']) for s in selected),
            unique_correct={k:sum(s['unique_correct_effects'][k] for s in selected) for k in selected[0]['unique_correct_effects']} if selected else {},
            false_reject_reduction={k:sum(s['false_reject_reduction_effects'][k] for s in selected) for k in selected[0]['false_reject_reduction_effects']} if selected else {})
    return result


def forecast_profile(profile):
    pairs=profile['pairs'];groups=defaultdict(list)
    for pair in pairs:
        assert pair['source_interface']==1 and pair['line_parameters_fixed']
        assert abs(.5*sum(x*x for row in pair['residual'] for x in row)-pair['half_SSE'])<=1e-8*(1+abs(pair['half_SSE']))
        groups[pair['a']].append(pair)
    nearest={a:dict(half_SSE=min(p['half_SSE'] for p in group),
        rivals=[p['b'] for p in group if abs(p['half_SSE']-min(v['half_SSE'] for v in group))<=1e-8]) for a,group in groups.items()}
    value=statistics.mean(r['half_SSE'] for r in nearest.values())
    return dict(success=profile['success'],mean_nearest_half_SSE=value,nearest=nearest,
        pairs=[dict(a=p['a'],b=p['b'],half_SSE=p['half_SSE'],success=p['success'],
            channel_half_SSE=dict(v=.5*sum(x*x for row in p['residual'] for x in row[:-2]),master_p=.5*sum(row[-2]**2 for row in p['residual']),master_q=.5*sum(row[-1]**2 for row in p['residual'])),
            source_p_range=[min(v[0] for v in p['source']),max(v[0] for v in p['source'])],
            source_q_range=[min(v[1] for v in p['source']),max(v[1] for v in p['source'])],
            active_source_coordinates=sum(bool(v) for row in p['active_mask'] for v in row),
            scaled_source_kkt_violation=p.get('scaled_source_kkt_violation'),global_optimality_certified=p.get('global_optimality_certified')) for p in pairs])


def raw_focus(row,record,metadata):
    path=OUT/('mobile_v2_formal_eval_'+row['bank'])/f'case_{record["index"]:03d}_{record["seed"]}.json.gz'
    lite=read(OUT/'mobile_v2_evidence_v1_work/analysis'/('mobile_v2_formal_eval_'+row['bank'])/path.name)
    raw=read(path);assert inputs[-1]['sha256']==lite['delivery_provenance']['raw_sha256']
    methods={m['name']:m for m in raw['methods']};selection=raw['selection']['methods'];answer={}
    truth=row['true_name']
    for name in METHODS:
        method=methods[name];sel=selection[name]['raw'];future=raw['future_records'][method['action_key']]
        assert sel['history_losses'] is None
        assert not any(sel[k] for k in ('uses_truth','uses_validation','uses_future_noise'))
        assert sel['selected_profile']['power_kw']==method['power_kw']
        profile=forecast_profile(sel['selected_profile'])
        assert abs(profile['mean_nearest_half_SSE']-metadata[name]['selected_score'])<=1e-8*(1+abs(metadata[name]['selected_score']))
        comparisons=future['comparisons'];blocks={}
        for candidate,value in comparisons.items():
            post=value['joint']['post'];by_block={k:v['loss'] for k,v in post['blocks'].items()}
            assert abs(sum(by_block.values())-post['loss'])<=1e-7*(1+abs(post['loss']))
            saved=row['modes']['joint_total']['score_details'][('fixed' if name.endswith('fixed') else 'mobile')+'_loss_'+('fixed' if name.endswith('fixed') else 'mobile')+'_cut']['losses'][candidate]
            assert abs(saved-post['loss'])<=1e-7*(1+abs(saved))
            blocks[candidate]=dict(total=post['loss'],blocks=by_block,channels={k:v['channel_loss'] for k,v in post['blocks'].items()},
                R=post['state']['r'],X=post['state']['x'])
        gaps={}
        for candidate in blocks:
            if candidate==truth:continue
            by_block={k:blocks[candidate]['blocks'][k]-blocks[truth]['blocks'][k] for k in blocks[truth]['blocks']}
            gaps[candidate]=dict(total=blocks[candidate]['total']-blocks[truth]['total'],blocks=by_block)
        answer[name]=dict(selected_origin=sel['selected_origin'],selected_score=sel['selected_score'],
            history_losses=sel['history_losses'],information_boundary={k:sel[k] for k in ('uses_truth','uses_validation','uses_future_noise','line_parameters_fixed','one_trained_parameter_vector')},
            initial_best_score=sel['initial_best_score'],operation=method['operation'],power_kw=method['power_kw'],
            full_AC_predictive=profile,actual_joint_candidate_fits=blocks,actual_joint_pair_gaps=gaps,
            grids=[dict(grid_points=g['grid_points'],accepted=g.get('accepted'),before_score=g.get('before_score'),
                raw_AC_score=g.get('raw_AC_score'),selected_score=g.get('selected_score'),rejection_reason=g.get('rejection_reason'),
                frozen_proxy_objective=(g.get('raw') or {}).get('objective'),frozen_proxy_best_bound=(g.get('raw') or {}).get('best_bound')) for g in sel['grids']])
    forecast=raw['forecast'];fit_rows=raw['training_result']['fits']
    return dict(raw_path=str(path),raw_sha256=inputs[-1]['sha256'],config={k:raw['config'].get(k) for k in
        ('horizon','training_points','future_start','forecast','source','profile','public_voltage_repeat_counts','operations')},
        forecast=dict(p=forecast['p'],q=forecast['q'],source_by_candidate=forecast['source_by_candidate'],metadata=forecast['metadata']),
        trained_lines={r.get('candidate',r.get('name')):dict(r=r['r'],x=r['x']) for r in fit_rows},
        true_lines=raw['truth'],methods=answer,
        true_reference_predictive_change=answer['scalar_mobile']['full_AC_predictive']['nearest'][truth]['half_SSE']-answer['scalar_fixed']['full_AC_predictive']['nearest'][truth]['half_SSE'])


if MARKDOWN.exists():raise FileExistsError('Preserve finalized audit; choose a new version')
banks={};all_rows=[];focus=[]
for bank in ('n3','n4'):
    directory=OUT/('mobile_v2_formal_'+bank+'_analysis')
    results=read(directory/'results.json');selection=read(directory/'selection_metadata.json');thresholds=read(directory/'reliability_v2_thresholds.json')
    old_rank=read(directory/'prediction_rank_diagnostic.json')
    phase=rel.read_phase(OUT/'mobile_v2_evidence_v1_work/analysis'/('mobile_v2_formal_eval_'+bank),expected_phase='evaluation')
    assert len(phase['records'])==len(results['by_history'])==48 and len({r['seed'] for r in phase['records']})==48
    lookup={(h['case_id'],h['seed']):h for h in results['by_history']};rows=[]
    for record in phase['records']:
        h=lookup[record['case_id'],record['seed']];meta=selection['rows'][h['key']];methods=base._methods(record)
        f,m=methods['scalar_fixed'],methods['scalar_mobile'];F,M=h['methods']['scalar_fixed'],h['methods']['scalar_mobile']
        delta_predictive=meta['scalar_mobile']['selected_score']-meta['scalar_fixed']['selected_score']
        delta_actual=M['inference']['joint_total']['M']-F['inference']['joint_total']['M']
        row=dict(bank=bank,case_id=record['case_id'],seed=record['seed'],index=record['index'],true_name=record['true_name'],
            H=h['H'],key=h['key'],status=record['status'],complete=F['inference']['joint_total']['complete'] and M['inference']['joint_total']['complete'],
            fixed_M=F['inference']['joint_total']['M'],mobile_M=M['inference']['joint_total']['M'],delta_M=delta_actual,
            delta_predictive_mean_half_SSE=delta_predictive,prediction_actual_M_reversal=delta_predictive>TOL and delta_actual<-TOL,
            predicted_tie_actual_M_change=abs(delta_predictive)<=TOL and abs(delta_actual)>TOL,
            power_matrix_max_difference_kw=max(abs(a-b) for fr,mr in zip(f['power_kw'],m['power_kw']) for a,b in zip(fr,mr)),modes={})
        for tag,name,method,summary in (('fixed','scalar_fixed',f,F),('mobile','scalar_mobile',m,M)):
            row[tag]=dict(selection=meta[name],power_kw=method['power_kw'],operation=method['operation'],
                **{k:summary.get(k) for k in ('moves','driver_minutes','grid_energy_kwh','travel_energy_kwh','throughput_kwh','conversion_loss_kwh','fixed_R_error','fixed_X_error','joint_R_error','joint_X_error')})
        for mode in MODES:
            cuts={name:thresholds['rules'][RULE][name][mode] for name in METHODS}
            cells={};details={}
            for lname in METHODS:
                for cname in METHODS:
                    tag=('fixed' if lname.endswith('fixed') else 'mobile')+'_loss_'+('fixed' if cname.endswith('fixed') else 'mobile')+'_cut'
                    evaluated=rel.decision(record,lname,mode,RULE,cuts[cname]);cells[tag]=decision_view(evaluated)
                    if lname==cname:assert same_decision(cells[tag],h['methods'][lname]['decisions'][RULE][mode])
                    details[tag]=dict(relative=evaluated['relative'],scores=evaluated['scores'],losses=evaluated['losses'])
            parameters,_=rel.candidate_parameters(record)
            named_cuts={name:{candidate:cuts[name][rel.group_key(record,RULE,candidate)] for candidate in parameters} for name in METHODS}
            sf=details['fixed_loss_fixed_cut']['relative'];sm=details['mobile_loss_mobile_cut']['relative']
            same_scores=set(sf)==set(sm) and all(abs(sf[k]-sm[k])<=TOL for k in sf)
            row['modes'][mode]=dict(cells=cells,score_details=details,cutoffs=named_cuts,same_relative_scores=same_scores,
                unique_correct_effects=event_effect(cells,'unique_correct'),false_reject_reduction_effects=event_effect(cells,'false_reject'))
        rows.append(row);all_rows.append(row)
        primary=row['modes']['joint_total']['cells']
        if not same_decision(primary['fixed_loss_fixed_cut'],primary['mobile_loss_mobile_cut']):
            row['focus_raw_evidence']=raw_focus(row,record,meta);focus.append(row)
    grouped={}
    for label,key in (('by_case','case_id'),('by_truth','true_name'),('by_H','H')):
        grouped[label]={str(v):summarize([r for r in rows if r[key]==v]) for v in sorted({r[key] for r in rows},key=str)}
    banks[bank]=dict(overall=summarize(rows),**grouped,rows=rows,analysis_lite_files=phase['files'],
        existing_prediction_rank_file_scope='Existing file diagnoses jointgrad/B only; scalar signs are recomputed here.',
        existing_B_rank_summary=old_rank['overall'])

assert not {r['seed'] for r in banks['n3']['rows']} & {r['seed'] for r in banks['n4']['rows']}
source_entries=[]
for filename in ('ev_systematic_design.py','ev_gradient_flow_design.py','ev_mobile_v2_design.py','ev_fixed_gradient.py','ev_dynamic_loads.py','ev_reliability_v2.py','ev_mobile_v2_results.py'):
    path=ROOT/'research_experiments/mobile_ev_mle'/filename
    source_entries.append(dict(path=str(path),sha256=sha256(path.read_bytes()).hexdigest()))

output=dict(schema='mobile_v3_scalar_existing_evidence_audit_v1',created_utc=datetime.now(timezone.utc).isoformat(),
    scope='Frozen v2 independent evaluation only; no AC solve, parameter fit, action planning, threshold change or new evaluation seed selection.',
    primary=dict(rule=RULE,inference='joint_total',reference='scalar_fixed',challenger='scalar_mobile'),
    banks=banks,focus_keys=[r['key'] for r in focus],all_history_denominator=96,
    formulas=dict(loss='L_k(u): saved full-SSE shared-line AC fit on training+validation+EV.',
        dimension='d_k=2*m_k independently adjustable R/X coordinates; source dimension is common across candidates.',
        relative='R_k(u)=L_k(u)+2*d_k-min_j[L_j(u)+2*d_j]. Candidate k retained iff R_k(u)<=c_method,k.',
        margin='M(u)=min_(k!=true)L_k(u)-L_true(u); full-SSE, truth used after action only.',
        scalar='phi(u)=mean_a min_(b!=a) q_ab(u), q_ab=1/2*min_s ||W[f_b(theta_b,forecast_PQ+u,s)-f_a(theta_a,forecast_PQ+u,source_forecast_a)]||^2.',
        thresholds='Four cells cross fixed/mobile saved loss with fixed/mobile frozen cutoffs; diagnostic attribution only.',
        effect='Good_MM-Good_FF=(Good_MF-Good_FF)+(Good_MM-Good_MF). The alternate path and interaction are also retained.'),
    prediction_scope=dict(lines='One trained R/X vector per topology, held fixed in scalar planning.',
        rival_source='P/Q source coordinates free independently at each future time, common interface1 and common [-.5,.5]pu physical box.',
        observations='P/Q forecast is bias-corrected training-only AR1; Q from predicted P and power factor. Candidate source AR1 fitted to each training source. Root=1pu; EV changes P once; Q unchanged.',
        validation='Not used in forecasts or scalar acceptance; actual joint evaluation includes training, validation and future.',
        history='Scalar call passes no history_losses offset. History enters through trained parameters and forecasts, not an explicit historical likelihood penalty.',
        acceptance='All directed pairs receive complete nonlinear AC source profiles; mean-nearest phi must strictly improve. MILP affine proxy alone does not decide acceptance.',
        optimality='Saved source and line fits are attained local optima; no global profile-MLE certificate.'),
    pilot_rule=dict(membership='Reuse the complete predeclared development bank: n3 indices0..19 and n4 indices0..7. No evaluation seed is promoted to development or selected for favorable outcomes.',
        denominator='28 slots: five n3 case/H regimes times four truths plus four n4 truths times two independent seeds. n3 paired regimes share background seeds and remain clustered.',
        actions='Keep the two already optimized fixed/mobile plans per history; no complete route/action library enumeration and no new action optimization in the diagnostic.',
        axes=['Saved forecast + fixed trained lines + rival source refit (current phi).','Replace forecast P/Q by simulated actual background only as an offline diagnostic; selector remains training-only.','Then replace reference source forecast by simulated actual source only offline, preserving rival source flexibility.','Compare fixed lines with shared history+future line refitting for the same saved actions.','Separate mean-reference tradeoffs from the realized true-reference score; compare noisy saved M and noiseless diagnostic separation.'],
        future_evaluation='After diagnostics and a new policy freeze, use newly declared calibration/evaluation histories disjoint from every v2 evaluation seed.'),
    inspected_source_files=source_entries,source_files=inputs,script_sha256=sha256(Path(__file__).read_bytes()).hexdigest())
TARGET.write_text(json.dumps(output,ensure_ascii=False,sort_keys=True,allow_nan=False,indent=2),encoding='utf-8')
print(json.dumps(dict(path=str(TARGET),focus_keys=output['focus_keys'],banks={k:v['overall'] for k,v in banks.items()}),sort_keys=True),flush=True)
