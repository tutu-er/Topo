# 352槽既有AC物理回放汇总

独立聚合核对：通过。只读取六份既有review报告；未重读raw、未求解、未修改科学源。

|组别|槽数|唯一seed|回放状态|保存状态|AC块回放|原记录规划失败事件/涉及槽|
|---|---:|---:|---|---:|---:|---:|
|original_pilot|4|4|{'passed': 4}|772|1788|0/0|
|original_development|28|16|{'passed': 28}|5660|13136|0/0|
|guard30_development|28|16|{'passed': 28}|3740|9176|16/8|
|guard60_cost_validation|4|4|{'passed': 4}|728|1724|0/0|
|formal_calibration|192|192|{'passed': 192}|33712|79232|18/9|
|formal_evaluation|96|96|{'passed': 96}|14380|34412|15/8|

共352个唯一来源槽，308个唯一seed；其中正式288条历史为192校准、96评价，开发及成本验证64槽另列。所有352槽物理回放passed，原始记录中的失败和回退照常保留。

|检查项目|数量|
|---|---:|
|saved_states_replayed|58992|
|AC_block_replays|139468|
|method_mode_checks|11616|
|source_profile_pair_checks|41028|
|joint_predictive_fit_checks|13826|
|proxy_endpoint_checks|6361920|
|proxy_action_QP_checks|32964|
|gradient_MILP_checks|858|
|operation_replay_checks|3520|
|reference_guard_checks|956|
|reference_guard_MILP_checks|344|

旧32槽属于未加移动底线的源码版本；保护版30秒开发28槽、60秒成本4槽和正式288槽分别归组。三个115文件快照与policy在JSON中分列。旧schema没有的可选检查保持覆盖分母，未自动补成已检查。

|最大误差|值|
|---|---:|
|max_whitened_residual_error|1.03439e-11|
|max_block_SSE_error|4.80213e-10|
|max_AC_equation|5.00905e-16|
|max_power_balance|7.35795e-16|
|max_envelope_price_scaled_error|6.80493e-09|

价格误差是保存拟合点上的包络价格算式回算，未将它计为每次完整重拟合的有限差分验证。QP、MILP和guard数量同样对应保存记录的核算对象。

|原记录中的失败或拒绝|事件数|涉及槽|报告覆盖槽|
|---|---:|---:|---:|
|recorded_planning_failures|49|25|352/352|
|recorded_failed_predictive_pairs|751|120|352/352|
|recorded_inference_failures|2|1|352/352|
|recorded_operation_failures|0|0|352/352|
|recorded_failed_proxy_QPs|0|0|348/352|
|recorded_invalid_proxy_actions|48|46|352/352|
|recorded_incomplete_proxy_tables|3|3|352/352|

规划或预测尝试失败，与已保存合法结果的物理回放失败分开计数；本汇总中的回放失败为0。352槽用于证据覆盖，独立统计结论仍使用正式评价各库48条历史。

聚合JSON SHA256：`84c907073bb70c8b1a9c5203dc10215cdd7e076cc5082b7ca6ec0a2c4460727a`。
