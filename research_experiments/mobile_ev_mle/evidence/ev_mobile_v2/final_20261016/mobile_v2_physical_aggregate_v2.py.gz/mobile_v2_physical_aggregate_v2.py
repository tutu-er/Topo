import json,gzip,base64,hashlib,math
from pathlib import Path,PureWindowsPath
from collections import Counter,defaultdict
from datetime import datetime,timezone
OUT=Path('outputs');JP=OUT/'mobile_v2_full_physical_summary_v2.json';MP=OUT/'mobile_v2_full_physical_summary_v2.md'
if JP.exists() or MP.exists():raise FileExistsError('v2 summary output already exists')
oldpath=OUT/'mobile_v2_full_physical_summary_v1.json';old=json.loads(oldpath.read_text(encoding='utf-8'))
FILES=['mobile_v2_fullpilot_independent_review_stable.json','mobile_v2_development_independent_review_v1.json','mobile_v2_fullreview_a.json','mobile_v2_fullreview_b.json','mobile_v2_fullreview_c.json','mobile_v2_fullreview_cost.json']
CHECK=list(old['overall']['checks']);FAIL=list(old['overall']['recorded_failures']);MAX=list(old['overall']['max_errors']);EXPECTED={k:v['slot_count'] for k,v in old['by_cohort'].items()};errors=[];nchecks=0

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s):return PureWindowsPath(s).as_posix().casefold()
def ck(v,msg):
 global nchecks
 nchecks+=1
 if not v:errors.append(msg)
def cohort(s):
 n=PureWindowsPath(s).name
 for p,k in [('mobile_v2_fullpilot_','original_pilot'),('mobile_v2_dev_','original_development'),('mobile_v2_guard_dev_','guard30_development'),('mobile_v2_guard60_cost_','guard60_cost_validation'),('mobile_v2_formal_cal_','formal_calibration'),('mobile_v2_formal_eval_','formal_evaluation')]:
  if n.startswith(p):return k
 raise ValueError(n)
def agg(rows):
 z={'slot_count':len(rows),'unique_input_path_hash_slots':len({(norm(e['input_path']),e['input_sha256']) for e in rows}),'unique_seed_count':len({e['seed'] for e in rows}),'review_status_counts':dict(Counter(e['status'] for e in rows)),'raw_status_counts':dict(Counter(e['raw_status'] for e in rows)),'phase_counts':dict(Counter(e['phase'] for e in rows)),'candidate_miss_slots':sum(e.get('candidate_miss') is True for e in rows),'checks':{},'recorded_failures':{},'max_errors':{}}
 for k in CHECK+FAIL:
  q=[e for e in rows if e.get(k) is not None]
  if k in CHECK:z['checks'][k]={'count':sum(e[k] for e in q),'reported_slots':len(q),'not_reported_slots':len(rows)-len(q)}
  else:z['recorded_failures'][k]={'event_count':sum(e[k] for e in q),'slots_with_event':sum(e[k]>0 for e in q),'reported_slots':len(q),'not_reported_slots':len(rows)-len(q)}
 for k in MAX:
  e=max(rows,key=lambda e:e[k]);z['max_errors'][k]={'value':e[k],'input_path':e['input_path'],'input_sha256':e['input_sha256'],'cohort':e['cohort'],'case_id':e['case_id'],'seed':e['seed']}
 z['guard_rejections']={k:sum(e.get(k,0) for e in rows) for k in ('reference_guard_rejected_initials','reference_guard_rejected_proposals','reference_guard_legal_fixed_fallbacks')}
 return z
entries=[];inputs=[];versiondirs=defaultdict(set)
for name in FILES:
 p=OUT/name;r=json.loads(p.read_text(encoding='utf-8'));cc=r['cases'];audits={norm(a['directory']):a for a in r['source_audits']}
 ck(r['success'] is True and r['expected_count_matches'] is True and r['case_denominator']==r['expected_case_count']==len(cc),name+' denominator/success')
 ck(dict(Counter(c['status'] for c in cc))==r['status_counts'] and dict(Counter(c['phase'] for c in cc))==r['phase_counts'],name+' grouping')
 ck(len({c['seed'] for c in cc})==r['unique_seed_count'],name+' seeds')
 for k in CHECK:
  if k in r:ck(all(c.get(k) is not None for c in cc) and sum(c[k] for c in cc)==r[k],name+' top sum '+k)
 ck(max(c['max_envelope_price_scaled_error'] for c in cc)==r['max_envelope_price_scaled_error'],name+' max price')
 for a in audits.values():ck(a['success'] is True and a['source_count']==115,name+' source115')
 for c in cc:
  directory=str(PureWindowsPath(c['input_path']).parent);a=audits.get(norm(directory));ck(a is not None,name+' matched source directory')
  if a is None:continue
  ck(c['success'] is True and c['state_review_complete'] is True and c['available_checks_passed'] is True and c['status']=='passed' and not c['errors'] and not c['missing'],name+' complete case '+str(c['index']))
  ck(all(math.isfinite(c[k]) and c[k]>=0 for k in MAX),name+' finite maxima')
  e=dict(c);e.update(review_file=name,source_directory=directory,cohort=cohort(directory),policy_id=a['policy_id'],snapshot_sha256=a['snapshot_sha256']);entries.append(e);versiondirs[(a['policy_id'],a['snapshot_sha256'])].add(norm(directory))
 inputs.append({'path':str(p.resolve()),'sha256':sha(p),'bytes':p.stat().st_size,'case_count':len(cc),'reviewer_sha256':{k:v for k,v in r['independent_tool_sha256'].items() if k.endswith('ev_mobile_v2_review.py')},'scope':r['scope']})
ck(len(entries)==352 and len({(norm(e['input_path']),e['input_sha256']) for e in entries})==352,'352 unique path/hash slots')
ck(len({(e['policy_id'],e['phase'],PureWindowsPath(e['source_directory']).name.split('_n')[1][0],e['case_id'],e['index'],e['seed']) for e in entries})==352,'352 semantic slots')
ck(dict(Counter(e['cohort'] for e in entries))==EXPECTED,'same six cohorts')
formal=[e for e in entries if e['cohort'].startswith('formal_')];nonformal=[e for e in entries if not e['cohort'].startswith('formal_')]
ck(len(formal)==len({e['seed'] for e in formal})==288,'288 formal independent seeds')
for bank,phase,n,seed0 in [('n3','calibration',96,101210001),('n4','calibration',96,101310001),('n3','evaluation',48,101220001),('n4','evaluation',48,101320001)]:
 rr=[e for e in formal if e['phase']==phase and '_'+bank+'_' in PureWindowsPath(e['source_directory']).name+'_'];ck(len(rr)==n and sorted(e['index'] for e in rr)==list(range(n)) and sorted(e['seed'] for e in rr)==list(range(seed0,seed0+n)),bank+'/'+phase+' frozen schedule')
whole=agg(entries);cohorts={k:agg([e for e in entries if e['cohort']==k]) for k in EXPECTED};versions=[]
for (policy,snapshot),dirs in versiondirs.items():
 rr=[e for e in entries if e['policy_id']==policy and e['snapshot_sha256']==snapshot];versions.append({'policy_id':policy,'snapshot_sha256':snapshot,'frozen_source_count':115,'source_directory_count':len(dirs),'cohort_counts':dict(Counter(e['cohort'] for e in rr)),'aggregate':agg(rr)})
for k in CHECK:ck(whole['checks'][k]['count']==old['overall']['checks'][k]['count'],'unchanged core count '+k)
for k in FAIL:ck(whole['recorded_failures'][k]['event_count']==old['overall']['recorded_failures'][k]['event_count'] and whole['recorded_failures'][k]['slots_with_event']==old['overall']['recorded_failures'][k]['slots_with_event'],'unchanged retained failure '+k)
for k in MAX:ck(whole['max_errors'][k]['value']==old['overall']['max_errors'][k]['value'],'unchanged maximum '+k)
ck(whole['recorded_failures']['recorded_failed_proxy_QPs']['reported_slots']==352,'failed-QP coverage352')
legacy=OUT/'mobile_v2_legacy_reviewer_sources_v1.json.gz'
with gzip.open(legacy,'rt',encoding='utf-8') as f:lr=json.load(f)
recover=[]
for target,row in lr['recovered_sources'].items():
 data=base64.b64decode(row['source_base64']);ck(hashlib.sha256(data).hexdigest()==target==row['sha256'] and len(data)==row['bytes'],'exact legacy reviewer recovery')
 recover.append({k:row[k] for k in ('sha256','bytes','commit','git_blob','path','exact_git_blob_bytes')})
current=Path('research_experiments/mobile_ev_mle/ev_mobile_v2_review.py');currenthash=sha(current);required={v for r in inputs for v in r['reviewer_sha256'].values()};available={currenthash,*lr['recovered_sources']}
ck(required<=available,'all selected reviewer hashes recoverable from current bytes or archived git blob')
report=dict(old);report.update(schema='mobile_EV_v2_full_physical_summary_v2',success=not errors,created_utc=datetime.now(timezone.utc).isoformat(),aggregation_checks=nchecks,errors=errors,source_reports=inputs,overall=whole,formal_288=agg(formal),nonformal_64=agg(nonformal),by_cohort=cohorts,by_scientific_source_version=versions)
report['revision']={'previous_summary':str(oldpath.resolve()),'previous_summary_sha256':sha(oldpath),'pilot_report':'mobile_v2_fullpilot_independent_review_stable.json','reason':'Use stable4 whose exact reviewer bytes were recovered; same four raw inputs and all core physical metrics as preserved final4. No AC replay rerun.','old_v1_and_final4_preserved':True,'only_coverage_change':{'field':'recorded_failed_proxy_QPs','v1':348,'v2':352,'failure_count':0}}
report['reviewer_source_recoverability']={'required_sha256':sorted(required),'all_recoverable':required<=available,'current_reviewer':{'path':str(current.resolve()),'sha256':currenthash},'legacy_archive':{'path':str(legacy.resolve()),'sha256':sha(legacy)},'exact_recovered_sources':recover}
with JP.open('x',encoding='utf-8') as f:json.dump(report,f,ensure_ascii=False,sort_keys=True,indent=2);f.write('\n')
lines=['# 352槽AC物理回放汇总 v2','', '改用stable4 pilot报告；其reviewer字节已从Git精确恢复。旧v1汇总与final4报告均保留，没有重跑AC。全部核心检查数量和最大误差与v1相同，失败QP计数覆盖从348增至352槽，计数仍为0。','', '|组别|槽数|唯一seed|保存状态|AC块|规划失败事件/槽|','|---|---:|---:|---:|---:|---:|']
for label,z in cohorts.items():
 f=z['recorded_failures']['recorded_planning_failures'];lines.append(f"|{label}|{z['slot_count']}|{z['unique_seed_count']}|{z['checks']['saved_states_replayed']['count']}|{z['checks']['AC_block_replays']['count']}|{f['event_count']}/{f['slots_with_event']}|")
lines+=['',f"352个唯一来源槽、{whole['unique_seed_count']}个唯一seed，全部物理回放passed。正式192校准＋96评价有288条独立seed；非正式64槽中的重复背景和不同版本单独保留。三种115源码快照及两种实际reviewer字节来源在JSON分列。",'', '|核查项目|次数|','|---|---:|']
for k in ('saved_states_replayed','AC_block_replays','method_mode_checks','source_profile_pair_checks','joint_predictive_fit_checks','proxy_endpoint_checks','proxy_action_QP_checks','gradient_MILP_checks','operation_replay_checks','reference_guard_checks','reference_guard_MILP_checks'):lines.append(f"|{k}|{whole['checks'][k]['count']}|")
lines+=['','旧32槽没有移动guard，相关可选字段保持原schema覆盖分母。包络价格检查是保存拟合点上的公式回算，未当成每次完整重拟合的有限差分检验。','', '|最大误差|值|','|---|---:|']
for k,z in whole['max_errors'].items():lines.append(f"|{k}|{z['value']:.6g}|")
lines+=['', '|原记录中的失败或拒绝|事件数|涉及槽|覆盖槽|','|---|---:|---:|---:|']
for k,z in whole['recorded_failures'].items():lines.append(f"|{k}|{z['event_count']}|{z['slots_with_event']}|{z['reported_slots']}/352|")
lines+=['','规划/预测尝试失败及回退，与保存结果的物理回放失败分开报告。正式校准n4 index64仍保留2次推断失败；正式评价96槽推断失败0。物理回放失败总数0。','',f'JSON SHA256：`{sha(JP)}`。']
with MP.open('x',encoding='utf-8') as f:f.write('\n'.join(lines)+'\n')
print(json.dumps({'success':report['success'],'errors':errors,'checks':nchecks,'slots':352,'reviewer_recoverability':report['reviewer_source_recoverability']['all_recoverable'],'failed_QP_coverage':whole['recorded_failures']['recorded_failed_proxy_QPs'],'json_sha256':sha(JP),'md_sha256':sha(MP)},ensure_ascii=True))
if errors:raise SystemExit(1)
