$ErrorActionPreference = 'Stop'
$taskStage = 'D:\0-github_workspace\Topo\outputs\ev_rx_stage_20261015'
$taskOutput = Join-Path $taskStage 'outputs'
$taskPython = 'D:\apps\miniconda3\envs\Topo\python.exe'
$taskStatePath = Join-Path $taskOutput 'mobile_v2_evidence_run_v1.json'
$taskLockPath = Join-Path $taskOutput 'mobile_v2_evidence_run_v1.lock'
$taskState = @{ status='waiting_statistics'; supervisor_pid=$PID; started_utc=[DateTime]::UtcNow.ToString('o'); steps=@{} }
function Save-TaskState {
    $taskState.updated_utc = [DateTime]::UtcNow.ToString('o')
    [IO.File]::WriteAllText($taskStatePath+'.tmp', ($taskState | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath ($taskStatePath+'.tmp') -Destination $taskStatePath -Force
}
function Run-TaskStep($taskName, $taskArguments) {
    $taskLog = Join-Path $taskOutput ('mobile_v2_evidence_'+$taskName+'_v1.log')
    $taskErrorLog = Join-Path $taskOutput ('mobile_v2_evidence_'+$taskName+'_v1.stderr.log')
    if ((Test-Path -LiteralPath $taskLog) -or (Test-Path -LiteralPath $taskErrorLog)) { throw ('Step logs already exist: '+$taskName) }
    $taskChild = Start-Process -FilePath $taskPython -ArgumentList $taskArguments -WorkingDirectory $taskStage -WindowStyle Hidden -PassThru -RedirectStandardOutput $taskLog -RedirectStandardError $taskErrorLog
    $null = $taskChild.Handle
    $taskState.status = $taskName
    $taskState.steps[$taskName] = @{ pid=$taskChild.Id; started_utc=[DateTime]::UtcNow.ToString('o'); log=$taskLog; stderr=$taskErrorLog }
    Save-TaskState
    $taskChild.WaitForExit(); $taskChild.Refresh()
    $taskState.steps[$taskName].exit_code = $taskChild.ExitCode
    $taskState.steps[$taskName].finished_utc = [DateTime]::UtcNow.ToString('o')
    Save-TaskState
    if ($taskChild.ExitCode -ne 0) { throw ('Step failed: '+$taskName+'; exit='+$taskChild.ExitCode) }
}
$taskLock = $null
try {
    $taskLock = [IO.File]::Open($taskLockPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
    [IO.File]::WriteAllText((Join-Path $taskOutput 'mobile_v2_evidence_run_v1.pid'), [string]$PID)
    Save-TaskState
    while ($true) {
        $taskCheckpoint = Get-Content -LiteralPath (Join-Path $taskOutput 'mobile_v2_orchestration_checkpoint.json') -Raw | ConvertFrom-Json
        if ($taskCheckpoint.status -eq 'failed') { throw 'Statistics controller reports failure; no raw audit started' }
        $taskWorker0 = Get-Content -LiteralPath (Join-Path $taskOutput 'mobile_v2_evaluation_worker0.json') -Raw | ConvertFrom-Json
        $taskWorker1 = Get-Content -LiteralPath (Join-Path $taskOutput 'mobile_v2_evaluation_worker1.json') -Raw | ConvertFrom-Json
        if (($taskCheckpoint.status -eq 'statistical_complete') -and ($taskWorker0.status -eq 'complete') -and ($taskWorker1.status -eq 'complete')) { break }
        Start-Sleep -Seconds 20
    }
    $taskPolicy = '35e7a11ba65a5366930888272f516c3165355f5dbe20de69919734dfd45e23e3'
    if (($taskCheckpoint.policy_id -ne $taskPolicy) -or ($taskWorker0.policy_id -ne $taskPolicy) -or ($taskWorker1.policy_id -ne $taskPolicy)) { throw 'Completion gate policy differs' }
    foreach ($taskTarget in @('mobile_v2_formal_source_cache_owners_v1.json.gz','mobile_v2_evidence_v1','mobile_v2_evidence_v1_work')) {
        if (Test-Path -LiteralPath (Join-Path $taskOutput $taskTarget)) { throw ('Output already exists; refusing overwrite: '+$taskTarget) }
    }
    $taskState.gate_passed_utc = [DateTime]::UtcNow.ToString('o'); Save-TaskState
    Run-TaskStep 'owners' @('-m','research_experiments.mobile_ev_mle.ev_mobile_v2_cache_owner_audit','--directory','outputs/mobile_v2_formal_cal_n3','outputs/mobile_v2_formal_cal_n4','outputs/mobile_v2_formal_eval_n3','outputs/mobile_v2_formal_eval_n4','--expected-count','288','--progress','--output','outputs/mobile_v2_formal_source_cache_owners_v1.json.gz')
    Run-TaskStep 'plan' @('-m','research_experiments.mobile_ev_mle.ev_mobile_v2_pack','--plan')
    Run-TaskStep 'pack' @('-m','research_experiments.mobile_ev_mle.ev_mobile_v2_pack','--raw-root',$taskOutput,'--output',(Join-Path $taskOutput 'mobile_v2_evidence_v1'))
    $taskState.status='complete'; $taskState.finished_utc=[DateTime]::UtcNow.ToString('o'); Save-TaskState
} catch {
    if ($null -ne $taskLock) { $taskState.status='failed'; $taskState.failure=$_.Exception.Message; Save-TaskState }
    throw
} finally {
    if ($null -ne $taskLock) { $taskLock.Dispose() }
}
