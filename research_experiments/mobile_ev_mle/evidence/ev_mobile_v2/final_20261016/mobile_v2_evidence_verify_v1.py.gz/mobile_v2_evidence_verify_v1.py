"""One-off byte verification of the completed D-stage evidence delivery."""
from hashlib import sha256
import json
from pathlib import Path
import tarfile

from research_experiments.mobile_ev_mle import ev_mobile_v2_pack as pack


stage=Path(__file__).resolve().parent.parent
evidence=stage/'outputs/mobile_v2_evidence_v1'
restored=stage/'outputs/mobile_v2_evidence_restore_check_v1'
report_path=stage/'outputs/mobile_v2_evidence_validation_v1.json'
state=json.loads((stage/'outputs/mobile_v2_evidence_run_v1.json').read_text(encoding='utf-8-sig'))
assert state['status']=='complete','pack supervisor must finish first'
assert not restored.exists() and not report_path.exists(),'verification output must be new'
value=json.loads((evidence/'pack_manifest.json').read_bytes())
body=dict(value);identifier=body.pop('manifest_id')
assert pack.delivery.base._object_hash(body)==identifier
assert (value['logical_directories'],value['experiment_slots'])==(14,352)
assert [(d['logical_source'],d['physical_bank'],d['phase'],d['case_count']) for d in value['datasets']]==[
    (name,bank,phase,len(indices)) for name,bank,phase,indices in pack.PLAN]
assert [g['case_count'] for g in value['compact_groups']]==[4,10]
assert len(value['complete_raw']['records'])==2


def digest(stream):
    result=sha256();size=0
    while True:
        chunk=stream.read(1024*1024)
        if not chunk:break
        result.update(chunk);size+=len(chunk)
    return size,result.hexdigest()


for entry in value['packages']:
    path=(evidence/entry['file']).resolve()
    assert path.is_relative_to(evidence.resolve())
    with path.open('rb') as source:measured=digest(source)
    assert measured==(entry['bytes'],entry['sha256'])
    assert entry['bytes']<=20*1024*1024
actual={str(p.relative_to(evidence)).replace('\\','/') for p in (evidence/'bundles').rglob('*') if p.suffix in ('.xz','.bin')}
assert actual=={e['file'] for e in value['packages']}
members_checked=0;case_member_checks=[]
groups=[(evidence/'bundles/analysis'/d['logical_source'],d['bundle_manifest'],d['case_count']) for d in value['datasets']]
groups += [(evidence/'bundles'/g['group'],g['bundle_manifest'],g['case_count']) for g in value['compact_groups']]
for directory,bundle,expected_count in groups:
    assert json.loads((directory/'bundle_manifest.json').read_bytes())==bundle
    case_members=set()
    for archive in bundle['archives']:
        expected={m['file']:m for m in archive['members']};seen=set()
        with tarfile.open(directory/archive['file'],mode='r|xz') as stream:
            for member in stream:
                assert member.isfile() and member.name in expected and member.name not in seen
                source=stream.extractfile(member);entry=expected[member.name]
                assert digest(source)==(entry['bytes'],entry['sha256'])
                seen.add(member.name);members_checked+=1
                if member.name.startswith('case_') and member.name.endswith('.json.gz'):
                    assert member.name not in case_members
                    case_members.add(member.name)
        assert seen==set(expected)
    assert len(case_members)==expected_count
    case_member_checks.append(dict(directory=str(directory.relative_to(evidence)),case_count=len(case_members)))
raw_dir=evidence/'bundles/selected_complete_raw'
assert json.loads((raw_dir/'raw_bundle_manifest.json').read_bytes())==value['complete_raw']['bundle']
raw_result=pack.verify_raw_bundle(raw_dir)
raw_files={r['original_file']:r for r in value['complete_raw']['bundle']['files']}
restored.mkdir();checks=[]
for entry in value['complete_raw']['records']:
    assert entry['phase']=='evaluation' and entry['index']==0
    raw=raw_files[entry['file']];target=restored/entry['file']
    with target.open('xb') as output:
        for part in raw['parts']:
            assert output.tell()==part['offset']
            with (raw_dir/part['file']).open('rb') as source:
                while True:
                    chunk=source.read(1024*1024)
                    if not chunk:break
                    output.write(chunk)
    with target.open('rb') as source:restored_bytes=digest(source)
    with Path(entry['source_path']).open('rb') as source:original_bytes=digest(source)
    assert restored_bytes==original_bytes==(entry['bytes'],entry['sha256'])==(raw['bytes'],raw['sha256'])
    checks.append(dict(bank=entry['physical_bank'],index=0,restored_file=str(target),source_path=entry['source_path'],
        bytes=restored_bytes[0],sha256=restored_bytes[1],original_bytes_identical=True))
assert {r['bank'] for r in checks}=={'n3','n4'}
result=dict(success=True,experiment_slots=352,logical_directories=14,package_count=len(value['packages']),
    package_bytes=sum(e['bytes'] for e in value['packages']),max_package_bytes=max(e['bytes'] for e in value['packages']),
    all_packages_at_most_20MiB=True,tar_member_checks=members_checked,raw_bundle_verification=raw_result,
    delivery_case_member_checks=case_member_checks,analysis_lite_case_members=352,preselected_compact_case_members=14,
    complete_raw_restorations=checks,pack_manifest_id=identifier,verification_script_sha256=sha256(Path(__file__).read_bytes()).hexdigest())
report_path.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,sort_keys=True),flush=True)
