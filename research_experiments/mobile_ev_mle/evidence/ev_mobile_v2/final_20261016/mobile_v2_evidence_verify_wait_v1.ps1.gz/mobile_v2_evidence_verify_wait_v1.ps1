$ErrorActionPreference='Stop'
$taskStage='D:\0-github_workspace\Topo\outputs\ev_rx_stage_20261015'
$taskOutput=Join-Path $taskStage 'outputs'
$taskPidPath=Join-Path $taskOutput 'mobile_v2_evidence_verify_wait_v1.pid'
if (Test-Path -LiteralPath $taskPidPath) { throw 'Verifier watcher already has a PID record; inspect it before retrying' }
[IO.File]::WriteAllText($taskPidPath,[string]$PID)
while ($true) {
    $taskState=Get-Content -LiteralPath (Join-Path $taskOutput 'mobile_v2_evidence_run_v1.json') -Raw | ConvertFrom-Json
    if ($taskState.status -eq 'failed') { throw 'Owner/pack job failed; verification not started' }
    if ($taskState.status -eq 'complete') { break }
    Start-Sleep -Seconds 20
}
$taskPython=Start-Process -FilePath 'D:\apps\miniconda3\envs\Topo\python.exe' -ArgumentList @('-m','outputs.mobile_v2_evidence_verify_v1') -WorkingDirectory $taskStage -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $taskOutput 'mobile_v2_evidence_verify_v1.log') -RedirectStandardError (Join-Path $taskOutput 'mobile_v2_evidence_verify_v1.stderr.log')
$null=$taskPython.Handle
[IO.File]::WriteAllText((Join-Path $taskOutput 'mobile_v2_evidence_verify_v1.pid'),[string]$taskPython.Id)
$taskPython.WaitForExit(); $taskPython.Refresh()
[IO.File]::WriteAllText((Join-Path $taskOutput 'mobile_v2_evidence_verify_v1.exitcode'),[string]$taskPython.ExitCode)
if ($taskPython.ExitCode -ne 0) { throw ('Evidence verification failed, exit='+$taskPython.ExitCode) }
