"""Read-only arithmetic audit of all-past observed finite-pool RNJ/WZZT.

No optimizer, AC solver, physical reference or future observations are imported.
Only aggregate counts, hashes and algorithm decisions are written.
"""
from __future__ import annotations
import argparse,hashlib,json,pickle
from pathlib import Path
import numpy as np
import pandas as pd

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def canonical(family):return tuple(sorted(set(tuple(sorted(map(int,s))) for s in family),key=lambda s:(len(s),s)))
def compatible(family,c):
    c=set(c)
    return all(not(c&set(s)) or c<=set(s) or set(s)<=c for s in family)
def close(a,b,tol=2e-11):
    if not np.isclose(a,b,atol=tol,rtol=1e-10):raise AssertionError((a,b))

def frames(scenes):
    allowed={'name','P_terminal','Q_terminal','V_terminal','V_root_observed','drop_target','units'}
    outputs=[[],[],[],[]];names=[]
    for s in scenes:
        assert set(s)==allowed,('unexpected scene fields',set(s)-allowed)
        assert s['units']=={'P_terminal':'pu','Q_terminal':'pu','V_terminal':'pu','V_root_observed':'pu','drop_target':'pu2'}
        p,q,v,root=[s[k] for k in ('P_terminal','Q_terminal','V_terminal','V_root_observed')]
        assert isinstance(p,pd.DataFrame) and isinstance(root,pd.Series)
        assert p.index.is_unique and p.index.is_monotonic_increasing and len(p)==24
        assert list(p.index.hour)==list(range(24))
        assert root.index.equals(p.index) and all(z.index.equals(p.index) and z.columns.equals(p.columns) for z in (q,v))
        assert all(np.isfinite(z.to_numpy()).all() for z in (p,q,v,root))
        expected=root.to_numpy()[:,None]**2-v.to_numpy()**2
        assert np.array_equal(expected,s['drop_target'].to_numpy())
        assert s['drop_target'].index.equals(p.index) and s['drop_target'].columns.equals(p.columns)
        for target,z in zip(outputs,(p,q,v,root),strict=True):target.append(z)
        names.append(s['name'])
    obs=tuple(pd.concat(x,axis=0) for x in outputs)
    assert obs[0].index.is_unique and obs[0].index.is_monotonic_increasing and len(set(names))==len(names)
    return obs

def input_hash(obs):
    h=hashlib.sha256()
    for z in obs:h.update(pd.util.hash_pandas_object(z,index=True).values.tobytes())
    h.update(json.dumps(list(obs[0].columns),default=str).encode())
    h.update(json.dumps([str(t) for t in obs[0].index.normalize()]).encode())
    return h.hexdigest()

def matrices(n,p):
    out=[]
    for key in ('r','x'):
        m=np.zeros((n,n))
        for s,w in zip(p['supports'],p[key],strict=True):m[np.ix_(s,s)]+=w
        out.append(m)
    return out

def loss(obs,point):
    p,q,v,root=obs;r,x=matrices(p.shape[1],point)
    y=root.to_numpy()[:,None]**2-v.to_numpy()**2
    return float(np.mean(np.abs(p.to_numpy()@r.T+q.to_numpy()@x.T-y)))

def audit(root):
    root=Path(root);protocol=read(root/'protocol_history.json');result=read(root/'history_fit/result.json')
    assert result['status']=='complete'
    for path,h in protocol['source_sha256'].items():assert sha(path)==h,('frozen source',path)
    for path,h in protocol['input_sha256'].items():assert sha(path)==h,('frozen input',path)
    packet=pickle.loads(Path(protocol['private_packet']).read_bytes())
    assert set(packet)=={'training','validation','metadata'}
    train=frames(packet['training']);valid=frames(packet['validation'])
    expected=['2021-01-25','2021-01-26','2021-01-27','2021-01-28','2021-01-29','2021-02-01','2021-02-02','2021-02-03','2021-02-04','2021-02-05']
    trdates=list(dict.fromkeys(train[0].index.strftime('%Y-%m-%d')));vadates=list(dict.fromkeys(valid[0].index.strftime('%Y-%m-%d')))
    assert trdates==expected[:-1] and vadates==expected[-1:]
    assert len(train[0])==216 and len(valid[0])==24 and train[0].index.intersection(valid[0].index).empty
    assert train[0].columns.equals(valid[0].columns) and list(train[0].columns)==result['terminal_labels']
    assert max(trdates+vadates)<packet['metadata']['information_cutoff']
    assert packet['metadata']['all_available_past_dates']==expected and packet['metadata']['forecast_dates']==expected
    hashes={'training':input_hash(train),'validation':input_hash(valid)}
    assert hashes==result['input_sha256']==protocol['normalized_input_sha256']
    assert result['source_sha256']=={k:v for k,v in protocol['source_sha256'].items() if not k.endswith('dr_decision_audit\\history.py')}
    points=result['selection_candidates'];point_records=[]
    for i,p in enumerate(points):
        tr,va=loss(train,p),loss(valid,p);close(tr,p['objective']);close(va,p['validation_mae'])
        assert canonical(p['supports'])==tuple(map(tuple,p['supports']))
        assert all(compatible(p['supports'][:j],s) for j,s in enumerate(p['supports']))
        assert all(w>=0. for key in ('r','x') for w in p[key])
        point_records.append(dict(index=i,origin=p.get('origin'),config=p.get('config'),path_index=p.get('path_index'),
            supports=len(p['supports']),training_mae=tr,validation_mae=va))
    cal=result['calibrations']['raw'];selection=[]
    for name in ('rnj_bank','baseline25','multistart_original_rule'):
        pool=result['bank'] if name=='rnj_bank' else [p for p in points if p.get('origin') in ('tree_bank','tree_initialized_correction')] if name=='baseline25' else points
        b=min(p['validation_mae'] for p in pool)
        elig=[i for i,p in enumerate(pool) if p['validation_mae']<=1.03*b+1e-12]
        chosen_i=min(elig,key=lambda i:(len(pool[i]['supports']),pool[i]['validation_mae'],i));chosen=pool[chosen_i]
        mask=[i for i,s in enumerate(chosen['supports']) if len(s)==1 or cal['a']*chosen['r'][i]+cal['b']*chosen['x'][i]+1e-10>=.16*cal['median_root_depth']]
        saved=result['models'][name]
        for k in ('supports','r','x'):
            want=[chosen[k][i] for i in mask]
            if k=='supports':assert saved[k]==want
            else:np.testing.assert_allclose(saved[k],want,rtol=0,atol=1e-12)
        close(saved['selection_validation_mae'],chosen['validation_mae'])
        close(saved['train_mae'],loss(train,saved));close(saved['validation_mae'],loss(valid,saved))
        assert saved['selected_origin']==chosen.get('origin')
        rr,xx=matrices(train[0].shape[1],saved)
        np.testing.assert_allclose(saved['R'],rr,rtol=0,atol=1e-12);np.testing.assert_allclose(saved['X'],xx,rtol=0,atol=1e-12)
        selection.append(dict(method=name,index=chosen_i,eligible=len(elig),best_validation=b,
            threshold=1.03*b+1e-12,selected_origin=saved['selected_origin'],selected_config=saved.get('config'),
            before_supports=len(chosen['supports']),after_supports=len(saved['supports']),post_contraction_validation=saved['validation_mae']))
    lp_records=result['LP_solves'];lp_lookup={canonical(r['family']):r for r in lp_records}
    assert len(lp_lookup)==len(lp_records)
    for r in lp_records:
        assert r['status']==2 and r['accepted'] and r['max_constraint_violation']<=1e-7 and r['max_bound_violation']<=1e-7
        close(r['objective'],r['physical'])
    paths=[];pool=canonical(result['pool_support_indices'])
    for name,s in result['searches'].items():
        assert s['reason']=='pool_local_optimum';cross=0;accepted=0;decisions=[]
        for i,d in enumerate(s['decisions']):
            current=s['path'][i];family=canonical(current['supports']);close(d['current'],loss(train,current))
            expected_candidates=[c for c in pool if len(c)>=2 and c not in family]
            assert d['full_sweep'] and [tuple(c['candidate']) for c in d['candidates']]==expected_candidates
            best=None;best_record=None
            for c in d['candidates']:
                candidate=tuple(c['candidate']);retained=[f for f in family if compatible([f],candidate)]
                removed=[f for f in family if f not in retained];assert list(map(list,removed))==c['removed']
                proposal=canonical([*retained,candidate]);close(c['objective'],lp_lookup[proposal]['objective'])
                if best is None or c['objective']<best-1e-12:best=c['objective'];best_record=c
            gain=0. if best is None else d['current']-best;close(d['gain'],gain)
            threshold=1e-10+.001*d['current'];accept=best is not None and gain>threshold
            if accept:
                accepted+=1;cross+=bool(best_record['removed']);assert i+1<len(s['path']);close(s['path'][i+1]['objective'],best)
                allowed=canonical([*[f for f in family if compatible([f],best_record['candidate'])],best_record['candidate']])
                assert set(canonical(s['path'][i+1]['supports']))<=set(allowed)
            else:assert i==len(s['decisions'])-1 and i==len(s['path'])-1
            decisions.append(dict(iteration=i,current=d['current'],best_candidate=None if best_record is None else best_record['candidate'],
                removed=None if best_record is None else best_record['removed'],gain=gain,threshold=threshold,accepted=accept,candidate_count=len(d['candidates'])))
        assert accepted==len(s['path'])-1
        paths.append(dict(name=name,path_points=len(s['path']),accepted=accepted,crossing_acceptances=cross,reason=s['reason'],decisions=decisions))
    output=dict(status='passed',scope='observed-only history coverage, stored-point raw-L1 and finite-pool decision/selection arithmetic',
        no_solver_or_AC_or_truth_read=True,optimizer_calls=0,AC_calls=0,training_dates=trdates,validation_dates=vadates,
        training_rows=len(train[0]),validation_rows=len(valid[0]),future_values_accessed=False,normalized_input_sha256=hashes,
        source_files_verified=len(protocol['source_sha256']),input_files_verified=len(protocol['input_sha256']),
        LP_receipts_checked=len(lp_records),point_objectives_replayed=len(points),selection=selection,paths=paths,point_records=point_records,
        limitations=['Candidate LP objectives without saved coefficient vectors checked against stored solver receipts, not independently re-solved.',
                     'Finite training-generated pool, not all supports or globally optimal topology.',
                     'No assessment of physical truth or new DR efficacy.'],audit_source_sha256=sha(__file__))
    (root/'audit_history.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:output[k] for k in ('status','training_rows','validation_rows','LP_receipts_checked','point_objectives_replayed','selection','paths')},ensure_ascii=False))
    return output

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--root',type=Path,required=True);args=a.parse_args();audit(args.root)
