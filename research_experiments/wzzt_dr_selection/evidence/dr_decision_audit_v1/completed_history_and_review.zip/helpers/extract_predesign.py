"""Extract states/forecast hypotheses from observed baseline only; no new fit."""
from pathlib import Path
import hashlib,json

ROOT=Path(r'C:\Users\23761\.codex\visualizations\2026\10\25\01a1726e-8ec7-7bc1-9f18-391f9cf79a1a\wzzt_dr_decision_v1')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def family(p):return tuple(tuple(s) for s in p['supports'])
def compatible(a,b):
    aa,bb=set(a),set(b)
    return not(aa&bb) or aa<=bb or bb<=aa
def parameter_point(p):return {key:p[key] for key in ('supports','r','x')}

d=read(ROOT/'history_fit/result.json');points=d['selection_candidates'];chosen=d['models']['multistart_original_rule']['selected_uncontracted']
best=min(p['validation_mae'] for p in points);eligible=[(i,p) for i,p in enumerate(points) if p['validation_mae']<=1.03*best+1e-12]
unique=[];seen=set()
for i,p in eligible:
    key=family(p)
    if key in seen:continue
    seen.add(key);unique.append((i,p))
base=set(family(chosen));extra=sorted(set(s for _,p in unique for s in family(p))-base,key=lambda s:(len(s),s))
all_nested=all(base<=set(family(p)) for _,p in unique)
all_extra_laminar=all(compatible(a,b) for i,a in enumerate(extra) for b in extra[i+1:])
alternatives=[(i,p) for i,p in enumerate(points) if family(p)!=family(chosen)]
non_same=None if not alternatives else min(alternatives,key=lambda item:(item[1]['validation_mae'],len(item[1]['supports']),item[0]))
states=[];index={}
def add_state(point,origin):
    key=family(point)
    if key in index:states[index[key]]['origins'].append(origin);return
    index[key]=len(states);states.append(dict(id=len(states),origins=[origin],**parameter_point(point)))
add_state(chosen,dict(rule='final_selected_uncontracted'))
if non_same is not None:add_state(non_same[1],dict(rule='best_validation_nonidentical_family',selection_candidate_index=non_same[0]))
first_cross=None
for name,path in d['searches'].items():
    for i,decision in enumerate(path['decisions']):
        winner=None
        for c in decision['candidates']:
            if winner is None or c['objective']<winner['objective']-1e-12:winner=c
        if winner is not None and decision['gain']>1e-10+.001*decision['current'] and winner['removed']:
            first_cross=(name,i,path['path'][i]);break
    if first_cross:break
if first_cross:add_state(first_cross[2],dict(rule='first_actual_cross_before',path=first_cross[0],path_index=first_cross[1]))
for name,path in d['searches'].items():add_state(path['path'][-1],dict(rule='actual_stop',path=name,path_index=len(path['path'])-1))
generators=[dict(id=0,rule='final_selected_uncontracted',**parameter_point(chosen))]
if non_same is not None:generators.append(dict(id=1,rule='best_validation_nonidentical_family',selection_candidate_index=non_same[0],**parameter_point(non_same[1])))
out=dict(scope='predesign observed-only finite-pool arithmetic; no solver/AC/future/truth',
    result_sha256=sha(ROOT/'history_fit/result.json'),audit_history_sha256=sha(ROOT/'audit_history.json'),
    eligible_unique_families=len(unique),eligible_all_supersets_of_selected=all_nested,
    eligible_extra_support_indices=[list(s) for s in extra],
    eligible_extra_support_labels=[[d['terminal_labels'][i] for i in s] for s in extra],
    eligible_extras_mutually_laminar=all_extra_laminar,
    eligible_families=[dict(selection_candidate_index=i,origin=p.get('origin'),config=p.get('config'),
         validation_mae=p['validation_mae'],additional_supports=[list(s) for s in set(family(p))-base],
         absent_selected_supports=[list(s) for s in base-set(family(p))]) for i,p in unique],
    first_actual_crossing_acceptance=None if first_cross is None else dict(path=first_cross[0],index=first_cross[1]),
    states=states,generator_points=generators,
    candidate_replay_rule='For each fixed state, test every pool support of size>=2 absent from current state; remove every crossing state support; jointly refit all R/X from zero with the same declared domain; preserve all ties and failure.',
    selected_model_self_prediction_lemma=dict(assumptions=['current point is globally optimal in its historical fixed-support L1 fit',
        'future target generated exactly by the same current point at arbitrary future P/Q',
        'same parameter domains and raw mean absolute error; old observations retained unchanged'],
        derivation='Let w=Nh/(Nh+Nf). Jnew(F0)=w Jhist(F0); for every candidate H, Jnew(H)>=w Jhist(H); hence gain_new(H)<=w gain_hist(H). If historical gain<=a+bJhist(F0), gain_new<=wa+bJnew(F0)<=a+bJnew(F0), a>=0.',
        conclusion='Every previously rejected candidate remains rejected for any price/response under this exact self-prediction; no LP batch is needed to prove it.',
        a=1e-10,b=.001,
        limits='Does not apply when future data use another parameter/model, new noise or nonlinear AC mismatch. Those are explicitly conditional model tests and require no-DR control.'),
    nesting_lemma='For any appended observations and any nested F0 subset F1 with new block weights permitted zero, J(F1)<=J(F0). Pure strict training improvement cannot prefer deletion; validation/contraction must be examined.',
    interpretation='No 3%-eligible nonnested/crossing family competition in current history. Do not fabricate a cross mechanism by treating rejected X-families as equally plausible or claim finite-pool uniform information impossibility.',
    planned_numeric_replay_status='not started; stop exact selected-model self-prediction branch mathematically; alternative-generator test requires explicit conditional scope',
    source_sha256=sha(__file__))
(ROOT/'predesign_findings.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:out[key] for key in ('eligible_unique_families','eligible_all_supersets_of_selected','eligible_extra_support_labels','eligible_extras_mutually_laminar','first_actual_crossing_acceptance')},ensure_ascii=False))
print('unique_states',len(states),'generators',len(generators))
