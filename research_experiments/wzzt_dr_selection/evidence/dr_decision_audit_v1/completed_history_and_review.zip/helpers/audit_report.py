"""Read-only review receipts for nested-family contraction and DR menu counts."""
from pathlib import Path
import hashlib,json,math

ROOT=Path(r'C:\Users\23761\.codex\visualizations\2026\10\25\01a1726e-8ec7-7bc1-9f18-391f9cf79a1a\wzzt_dr_decision_v1')
REPORT=Path(r'C:\Users\23761\.codex\worktrees\wzzt-dr-selection\Topo\research_experiments\wzzt_dr_selection\dr_decision_audit\REPORT.md')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fam(p):return tuple(tuple(s) for s in p['supports'])
d=read(ROOT/'history_fit/result.json');points=d['selection_candidates'];labels=d['terminal_labels'];cal=d['calibrations']['raw']
selected=d['models']['multistart_original_rule'];base=fam(selected);threshold=.16*cal['median_root_depth']
best=min(p['validation_mae'] for p in points);seen=set();records=[]
for i,p in enumerate(points):
    if p['validation_mae']>1.03*best+1e-12 or fam(p) in seen:continue
    seen.add(fam(p));keep=[];extra=[]
    for j,(s,r,x) in enumerate(zip(p['supports'],p['r'],p['x'],strict=True)):
        depth=cal['a']*r+cal['b']*x
        retained=len(s)==1 or depth+1e-10>=threshold
        if retained:keep.append(tuple(s))
        if tuple(s) not in set(base):extra.append(dict(support_indices=s,support_labels=[labels[k] for k in s],
            r=r,x=x,positive_effect=max(r,x)>1e-9,normalized_depth=depth,output_threshold=threshold,retained=retained))
    assert tuple(keep)==base
    effective=[s for s,r,x in zip(keep,[p['r'][j] for j,s in enumerate(p['supports']) if tuple(s) in keep],
        [p['x'][j] for j,s in enumerate(p['supports']) if tuple(s) in keep],strict=True) if max(r,x)>1e-9]
    assert tuple(effective)==base
    records.append(dict(selection_candidate_index=i,config=p.get('config'),origin=p.get('origin'),
        before_supports=len(p['supports']),after_supports=len(keep),after_effective_supports=len(effective),
        contracted_supports_equal_selected=True,added_raw_blocks=extra))
assert len(records)==5
coeff=[1,0,0,0,0]
for slot in range(30):coeff=[sum(coeff[k-j] for j in range(3) if k-j>=0) for k in range(5)]
counts=dict(all_feasible=sum(coeff),one_node=1+15*(3**2-1),identical_both_rounds=1+15+15+math.comb(15,2))
assert counts==dict(all_feasible=45446,one_node=121,identical_both_rounds=136)
max_coeff=max(w for p in points for key in ('r','x') for w in p[key])
result=dict(status='passed',scope='report mathematics reviewed; contraction and menu arithmetic independently replayed, no fit/AC/truth',
    report_sha256=sha(REPORT),fit_sha256=sha(ROOT/'history_fit/result.json'),audit_script_sha256=sha(__file__),
    contraction_threshold=threshold,eligible_families=records,max_coefficient_in_21_stored_candidate_points=max_coeff,
    menu_counts=counts,menu_coefficients_cost0_to4=coeff,
    both_rounds_two_node_synchronous=dict(price_each=1,price_unit_sum_training=4,worst_payment=1.6,
        independent_train_Bernoulli=4,independent_validation_Bernoulli=4,independent_joint_patterns=256),
    same_sync_if_price2=dict(price_unit_sum_training=8,worst_payment=3.2,feasible=False),
    alternative_single_round_two_node_sync=dict(price_each=2,price_unit_sum_training=4,worst_payment=1.6,
        independent_train_Bernoulli=2,independent_validation_Bernoulli=2,independent_joint_patterns=16,
        scope='different schedule: second train and second validation events unrewarded; do not mix with both-round synchronous policy'),
    self_prediction_lemma_review=dict(valid=True,conditions=['historical fixed-family global LP optimum',
        'same parameter domain, candidate family and per-observation weights',
        'old observations retained unchanged; future raw L1 target generated exactly by same optimum',
        'acceptance threshold a+bJ with a>=0',
        'w uses scalar observation counts; equals time-row ratio here because same terminal count in all rows'],
        not_claimed=['real DR is ineffective','all models or newly rebuilt candidate pools excluded','statistical confidence coverage',
                     'AC/noise mismatched future follows exact self-prediction']),
    scope_checks=['5 eligible families arise from algorithm 3% rule, not a confidence set',
        'all 5 current raw points contract to same 21-support family, but coefficients differ',
        'positive effects below output threshold remain positive effects; do not remove true weak lines from evaluation',
        'future re-estimation can move coefficients across threshold; current contraction is not permanent non-identifiability'],
    minor_wording_suggestion='REPORT says all stored candidates maximum coefficient; more precise is 21 stored candidate points, not all 83 LPs whose full coefficients are unavailable.',
    solver_calls=0,AC_calls=0)
(ROOT/'audit_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=result['status'],threshold=threshold,contracted_equal=5,total=5,
    maximum_coefficient=max_coeff,menu_counts=counts,report_sha256=result['report_sha256'])))
