"""Independent saved-evidence audit; no project/producer/controller imports.

Writing/importing this file never reads actual data. Run only after root confirms
the frozen actual root is complete, with explicit --allow-actual-read. No source
profile generation, AC, QP, LP, inference or solver calls occur here.
"""
from __future__ import annotations
import argparse
import ast
from collections import Counter
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import pickle
import traceback
import numpy as np
import pandas as pd

FIELDS=('P_terminal','Q_terminal','V_terminal','V_root_observed')
UNITS={k:'pu' for k in FIELDS}|{'drop_target':'pu2'}
TOL=1e-10

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fingerprint(x): return hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest()

class Audit:
    def __init__(self): self.checks=[];self.notes=[];self.numeric={}
    def check(self,name,condition,**detail):
        self.checks.append(dict(name=name,pass_=bool(condition),**detail))
    def close(self,name,a,b,tol=TOL):
        a,b=np.asarray(a),np.asarray(b)
        difference=float(np.max(np.abs(a-b),initial=0)) if a.shape==b.shape else None
        self.check(name,difference is not None and difference<=tol,max_abs_difference=difference,tolerance=tol)
    def maximum(self,name,value): self.numeric[name]=max(float(value),self.numeric.get(name,0.))

def old_scenes(row):
    """Decode the two saved past NPZ splits directly, without the producer."""
    answer={}
    for role,offset in (('train',0),('validation',3)):
        p=Path(row[role]['path']);expected=row[role].get('catalog_sha256',row[role].get('sha256'))
        if sha(p)!=expected: raise ValueError('past NPZ hash mismatch '+str(p))
        with np.load(p,allow_pickle=False) as f:
            labels=f['labels'].astype(int).tolist()
            raw={k:np.asarray(f[k],float) for k in ('P','Q','V','root')}
        if any(raw[k].shape!=(3,96,len(labels)) for k in ('P','Q','V')) or raw['root'].shape!=(3,96):
            raise ValueError('past split is not all three96-row days')
        days=[]
        for i in range(3):
            index=pd.date_range(pd.Timestamp('2000-01-01')+pd.Timedelta(days=offset+i),periods=96,freq='15min')
            p,q,v=[pd.DataFrame(raw[k][i],index=index,columns=labels) for k in ('P','Q','V')]
            root=pd.Series(raw['root'][i],index=index,name='V_root_measured')
            days.append(dict(P_terminal=p,Q_terminal=q,V_terminal=v,V_root_observed=root,
                units=dict(UNITS),drop_target=pd.DataFrame(root.to_numpy()[:,None]**2-v.to_numpy()**2,index=index,columns=labels)))
        answer['training' if role=='train' else 'validation']=days
    return answer,labels

def combine(scenes):
    frames=tuple(pd.concat([s[k] for s in scenes],axis=0) for k in FIELDS)
    if not frames[0].index.is_unique or not frames[0].index.is_monotonic_increasing:
        raise ValueError('observations are not unique chronological rows')
    day_ids=[str(v) for v in frames[0].index.normalize()]
    h=hashlib.sha256()
    for frame in frames: h.update(pd.util.hash_pandas_object(frame,index=True).values.tobytes())
    h.update(json.dumps(list(frames[0].columns),default=str).encode())
    h.update(json.dumps(day_ids).encode())
    return frames,day_ids,h.hexdigest()

def available_scenes(history,packet,checkpoint):
    training=list(history['training']);validation=list(history['validation'])
    ids=packet['metadata']['training_event_ids']
    if checkpoint=='early':
        if ids.count(0)!=1: raise ValueError('event0 missing, later event may not replace it')
        first=packet['training'][ids.index(0)]
        trimmed={k:first[k].iloc[:84].copy() for k in FIELDS}
        trimmed.update(units=dict(first['units']),drop_target=first['drop_target'].iloc[:84].copy())
        training.append(trimmed)
    elif checkpoint=='final':
        if ids!=[0,1] or packet['metadata']['validation_event_ids']!=[2,3]:
            raise ValueError('final event order/availability mismatch')
        training+=packet['training'];validation+=packet['validation']
    else: raise ValueError('unknown checkpoint')
    return training,validation

def waveform(template,directions,active_positions):
    direction=np.asarray(directions,int)
    if not np.isin(direction,[-1,0,1]).all(): raise ValueError('invalid direction')
    base=np.tile(np.array([-.2]*4+[.2]*4)[:,None],(1,len(direction)))
    if template=='alternating_opposed': base[:,active_positions]=np.array([-.2,.2]*4)[:,None]
    elif template not in ('same','opposed'): raise ValueError('unknown template')
    return base*direction[None,:]

def expected_participants(price,event,law,seed,path):
    rng=np.random.default_rng(np.random.SeedSequence([int(seed),int(path),int(event)]))
    uniform=rng.random(len(price)) if law=='local' else np.repeat(rng.random(),len(price))
    return uniform<np.array([0.,.5,.75])[np.asarray(price,int)]

def paper15_family(source_root):
    """Parse static edge endpoints/positive library coefficients, then own BFS.

    No network constructor or profile function is imported or executed. This
    source feeder has all-positive physical edges; no threshold removes weak
    edges. A changed/zero library makes this audit unresolved instead of silently
    applying the positive-edge assumption to a different network.
    """
    path=Path(source_root)/'rnj_wzzt/data/paper_style_terminal_lv.py'
    tree=ast.parse(path.read_text(encoding='utf-8'))
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='build_paper_style_terminal_lv_case')
    assignments={n.targets[0].id:n.value for n in fn.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
    constants={k:float(ast.literal_eval(assignments[k])) for k in ('overhead_r_km','overhead_x_km','service_r_km','service_x_km','impedance_scale')}
    if min(constants.values())<=0: raise ValueError('static feeder has zero/negative library; positivity not certified by this parser')
    edges=[];edge_parameters={}
    for item in assignments['edge_specs'].elts:
        u,v=ast.literal_eval(item.elts[0]),ast.literal_eval(item.elts[1])
        call=item.elts[2].value
        if not isinstance(call,ast.Call) or not isinstance(call.func,ast.Name) or call.func.id!='z':
            raise ValueError('unrecognized edge impedance expression')
        if any(not isinstance(a,ast.Name) or constants.get(a.id,0)<=0 for a in call.args[:2]) or ast.literal_eval(call.args[2])<=0:
            raise ValueError('edge positivity unresolved')
        edges.append((int(u),int(v)))
        length=float(ast.literal_eval(call.args[2]))
        # Frozen reference context explicitly rescales builder5 to target1.
        zbase=.4**2/.2
        edge_parameters[f'{int(u)}->{int(v)}']=[constants[call.args[0].id]*length/1000/zbase,
                                             constants[call.args[1].id]*length/1000/zbase]
    terminals=[int(ast.literal_eval(item.elts[0])) for item in assignments['terminal_specs'].elts]
    children={};parents={}
    for u,v in edges:
        if v in parents: raise ValueError('not a rooted tree')
        parents[v]=u;children.setdefault(u,[]).append(v)
    root=int(ast.literal_eval(assignments['root']))
    def descendants(node):
        answer={node} if node in terminals else set()
        for child in children.get(node,[]): answer |= descendants(child)
        return answer
    family={tuple(sorted(descendants(v))) for u,v in edges}
    if () in family or descendants(root)!=set(terminals): raise ValueError('tree/terminal parser mismatch')
    return family,terminals,dict(path=str(path),sha256=sha(path),positive_edges=len(edges),root=root,
        physical_target_impedance_scale=1.,edge_parameters_pu=edge_parameters)

def physical_equations(a,t,labels,edge_parameters):
    """Direct nodal/branch identities from saved AC arrays, no AC rerun."""
    ac=t['ac'];voltage=ac['V_bus_mag'];buses=list(voltage.columns)
    incoming_p={b:np.zeros(96) for b in buses};incoming_q={b:np.zeros(96) for b in buses}
    outgoing_p={b:np.zeros(96) for b in buses};outgoing_q={b:np.zeros(96) for b in buses}
    p,q=np.asarray(t['P_pu']),np.asarray(t['Q_pu'])
    a.check('physical_all_converged',bool(ac['converged'].to_numpy(dtype=bool).all()))
    a.check('physical_voltage_limits',bool(((voltage.to_numpy()>=.9)&(voltage.to_numpy()<=1.1)).all()))
    a.check('static_branch_set',set(ac['branch_p_from_pu'].columns)==set(edge_parameters))
    for column,(r,x) in edge_parameters.items():
        u,v=map(int,column.split('->'))
        pf=ac['branch_p_from_pu'][column].to_numpy();pt=ac['branch_p_to_pu'][column].to_numpy()
        qf=ac['branch_q_from_pu'][column].to_numpy();qt=ac['branch_q_to_pu'][column].to_numpy()
        lp=ac['branch_loss_p_pu'][column].to_numpy();lq=ac['branch_loss_q_pu'][column].to_numpy()
        ell=ac['I_branch_mag'][column].to_numpy()**2
        incoming_p[v]+=pt;incoming_q[v]+=qt;outgoing_p[u]+=pf;outgoing_q[u]+=qf
        for residual in (pf-pt-lp,qf-qt-lq,lp-r*ell,lq-x*ell):
            a.maximum('physical_max_branch_residual',np.max(abs(residual),initial=0))
        drop=voltage[u].to_numpy()**2-voltage[v].to_numpy()**2-2*(r*pf+x*qf)+(r*r+x*x)*ell
        a.maximum('physical_max_DistFlow_residual',np.max(abs(drop),initial=0))
    for bus in buses:
        if bus==1: continue
        local_p=p[:,labels.index(bus)] if bus in labels else 0.
        local_q=q[:,labels.index(bus)] if bus in labels else 0.
        a.maximum('physical_max_nodal_residual',np.max(abs(incoming_p[bus]-outgoing_p[bus]-local_p),initial=0))
        a.maximum('physical_max_nodal_residual',np.max(abs(incoming_q[bus]-outgoing_q[bus]-local_q),initial=0))
    a.maximum('physical_max_system_residual',np.max(abs(outgoing_p[1]-p.sum(axis=1)-ac['branch_loss_p_pu'].sum(axis=1).to_numpy()),initial=0))
    a.maximum('physical_max_system_residual',np.max(abs(outgoing_q[1]-q.sum(axis=1)-ac['branch_loss_q_pu'].sum(axis=1).to_numpy()),initial=0))

def parameters(point):
    supports=point.get('supports',point.get('support_indices'))
    r=point.get('r_values',point.get('r'));x=point.get('x_values',point.get('x'))
    if supports is None or r is None or x is None or len(supports)!=len(r) or len(r)!=len(x):
        raise ValueError('missing aligned support/parameter vectors')
    return supports,np.asarray(r,float),np.asarray(x,float)

def matrices(point,n):
    supports,r,x=parameters(point);R=np.zeros((n,n));X=R.copy()
    for s,rv,xv in zip(supports,r,x):
        for i in s:
            for j in s: R[i,j]+=rv;X[i,j]+=xv
    return R,X

def mae(point,observed):
    p,q,v,root=[f.to_numpy(dtype=float) for f in observed]
    R,X=matrices(point,p.shape[1]);y=root[:,None]**2-v**2
    return float(np.mean(np.abs(y-p@R.T-q@X.T)))

def effective(point,labels):
    supports,r,x=parameters(point)
    return {tuple(sorted(labels[i] for i in s)) for s,rv,xv in zip(supports,r,x) if rv>0 or xv>0}

def final_selection(points,cal,train,valid):
    losses=[mae(p,valid) for p in points]
    best=min(losses)
    eligible=[i for i,v in enumerate(losses) if v<=1.03*best+1e-12]
    index=min(eligible,key=lambda i:(len(parameters(points[i])[0]),losses[i],i))
    supports,r,x=parameters(points[index]);cutoff=.16*float(cal['median_root_depth'])
    keep=[j for j,s in enumerate(supports) if len(s)==1 or float(cal['a'])*r[j]+float(cal['b'])*x[j]+1e-10>=cutoff]
    return dict(supports=[supports[j] for j in keep],r=r[keep].tolist(),x=x[keep].tolist()),index

def audit_physical(a,root,cfg,lock,policy,law,natural,edge_parameters):
    out=root/'physical'/f'{law}__{policy}'
    receipt=read(out/'events_receipt.json');packet=pickle.loads((out/'packet.pkl').read_bytes())
    saved=pickle.loads((out/'physical_truth.pkl').read_bytes())
    for name,ref in receipt.get('private_files',{}).items(): a.check('physical_private_hash',sha(out/name)==ref['sha256'],file=str(out/name))
    labels=list(map(int,lock['labels']));active=[labels.index(int(v)) for v in lock['active_labels']]
    prices=np.asarray(lock['plans'][policy],int);directions=np.asarray(lock['directions'][policy],int)
    template=lock['templates'][policy];events={int(e['event']):e for e in receipt['event_records']}
    truth={int(e['event']):e for e in saved['events']}
    scenes={}
    for role in ('training','validation'):
        ids=packet['metadata'][role+'_event_ids']
        a.check('packet_event_mapping',ids==[s['actual_event_id'] for s in packet[role]],policy=policy,role=role)
        scenes.update(zip(ids,packet[role]))
    paid=[];committed=[]
    for event in range(4):
        row=events[event];price=prices[event%2];direction=directions[event%2]
        z=expected_participants(price,event,law,cfg['participation_seed'],0)
        a.close('participation_CRN',np.asarray(row['accepted_participants'],int),z.astype(int),tol=0)
        fee=.2*float(price@z);committed.append(fee)
        a.close('event_committed_fee',row['committed_payment'],fee)
        a.close('contracted_energy',row['contracted_reduction_kWh'],.2*z)
        a.close('contracted_rebound',row['contracted_rebound_kWh'],.2*z)
        expected_replicate=cfg['replicate_base']+event
        a.check('fixed_replicate',row['replicate']==expected_replicate,event=event)
        if row['status']!='complete':
            a.check('failed_payment_unknown',row.get('actual_payment') is None,event=event)
            paid.append(None)
            a.notes.append(dict(event=event,policy=policy,law=law,scope='failed event natural baseline not saved; device qualification receipt-only, not independently reproduced'))
            continue
        paid.append(fee);a.close('delivered_fee',row['actual_payment'],fee)
        t=truth[event];p=np.asarray(t['P_pu']);q=np.asarray(t['Q_pu'])
        p0=np.asarray(t['natural_P_pu']);q0=np.asarray(t['natural_Q_pu'])
        key=event
        if key in natural:
            a.close('same_natural_P_path',p0,natural[key][0],tol=0)
            a.close('same_natural_Q_path',q0,natural[key][1],tol=0)
            a.close('same_root_path',t['root_pu'],natural[key][2],tol=0)
        else: natural[key]=(p0.copy(),q0.copy(),np.asarray(t['root_pu']).copy())
        delta=np.zeros_like(p);delta[76:84]=waveform(template,direction,active)*z[None,:]
        a.close('P_waveform',200*(p-p0),delta)
        a.close('Q_waveform',200*(q-q0),.35*delta)
        a.close('delivered_reduction',np.maximum(-delta,0).sum(axis=0)*.25,.2*z)
        a.close('delivered_rebound',np.maximum(delta,0).sum(axis=0)*.25,.2*z)
        a.close('net_energy',delta.sum(axis=0)*.25,np.zeros(len(labels)))
        a.check('same_peak',np.max(abs(delta),initial=0)<=.2+1e-12)
        a.check('terminal_power_capacity',np.max(abs(p),initial=0)*200<=45+1e-12)
        offered=price>0;fullwave=waveform(template,direction,active)
        residual_p=200*p0[76:84]-.2;residual_q=200*q0[76:84]-.07
        device_power=.2+fullwave;energy=np.cumsum(device_power,axis=0)*.25
        decomposition=(residual_p>=-1e-12).all(axis=0)&(residual_q>=-1e-12).all(axis=0)
        power_ok=(device_power>=-1e-12).all(axis=0)&(device_power<=.4+1e-12).all(axis=0)
        energy_ok=(energy>=-1e-12).all(axis=0)&(energy<=.4+1e-12).all(axis=0)
        deadline=abs(energy[-1]-.4)<=1e-12
        available=decomposition&power_ok&energy_ok&deadline
        a.check('accepted_devices_available',np.all((~z)|available),event=event)
        qualification=row['checks']['quote_qualification']
        a.close('device_decomposition_flags',np.asarray(qualification['decomposition_pass'],int),decomposition.astype(int),tol=0)
        a.close('device_power_flags',np.asarray(qualification['device_power_pass'],int),power_ok.astype(int),tol=0)
        a.close('device_energy_flags',np.asarray(qualification['device_energy_pass'],int),energy_ok.astype(int),tol=0)
        a.check('quote_qualification_flag',qualification['quote_qualification_pass']==bool(np.all((~offered)|available)))
        scene=scenes[event];index=pd.date_range(pd.Timestamp('2000-01-01')+pd.Timedelta(days=6+event),periods=96,freq='15min')
        for field in FIELDS:
            a.check('event_timestamps',scene[field].index.equals(index),field=field,event=event)
        a.check('explicit_units',scene.get('units')==UNITS,event=event)
        a.close('observed_drop_target',scene['drop_target'].to_numpy(),scene['V_root_observed'].to_numpy()[:,None]**2-scene['V_terminal'].to_numpy()**2)
        a.close('truth_participants',np.asarray(t['participants'],int),z.astype(int),tol=0)
        physical_equations(a,t,labels,edge_parameters)
    a.close('worst_budget',receipt['worst_payment'],.4*prices.sum())
    a.check('budget_bound',sum(committed)<=1.6+1e-12 and .4*prices.sum()<=1.6+1e-12)
    a.close('committed_total',receipt['committed_payment'],sum(committed))
    a.close('known_paid_total',receipt['known_actual_payment'],sum(v for v in paid if v is not None))
    a.check('unknown_fee_count',receipt['unknown_payment_events']==sum(v is None for v in paid))
    if any(v is None for v in paid): a.check('unknown_total_not_zero',receipt['actual_payment'] is None)
    else: a.close('actual_fee_total',receipt['actual_payment'],sum(paid))
    return receipt,packet

def run(root,output):
    root=Path(root).resolve();a=Audit()
    cfg=read(root/'actual_protocol.json');records=read(root/'actual_records.json')
    # This bounded whole-root audit deliberately waits. The private truth file
    # contains all four future events, so an early-only completed fit must not
    # authorize opening that file while its final fit is still pending.
    if (root/'run.lock').exists() or len(records)!=cfg['planned_records']:
        raise RuntimeError('actual run incomplete/active; no physical truth opened; wait for root completion')
    if any(r.get('status')!='complete' or not r.get('fit_complete') for r in records):
        raise RuntimeError('whole-root truth audit requires completed fits; retain failed records and request a completed-record-only audit')
    a.check('frozen_actual_protocol',sha(root/'actual_protocol.json')==read(root/'actual_protocol.sha256.json')['sha256'])
    for group in ('source_sha256','input_sha256','archived_source_sha256'):
        for p,h in cfg[group].items(): a.check('frozen_'+group,sha(p)==h,path=p)
    history,labels=old_scenes(cfg['history_row'])
    truth,expected_labels,tree_source=paper15_family(cfg['physical_source_root'])
    a.check('truth_terminal_order',labels==expected_labels)
    a.check('full_record_denominator',len(records)==cfg['planned_records'],actual=len(records),expected=cfg['planned_records'])
    if cfg.get('controls_only'):
        expected_controls={'zero','single','rotation','same','opposed','alternating','input_best'}
        a.check('exact_controls_only_methods',set(cfg['policies'])==expected_controls and cfg['planned_records']==28)
        missing=cfg.get('missing_method_records',[])
        a.check('full_price_unresolved_not_fallback',len(missing)==4 and all(
            r['policy']=='wzzt_best' and r['status']=='price_unresolved' for r in missing) and
            not any(r['policy']=='wzzt_best' for r in records))
        for role,ref in cfg['planning_unresolved'].items(): a.check('original_price_unresolved_hash',sha(ref['path'])==ref['sha256'],role=role)
    physical={};natural={};locks={}
    for law,ref in cfg['locks'].items():
        a.check('frozen_price_lock',sha(ref['path'])==ref['sha256'],law=law)
        lock=read(ref['path']);locks[law]=lock
        for policy in cfg['policies']:
            try:
                receipt,packet=audit_physical(a,root,cfg,lock,policy,law,natural,tree_source['edge_parameters_pu'])
                physical[(law,policy)]=(receipt,packet)
                start=datetime.fromisoformat(receipt['started_utc'])
                a.check('actual_after_protocol',start>=datetime.fromisoformat(cfg['created_utc']))
                lock_time=lock.get('created_utc',lock.get('frozen_utc'))
                if lock_time: a.check('actual_after_price_freeze',start>=datetime.fromisoformat(lock_time))
                else: a.notes.append(dict(law=law,policy=policy,scope='price lock lacks timestamp; hash binding checked, chronology available from protocol only'))
            except Exception as exc:
                a.check('physical_audit_exception',False,policy=policy,law=law,error=str(exc),traceback=traceback.format_exc())
    fit_seen={};cost_audits=0;complete=0
    for row in records:
        law,policy,checkpoint=row['dependence'],row['policy'],row['checkpoint']
        try:
            receipt,packet=physical[(law,policy)];event={e['event']:e for e in receipt['event_records']}
            cutoff=1 if checkpoint=='early' else 4
            needed=list(range(cutoff))
            expected_operation=all(event[e].get('status')=='complete' and all(
                event[e].get('checks',{}).get(k) is True for k in
                ('energy_return_pass','capacity_pass','voltage_limits_pass','electrical_equations_pass')) for e in needed)
            a.check('checkpoint_operation_status',row.get('operation_checks_pass')==expected_operation,record=row['record_id'])
            costs=row.get('cost',{});paid=[event[e].get('actual_payment') for e in range(cutoff)]
            expected_paid=None if any(v is None for v in paid) else sum(paid)
            a.check('checkpoint_actual_fee',row.get('actual_payment')==expected_paid,record=row['record_id'])
            if costs:
                a.check('checkpoint_cost_actual',costs.get('paid_through_checkpoint')==expected_paid)
                price=np.asarray(locks[law]['plans'][policy])
                a.close('checkpoint_future_worst',costs['unstarted_event_worst_payment'],sum(.2*price[e%2].sum() for e in range(cutoff,4)))
                a.check('no_success_cancellation',costs.get('future_event_cancellation') is False)
                cost_audits+=1
            if row['status']!='complete': continue
            complete+=1
            identifier_path=Path(row['identifier_packet_path'])
            a.check('identifier_packet_hash',sha(identifier_path)==row['identifier_packet_sha256'])
            identifier=pickle.loads(identifier_path.read_bytes())
            if checkpoint=='early':
                a.check('worker_prefix_only',identifier['metadata'].get('precut') is True and
                    identifier['metadata'].get('training_event_ids')==[0] and
                    identifier['metadata'].get('validation_event_ids')==[] and
                    len(identifier['training'])==1 and not identifier['validation'])
                for field in FIELDS:
                    own_source=packet['training'][packet['metadata']['training_event_ids'].index(0)][field].iloc[:84]
                    supplied=identifier['training'][0][field]
                    a.check('worker_prefix_timestamps',supplied.index.equals(own_source.index),field=field)
                    a.close('worker_prefix_values',supplied.to_numpy(),own_source.to_numpy())
                a.check('worker_prefix_units',identifier['training'][0].get('units')==UNITS)
            training,validation=available_scenes(history,packet,checkpoint)
            tr,days,th=combine(training);va,vdays,vh=combine(validation)
            expected_rows=(372,288) if checkpoint=='early' else (480,480)
            a.check('checkpoint_rows',(len(tr[0]),len(va[0]))==expected_rows,record=row['record_id'])
            if checkpoint=='early': a.check('early_last_available_time',tr[0].index[-1]==pd.Timestamp('2000-01-07 20:45:00'))
            inputs={'training':th,'validation':vh}
            a.check('record_input_hash',inputs==row['input_sha256'],record=row['record_id'])
            expected_fp=fingerprint(dict(input_sha256=inputs,source_sha256=cfg['source_sha256'],search_seconds=cfg['fit_path_seconds']))
            a.check('dedup_identity',expected_fp==row['observed_fingerprint'])
            result=read(row['fit_path'])
            a.check('result_exact_input_hash',result['input_sha256']==inputs)
            a.check('same_input_same_fit',expected_fp not in fit_seen or fit_seen[expected_fp]==row['fit_path'])
            a.check('truth_not_identifier_input',result.get('truth_input_allowed') is False and row.get('truth_read_before_fit') is False)
            a.check('search_scans_report',row['all_local_scans_complete']==all(s['reason']=='pool_local_optimum' for s in result['searches'].values()))
            truth_file=read(root/'physical'/f'{law}__{policy}'/'truth_evaluation.json')
            a.check('independent_BFS_truth',truth=={tuple(sorted(s)) for s in truth_file['true_supports']})
            for name,model in result['models'].items():
                pred=effective(model,labels);evaluation=row['evaluation'][name]
                a.check('full_structure_errors',evaluation['full_block_errors']==len(truth^pred) and evaluation['full_recovery']==(truth==pred),record=row['record_id'],model=name)
                a.check('explicit_missed_extra',evaluation['missed']==[list(s) for s in sorted(truth-pred)] and evaluation['extra']==[list(s) for s in sorted(pred-truth)])
                a.maximum('max_model_training_L1_difference',abs(mae(model,tr)-model['train_mae']))
                a.maximum('max_model_validation_L1_difference',abs(mae(model,va)-model['validation_mae']))
            if expected_fp not in fit_seen:
                cal=result['calibrations']['raw'];bank=result['bank'];all_points=result['selection_candidates']
                candidates={'rnj_bank':bank,'baseline25':all_points[:len(bank)+len(result['searches']['primary']['path'])],
                    'multistart_original_rule':all_points}
                for name,points in candidates.items():
                    chosen,index=final_selection(points,cal,tr,va)
                    expected_matrices=matrices(chosen,len(labels));actual_matrices=matrices(result['models'][name],len(labels))
                    a.close('final_selection_R',expected_matrices[0],actual_matrices[0])
                    a.close('final_selection_X',expected_matrices[1],actual_matrices[1])
                    a.check('selection_index',result['models'][name]['selection_index']==index,model=name)
                a.check('fifteen_native_RNJ',len(bank)==15)
                a.check('saved_LP_receipts',all(s.get('status')==2 and s.get('accepted') for s in result['LP_solves']))
            fit_seen[expected_fp]=row['fit_path']
        except Exception as exc:
            a.check('record_audit_exception',False,record=row['record_id'],error=str(exc),traceback=traceback.format_exc())
    summary=read(root/'actual_summary.json')
    a.check('summary_actual_denominator',summary['planned']==cfg['planned_records'] and summary['records']==len(records))
    a.check('summary_method_denominator',len(summary['groups'])==2*len(cfg['policies']))
    for group in summary['groups']:
        rows=[r for r in records if r['policy']==group['policy'] and r['checkpoint']==group['checkpoint']]
        complete_rows=[r for r in rows if r['status']=='complete']
        feasible=[r for r in complete_rows if r.get('operation_checks_pass') is True]
        a.check('operation_subdenominator',group['structure_denominator']==len(feasible) and group['all_structural_denominator']==len(complete_rows))
        for tag,model in (('wzzt','multistart_original_rule'),('rnj','rnj_bank')):
            a.check('feasible_structure_numerator',group[tag+'_full']==sum(r['evaluation'][model]['full_recovery'] for r in feasible))
    for name,value in a.numeric.items():
        tolerance=1e-8 if name.startswith('physical_') else TOL
        a.check(name,value<=tolerance,max_abs_difference=value,tolerance=tolerance)
    report=dict(status='passed' if all(c['pass_'] for c in a.checks) else 'failed',created_utc=datetime.now(timezone.utc).isoformat(),
        actual_root=str(root),audit_source_sha256=sha(__file__),records=len(records),complete_records=complete,
        statuses=dict(Counter(r['status'] for r in records)),unique_complete_fits=len(fit_seen),cost_record_checks=cost_audits,
        checks=len(a.checks),failed_checks=[c for c in a.checks if not c['pass_']],all_checks=a.checks,notes=a.notes,
        numeric_maxima=a.numeric,independent_true_blocks=len(truth),true_source=tree_source,
        no_new_AC_LP_or_profiles=True,producer_controller_evaluate_imports=False,
        scope='saved-evidence reconstruction; floating checks/LP receipts are not global optimality, statistical coverage or recovery probabilities')
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
    return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--allow-actual-read',action='store_true');a=p.parse_args()
    if not a.allow_actual_read: p.error('root must explicitly authorize reading the completed actual evidence')
    report=run(a.root,a.output)
    print(json.dumps({k:report[k] for k in ('status','records','complete_records','checks','unique_complete_fits','independent_true_blocks')}))
    return 0 if report['status']=='passed' else 2

if __name__=='__main__': raise SystemExit(main())
