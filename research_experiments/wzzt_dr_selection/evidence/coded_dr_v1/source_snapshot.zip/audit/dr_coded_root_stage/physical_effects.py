"""Evaluator-only saved counterfactual contrasts, never a design score.

Run after all frozen actual records return. No new profiles/AC/LP are produced.
"""
from pathlib import Path
import json,pickle
import numpy as np
BASE=Path(r'C:\Users\23761\.codex\visualizations\2026\10\25\01a1726e-8ec7-7bc1-9f18-391f9cf79a1a')
ROOT=BASE/'wzzt_dr_coded_actual_controls_v1'

def main():
    records=json.loads((ROOT/'actual_records.json').read_text(encoding='utf-8'))
    assert len(records)==28 and all(r['status']=='complete' for r in records)
    rows=[]
    for law in ('local','common'):
        zero=pickle.loads((ROOT/'physical'/f'{law}__zero'/'physical_truth.pkl').read_bytes())['events']
        zero={r['event']:r for r in zero}
        for folder in sorted((ROOT/'physical').glob(law+'__*')):
            receipt=json.loads((folder/'events_receipt.json').read_text(encoding='utf-8'))
            truth=pickle.loads((folder/'physical_truth.pkl').read_bytes())['events']
            maxp=maxq=maxv=aggregate=0.;participants=active_events=0
            for event in truth:
                baseline=zero[event['event']]
                assert np.max(abs(event['natural_P_pu']-baseline['natural_P_pu']))<1e-14
                assert np.max(abs(event['natural_Q_pu']-baseline['natural_Q_pu']))<1e-14
                delta=(event['P_pu']-baseline['P_pu'])*200
                maxp=max(maxp,float(np.max(abs(delta))))
                maxq=max(maxq,float(np.max(abs((event['Q_pu']-baseline['Q_pu'])*200))))
                maxv=max(maxv,float(np.max(abs(event['V_pu']-baseline['V_pu']))))
                aggregate=max(aggregate,float(np.max(abs(delta.sum(axis=1)))))
                participants+=int(event['participants'].sum());active_events+=int(event['participants'].any())
            target=json.loads((folder/'truth_evaluation.json').read_text(encoding='utf-8'))
            shared=[s for s in target['true_supports'] if 109 in s and 113 in s]
            rows.append(dict(policy=receipt['policy'],dependence=law,participant_node_events=participants,
                active_events=active_events,max_increment_kw=maxp,max_increment_kvar=maxq,
                max_true_voltage_counterfactual_difference_pu=maxv,max_total_terminal_P_increment_kw=aggregate,
                true_shared_positive_supports_for_active_pair=shared))
    result=dict(scope='saved evaluator-only no-DR counterfactual; not observable online or used for prices/identifier',
        records=rows,total_participant_node_events=sum(r['participant_node_events'] for r in rows),
        total_active_events=sum(r['active_events'] for r in rows),
        new_profiles=0,new_AC=0,new_LP=0,
        prices_or_algorithm_changed_after_evaluation=False)
    truth=json.loads((ROOT/'physical/local__zero/truth_evaluation.json').read_text(encoding='utf-8'))
    shared=[s for s in truth['true_supports'] if 109 in s and 113 in s]
    result['true_shared_positive_supports_for_active_pair']=shared
    result['positive_true_shared_ancestor_line_cancellation_tested']=bool(shared)
    result['true_supports_used_for_price_design']=False
    (BASE/'dr_coded_root_stage/physical_effects.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
