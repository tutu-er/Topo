"""Aggregate frozen records; no fitting, simulator or raw trajectories loaded."""
from pathlib import Path
from collections import Counter
import hashlib,json

BASE=Path(r'C:\Users\23761\.codex\visualizations\2026\10\25\01a1726e-8ec7-7bc1-9f18-391f9cf79a1a')
ROOT=BASE/'wzzt_dr_coded_actual_controls_v1'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def family(point,labels):
    support=point.get('support_labels',[[labels[i] for i in s] for s in point['supports']])
    rv=point.get('r_values',point.get('r'));xv=point.get('x_values',point.get('x'))
    return {tuple(s) for s,r,x in zip(support,rv,xv,strict=True) if r>0 or x>0}

def main():
    rows=read(ROOT/'actual_records.json');cfg=read(ROOT/'actual_protocol.json')
    assert len(rows)==cfg['planned_records']==28
    fits={r['fit_path']:read(r['fit_path']) for r in rows if r.get('fit_complete')}
    statuses=Counter(s['status'] for fit in fits.values() for s in fit['LP_solves'])
    path_status=Counter(s for fit in fits.values() for s in fit['search_stop_statuses'].values())
    physical={r['physical_receipt_path']:read(r['physical_receipt_path']) for r in rows}
    events=[e for p in physical.values() for e in p['event_records']]
    assert len(physical)==14 and len(events)==56
    outcome=[]
    for checkpoint in ('early','final'):
        subset=[r for r in rows if r['checkpoint']==checkpoint]
        outcome.append(dict(checkpoint=checkpoint,records=len(subset),
            wzzt_error_counts=dict(Counter(r['evaluation']['multistart_original_rule']['full_block_errors'] for r in subset)),
            RNJ_error_counts=dict(Counter(r['evaluation']['rnj_bank']['full_block_errors'] for r in subset)),
            WZZT_full=sum(r['evaluation']['multistart_original_rule']['full_recovery'] for r in subset),
            RNJ_full=sum(r['evaluation']['rnj_bank']['full_recovery'] for r in subset)))
    paired=[]
    for r in rows:
        if r['policy']=='zero':continue
        control=next(c for c in rows if c['policy']=='zero' and c['dependence']==r['dependence'] and c['checkpoint']==r['checkpoint'])
        delta=r['evaluation']['multistart_original_rule']['full_block_errors']-control['evaluation']['multistart_original_rule']['full_block_errors']
        paired.append(delta)
    cost=[]
    for policy in cfg['policies']:
        final=[r for r in rows if r['policy']==policy and r['checkpoint']=='final']
        early=[r for r in rows if r['policy']==policy and r['checkpoint']=='early']
        cost.append(dict(policy=policy,full_contract_payments={r['dependence']:r['actual_payment'] for r in final},
            checkpoint_payments={r['dependence']:r['actual_payment'] for r in early},
            WZZT_early_errors=[r['evaluation']['multistart_original_rule']['full_block_errors'] for r in early],
            WZZT_final_errors=[r['evaluation']['multistart_original_rule']['full_block_errors'] for r in final]))
    leaf=[]
    for r in rows:
        fit=fits[r['fit_path']];point=fit['models']['multistart_original_rule']
        supports=point.get('support_labels',[[fit['terminal_labels'][i] for i in s] for s in point['supports']])
        values=[dict(r=rv,x=xv) for s,rv,xv in zip(supports,point.get('r_values',point['r']),point.get('x_values',point['x'])) if s==[103]]
        pre=[dict(r=rv,x=xv) for s,rv,xv in zip(point['pre_contraction_support_indices'],point['pre_contraction_r_values'],point['pre_contraction_x_values']) if s==[fit['terminal_labels'].index(103)]]
        leaf.append(dict(record_id=r['record_id'],checkpoint=r['checkpoint'],leaf103=values,precontraction_leaf103=pre,
            selected_origin=point.get('selected_origin')))
    p=read(BASE/'wzzt_dr_coded_planning_v1/case_plans.json')
    pcfg=read(BASE/'wzzt_dr_coded_planning_v1/protocol.json')
    old_path=Path(pcfg['pilot_row']['existing_result']['path']);old=read(old_path)
    index103=old['labels'].index(103);best=min(v['validation_mae'] for v in old['base_points'])
    historical=[]
    for index,point in enumerate(old['base_points']):
        if point['validation_mae']>1.03*best+1e-12:continue
        for s,rv,xv in zip(point['supports'],point['r'],point['x']):
            if s==[index103]:historical.append(dict(raw_index=index,r=rv,x=xv))
    summary=dict(status='complete_controls_only',full_DR_method_goal_achieved=False,
        actual_records=len(rows),price_unresolved_records=cfg.get('missing_method_records',[]),
        price_method_unresolved_count=4,full_comparison_planned_records=32,
        statuses=dict(Counter(r['status'] for r in rows)),unique_fits=len(fits),
        LP_calls_unique=sum(len(f['LP_solves']) for f in fits.values()),LP_statuses=dict(statuses),
        WZZT_path_statuses=dict(path_status),incomplete_scan_records=sum(not r['all_local_scans_complete'] for r in rows),
        incomplete_scan_unique_fits=sum(not f['all_local_scans_complete'] for f in fits.values()),
        operation_checks_pass=sum(r['operation_checks_pass'] is True for r in rows),
        actual_physical_trajectories=len(physical),physical_events=len(events),AC_samples=len(events)*96,
        unique_natural_four_day_paths=1,checkpoints=outcome,
        paid_vs_zero_comparisons=dict(total=len(paired),better=sum(v<0 for v in paired),same=sum(v==0 for v in paired),worse=sum(v>0 for v in paired)),
        same_observations_WZZT_vs_RNJ=dict(records=len(rows),same_family=sum(family(fits[r['fit_path']]['models']['multistart_original_rule'],fits[r['fit_path']]['terminal_labels'])==family(fits[r['fit_path']]['models']['rnj_bank'],fits[r['fit_path']]['terminal_labels']) for r in rows)),
        cost_by_policy=cost,full_contract_total_payment=sum(r['actual_payment'] for r in rows if r['checkpoint']=='final'),
        full_contract_unknown_payment_records=sum(r['actual_payment'] is None for r in rows if r['checkpoint']=='final'),
        early_and_final_costs_not_additive=True,
        planning_gate=dict(status=p['status'],seconds=p['elapsed_seconds'],LP_calls=p['LP_calls'],
                           planned_training_contexts=96,complete=58,unresolved=1,not_started=37),
        new_total_LP_calls=2868+sum(len(f['LP_solves']) for f in fits.values()),
        unique_current_pure_tests=16,independent_template_mask_checks=12,
        early_missing_block=[[103]],early_error_reason='selected raw singleton103 fitted r=x=0 before contraction; not a .16 removal',
        historical103=dict(eligible_points=len(historical),positive=sum(v['r']>0 or v['x']>0 for v in historical),
                           min_r_plus_x=min(v['r']+v['x'] for v in historical),
                           max_r_plus_x=max(v['r']+v['x'] for v in historical),source_sha256=sha(old_path)),
        active_labels=[109,113],intersection_label110_not_probed=True,
        two_round_complementary_three_site_construct_tested=False,
        locked_panel_count=8,actual_pilot_conditions=1,other_conditions_not_started=7,
        scope='bounded existing-AMI development test; one shared natural path, no general recovery probability or global no-DR claim')
    truth=read(ROOT/'physical/local__zero/truth_evaluation.json')
    shared=[s for s in truth['true_supports'] if 109 in s and 113 in s]
    summary['true_shared_positive_supports_for_active_pair']=shared
    summary['strong_true_shared_ancestor_cancellation_premise_present']=bool(shared)
    audit_path=BASE/'dr_coded_independent_audit_stage/actual_independent_audit.json'
    audit=read(audit_path)
    summary['actual_independent_audit']=dict(checks=audit['checks'],failed=len(audit['failed_checks']),
        path=str(audit_path),sha256=sha(audit_path),first_numerical_index_discrepancy_retained=True,new_solver_calls=0)
    (BASE/'dr_coded_root_stage/summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (BASE/'dr_coded_root_stage/leaf103_diagnosis.json').write_text(json.dumps(dict(records=leaf,historical=historical,
        historical_source_sha256=sha(old_path),evaluator_only=True,used_to_design_new_prices=False),indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in summary.items() if k in ('actual_records','unique_fits','LP_calls_unique','LP_statuses','incomplete_scan_records','incomplete_scan_unique_fits','full_contract_total_payment','new_total_LP_calls','paid_vs_zero_comparisons')}))

if __name__=='__main__':main()
