"""Publish metadata, fitted results and source; never copy observed trajectories."""
from pathlib import Path
import ast,gzip,hashlib,json,zipfile

BASE=Path(r'C:\Users\23761\.codex\visualizations\2026\10\25\01a1726e-8ec7-7bc1-9f18-391f9cf79a1a')
REPO=Path(r'C:\Users\23761\.codex\worktrees\wzzt-dr-selection\Topo')
ACT=BASE/'wzzt_dr_coded_actual_controls_v1'
OUT=BASE/'wzzt_dr_coded_delivery_v2'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def encoded(value):return (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()

FIT_KEYS=('status','fingerprint','input_sha256','source_sha256','environment','settings','root_label','search_seconds',
    'terminal_labels','training_rows','validation_rows','training_day_counts','validation_day_counts','models',
    'bank','selection_candidates','searches','search_stop_statuses','all_local_scans_complete','LP_solves',
    'calibrations','extra_start_sources','start_preparation','pool_size','pool_support_indices','pool_support_labels','elapsed_seconds')

def check_metadata(value,path=''):
    forbidden={'p_pu','q_pu','v_pu','p_true','q_true','v_true','natural_p_pu','natural_q_pu',
               'p_measured','q_measured','voltage_measured','p_terminal','q_terminal','v_terminal'}
    if isinstance(value,dict):
        for key,item in value.items():
            if key.lower() in forbidden and isinstance(item,(list,dict)):
                raise ValueError('potential trajectory in publication: '+path+'/'+key)
            check_metadata(item,path+'/'+key)
    elif isinstance(value,list):
        for i,item in enumerate(value):check_metadata(item,path+'/'+str(i))

def main():
    if OUT.exists():raise FileExistsError('existing public delivery retained')
    OUT.mkdir()
    summary=read(BASE/'dr_coded_root_stage/summary.json')
    assert summary['actual_records']==28 and summary['actual_independent_audit']['failed']==0
    (OUT/'summary.json').write_bytes(encoded(summary))
    records=read(ACT/'actual_records.json');check_metadata(records)
    raw=encoded(records);(OUT/'records.json.gz').write_bytes(gzip.compress(raw,mtime=0))
    index={}
    with zipfile.ZipFile(OUT/'fits.zip','w',zipfile.ZIP_DEFLATED) as z:
        for path in sorted({r['fit_path'] for r in records if r.get('fit_complete')}):
            result=read(path);filtered={k:result[k] for k in FIT_KEYS if k in result}
            original_hash=sha(Path(path).read_bytes())
            filtered.update(archive_scope='fitted metadata only; original observed arrays remain private',
                            original_result_sha256=original_hash)
            check_metadata(filtered)
            member=result['fingerprint']+'.json';data=encoded(filtered);z.writestr(member,data)
            index[path]=dict(member=member,original_sha256=original_hash,published_member_sha256=sha(data))
    assert len(index)==17
    (OUT/'fit_index.json').write_bytes(encoded(index))
    stage={}
    def add(path,member):
        path=Path(path)
        if path.suffix.lower() not in ('.json','.gz','.log','.md','.zip'):raise ValueError(str(path))
        data=path.read_bytes()
        if path.suffix=='.json':check_metadata(json.loads(data))
        if member in stage:raise ValueError('duplicate stage member '+member)
        stage[member]=data
    plan=BASE/'wzzt_dr_coded_planning_v1'
    for p in plan.rglob('*.json'):
        if p.name in ('checkpoint.json','run_checkpoint.json'):continue
        add(p,'planning/'+p.relative_to(plan).as_posix())
    add(plan/'source_snapshot_before_controller_fix.zip','planning/source_snapshot_before_controller_fix.zip')
    fixed=BASE/'wzzt_dr_coded_fixed_controls_v1'
    for p in fixed.rglob('*.json'):add(p,'fixed_controls/'+p.relative_to(fixed).as_posix())
    for name in ('actual_protocol.json','actual_protocol.sha256.json','actual_summary.json'):
        add(ACT/name,'actual/'+name)
    for folder in (ACT/'physical').iterdir():
        for name in ('events_receipt.json','truth_evaluation.json','controller_launch.json'):
            p=folder/name
            if p.exists():add(p,'actual/physical/'+folder.name+'/'+name)
    for name in ('wzzt_dr_coded_qualification_v1','wzzt_dr_coded_planning_audit_v1',
                 'dr_coded_independent_audit_stage','dr_coded_runner_fix_v2',
                 'dr_coded_physical_stage','dr_coded_plan_stage','dr_coded_root_stage'):
        root=BASE/name
        for p in root.glob('*.json'):
            if p.name.endswith('.console.json'):continue
            add(p,'checks/'+name+'/'+p.name)
        if (root/'RESULTS.md').exists():add(root/'RESULTS.md','checks/'+name+'/RESULTS.md')
    with zipfile.ZipFile(OUT/'stage_records.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name,data in sorted(stage.items()):z.writestr(name,data)
    cfg=read(ACT/'actual_protocol.json');sources={}
    for group in ('source_sha256','archived_source_sha256'):
        for p,h in cfg[group].items():
            file=Path(p);data=file.read_bytes();assert sha(data)==h,p
            try:member='repo/'+file.relative_to(REPO).as_posix()
            except ValueError:member='physical/'+file.relative_to(Path(cfg['physical_source_root'])).as_posix()
            sources[member]=data
    for name in ('wzzt_dr_coded_planning_audit_v1','dr_coded_independent_audit_stage','dr_coded_root_stage'):
        for p in (BASE/name).glob('*.py'):sources['audit/'+name+'/'+p.name]=p.read_bytes()
    # Preserve both reviewed controller versions, including the one never used
    # for actual data; no revision is substituted into the original protocol.
    for name in ('dr_coded_runner_stage','dr_coded_runner_fix_v2'):
        for p in (BASE/name).glob('*.py'):sources['versioned/'+name+'/'+p.name]=p.read_bytes()
    with zipfile.ZipFile(OUT/'source_snapshot.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name,data in sorted(sources.items()):
            ast.parse(data.decode('utf-8-sig'),filename=name);z.writestr(name,data)
    readme='''# 相反移峰首门公开证据

主结果见../../dr_coded_selection/REPORT.md。完整价格法未决；28固定控制记录全部返回，另4价格项未执行。early各策略RNJ/WZZT均1错漏，final均0，无奖励相同。

summary保存完整分母；records.json.gz保存28记录元数据；fits.zip为17个筛选后的拟合结果，fit_index同时保留原私有文件与公开成员hash。筛选文件不是原结果的逐字节副本。stage_records包含资格、未决价表、冻结固定价格、物理/费用回执、初始失败与最终独立审计；source_snapshot包含当前运行源码、审计及两个controller版本。原规划全过程109源ZIP另在stage_records中。

没有上传observed/physical/identifier pickle、旧NPZ、家庭或聚合P/Q/V轨迹。公开材料可核对拟合/选择与摘要；完整物理重放仍需私有观测和生成器环境。

私有恢复根位于C:/Users/23761/.codex/visualizations/2026/10/25/01a1726e-8ec7-7bc1-9f18-391f9cf79a1a/：wzzt_dr_coded_qualification_v1、wzzt_dr_coded_planning_v1、wzzt_dr_coded_fixed_controls_v1、wzzt_dr_coded_actual_controls_v1及独立audit目录。全部阶段已结束，无运行锁；不重跑旧价表或追加原求解预算。旧controller修复后，原价protocol的两个非规划源漂移由冻结源ZIP解释，不修改原hash。

仅一个共享四日自然路径。6条记录/3份拟合未完成全部WZZT扫描；保存LP状态、矩阵重放和数值校验不作为全局最优或统计覆盖。两节点实际没有共同正有效线路祖先，未验证强共同祖先抵消或两轮三节点互补构造。原自动任务仍关闭。
'''
    (OUT/'README.md').write_text(readme,encoding='utf-8')
    manifest=dict(scope='metadata/fits/source only; no household or aggregate observed/physical trajectories',
        files={p.name:dict(sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(OUT.iterdir())},
        source_members={name:sha(data) for name,data in sorted(sources.items())},
        compressed_records=dict(uncompressed_sha256=sha(raw),records=len(records)),
        original_to_published_fit_files_are_not_identical=True,
        actual_records=28,unresolved_price_records=4,unique_fits=17,shared_natural_paths=1,
        source_versions='original planning snapshot retained separately from corrected actual controller',
        raw_observed_and_physical_files_remain_private=True)
    (OUT/'manifest.json').write_bytes(encoded(manifest))
    for name,m in manifest['files'].items():
        data=(OUT/name).read_bytes();assert sha(data)==m['sha256'] and len(data)==m['bytes']
    for name in ('fits.zip','stage_records.zip','source_snapshot.zip'):
        with zipfile.ZipFile(OUT/name) as z:
            assert z.testzip() is None
            for member in z.namelist():
                assert Path(member).suffix.lower() not in ('.pkl','.pickle','.npz','.npy','.rdata'),member
                if name=='source_snapshot.zip':assert sha(z.read(member))==manifest['source_members'][member]
    print(json.dumps(dict(status='verified',files=len(manifest['files'])+1,
        bytes=sum(p.stat().st_size for p in OUT.iterdir()),source_members=len(sources),stage_members=len(stage),unique_fits=len(index))))

if __name__=='__main__':main()
