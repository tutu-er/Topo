"""Independent saved coded-planning arithmetic; no parent imports or solvers.

Only completed historical/prediction artifacts are read. No actual future,
physical truth, AC solver, LP solver, or profile generator is accessed.
"""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
from fractions import Fraction as F
import hashlib
import itertools
import json
import math
from pathlib import Path
import numpy as np


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))


def matrices(point,n):
    rr=np.zeros((n,n));xx=rr.copy();family=set()
    for s,r,x in zip(point['supports'],point['r'],point['x']):
        assert s and len(s)==len(set(s)) and min(s)>=0 and max(s)<n and r>=0 and x>=0
        z=np.zeros(n);z[s]=1;rr+=float(r)*np.outer(z,z);xx+=float(x)*np.outer(z,z)
        if r>0 or x>0:family.add(tuple(sorted(s)))
    return rr,xx,family


def contract(point,cal):
    chosen=[i for i,(s,r,x) in enumerate(zip(point['supports'],point['r'],point['x']))
            if len(s)==1 or cal['a']*r+cal['b']*x+1e-10>=.16*cal['median_root_depth']]
    return dict(supports=[point['supports'][i] for i in chosen],r=[point['r'][i] for i in chosen],
                x=[point['x'][i] for i in chosen])


def old_arrays(row,role):
    entry=row[role];p=Path(entry['path'])
    assert p.name==role+'_observed.npz' and sha(p)==entry['catalog_sha256']
    with np.load(p,allow_pickle=False) as z:
        labels=z['labels'].astype(int).tolist()
        pp,qq,vv=(z[k].reshape(288,len(labels)).copy() for k in ('P','Q','V'))
        root=z['root'].reshape(288).copy()
    return labels,(pp,qq,root[:,None]**2-vv**2)


def forecast_future(train,valid,positions,template):
    n=train[0].shape[1]
    pp=np.concatenate((train[0],valid[0])).reshape(6,96,n).mean(axis=0)
    qq=np.concatenate((train[1],valid[1])).reshape(6,96,n).mean(axis=0)
    wave=np.r_[np.full(4,-.2),np.full(4,.2)]
    if template=='alternating_opposed':wave=np.array([-.2,.2]*4)
    second=wave if template=='same' else -wave
    future={}
    for key in range(4):
        p=pp.copy();q=qq.copy()
        for bit,pos,w in ((0,positions[0],wave),(1,positions[1],second)):
            if key&(1<<bit):p[76:84,pos]+=w/200.;q[76:84,pos]+=.35*w/200.
        future[key]=(p,q)
    return future


def event_law(prices,law):
    probability=[F(0),F(1,2),F(3,4)]
    p=[probability[int(v)] for v in prices]
    if law=='local':
        out=[]
        for key in range(4):
            mass=F(1)
            for j in range(2):mass*=p[j] if key&(1<<j) else 1-p[j]
            if mass:out.append((key,mass))
    else:
        cuts=sorted({F(0),F(1),*p});bucket={}
        for lower,upper in zip(cuts,cuts[1:]):
            mid=(lower+upper)/2;key=sum(1<<j for j in range(2) if mid<p[j])
            bucket[key]=bucket.get(key,F(0))+upper-lower
        out=sorted(bucket.items())
    assert sum(m for _,m in out)==1
    return out


def menu_distribution(menu,law):
    first,second=event_law(menu[0],law),event_law(menu[1],law)
    out={}
    for outcomes in itertools.product(first,second,first,second):
        key=tuple(v[0] for v in outcomes);mass=math.prod(v[1] for v in outcomes)
        out[key]=out.get(key,F(0))+mass
    assert sum(out.values())==1
    return out


def menu_set():
    return [np.asarray(v,np.uint8).reshape(2,2) for v in itertools.product(range(3),repeat=4) if sum(v)<=4]


def fees(menu,distribution):
    expected=F(0)
    for key,mass in distribution.items():
        paid=F(1,5)*sum(int(menu[e%2,j])*bool(key[e]&(1<<j)) for e in range(4) for j in range(2))
        expected+=mass*paid
    direct=F(2,5)*sum(int(v)*[F(0),F(1,2),F(3,4)][int(v)] for v in menu.flat)
    assert expected==direct
    return expected,F(2,5)*int(menu.sum())


def verify_planning_sources(root,cfg,protocol):
    import zipfile
    mismatches=[]
    allowed={'research_experiments/wzzt_dr_selection/dr_coded_selection/controller.py',
             'research_experiments/wzzt_dr_selection/dr_coded_selection/test_controller.py'}
    archive=root/'source_snapshot_before_controller_fix.zip'
    expected_zip='9694d311a2fbf5efb07b718e60bceb9ff14d71c843e28655e83d770142557cde'
    metadata=read(root/'source_snapshot_before_controller_fix.json')
    assert sha(archive)==metadata['sha256']==expected_zip
    assert metadata['protocol_sha256']==sha(root/'protocol.json')
    repo=Path(cfg['repo_root']).resolve()
    with zipfile.ZipFile(archive) as z:
        for filename,digest in cfg['source_sha256'].items():
            current=sha(filename)
            if current==digest:continue
            relative=Path(filename).resolve().relative_to(repo).as_posix()
            assert relative in allowed and filename not in protocol['identity']['source_sha256']
            archived=z.read('repo/'+relative)
            assert hashlib.sha256(archived).hexdigest()==digest
            mismatches.append(dict(path=filename,frozen_sha256=digest,current_sha256=current,
                reason='actual-controller/test repaired after planning ended; snapshot verifies original bytes; not used by coded replay'))
    for filename,digest in protocol['identity']['source_sha256'].items():assert sha(filename)==digest
    return mismatches,expected_zip


def template_audit(root,template,require_complete):
    cfg=read(root/'protocol.json');td=root/'planning'/template
    protocol=read(td/'plan_protocol.json');saved_result_path=td/'plan_result.json'
    final=read(saved_result_path) if saved_result_path.exists() else read(td/'checkpoint.json')
    nonplanning_drift,snapshot_sha=verify_planning_sources(root,cfg,protocol)
    pilot=cfg['pilot_row'];labels,train=old_arrays(pilot,'train');vl,valid=old_arrays(pilot,'validation');assert labels==vl==cfg['labels']
    entry=pilot['existing_result'];assert sha(entry['path'])==entry['catalog_sha256'];old=read(entry['path'])
    indices=cfg['representative_indices'];models=[old['base_points'][i] for i in indices]
    cal=old['calibration'];n=len(labels);positions=[labels.index(v) for v in cfg['active_labels']]
    future=forecast_future(train,valid,positions,template)
    rawhash=[hashlib.sha256(np.asarray(a,dtype='<f8').tobytes()).hexdigest() for a in (*train,*valid)]
    assert rawhash==protocol['identity']['historical_arrays_hash']
    masks={};pending=[]
    for serial in range(len(models)):
        for a,b in itertools.product(range(4),repeat=2):
            p=td/'training_masks'/f'm{serial}_u{a}_{b}.json'
            if not p.exists():pending.append([serial,a,b]);continue
            raw=read(p)
            if raw['status']!='complete':pending.append([serial,a,b]);continue
            masks[(serial,a,b)]=(p,raw)
    if require_complete and len(masks)!=32:
        return dict(status='pending',template=template,completed_training_masks=len(masks),expected_training_masks=32,
                    planner_status=final['status'],missing_or_unresolved_keys=pending)
    tables=[{} for _ in models];rnj_tables=[{} for _ in models]
    max_train=max_val=max_LP=0.;point_count=validation_count=accepted=crossing=0;index_tie_differences=0
    mask_audits=[]
    for (serial,a,b),(path,saved) in sorted(masks.items()):
        rh,xh,target=matrices(models[serial],n)
        assert {tuple(v) for v in saved['target_raw_positive_family']}==target
        p=np.concatenate((train[0],future[a][0],future[b][0]));q=np.concatenate((train[1],future[a][1],future[b][1]))
        y=np.concatenate((train[2],future[a][0]@rh.T+future[a][1]@xh.T,future[b][0]@rh.T+future[b][1]@xh.T))
        candidates=saved['candidate_points'];bank=saved['bank_points'];assert len(bank)==15
        matrices_cache=[]
        for candidate in candidates:
            r,x,_=matrices(candidate,n);matrices_cache.append((r,x))
            value=float(np.mean(abs(p@r.T+q@x.T-y)));difference=abs(value-candidate['objective'])
            max_train=max(max_train,difference);assert difference<=1e-8
            point_count+=1
        for lp in saved['LP_solves']:
            assert lp['status']==2 and lp['accepted']
            violation=max(lp['max_constraint_violation'],lp['max_bound_violation']);max_LP=max(max_LP,violation)
            assert violation<=1e-7 and abs(lp['physical']-lp['objective'])<=1e-8
        assert saved['LP_count']==len(saved['LP_solves']) and saved['coefficient_upper_bound'] is None
        proposal={tuple(v) for v in protocol['proposal_pool']}
        for trajectory in saved['paths'].values():
            assert trajectory['reason']=='pool_local_optimum'
            path_points=trajectory['path'];next_point=0
            for decision in trajectory['decisions']:
                current=path_points[next_point]
                assert abs(current['objective']-decision['current'])<=1e-11 and decision['full_sweep']
                family={tuple(s) for s in current['supports']};candidate_records=decision['candidates']
                expected={s for s in proposal if len(s)>1 and s not in family}
                assert {tuple(c['candidate']) for c in candidate_records}==expected
                winner=None
                for item in candidate_records:
                    c=set(item['candidate']);removed={s for s in family if c&set(s) and not c<=set(s) and not set(s)<=c}
                    assert {tuple(s) for s in item['removed']}==removed
                    if winner is None or item['objective']<winner['objective']-1e-12:winner=item
                gain=0. if winner is None else current['objective']-winner['objective']
                assert abs(gain-decision['gain'])<=1e-11
                if gain>1e-10+.001*current['objective']:
                    accepted+=1;crossing+=bool(winner['removed']);next_point+=1
                    assert next_point<len(path_points) and abs(path_points[next_point]['objective']-winner['objective'])<=1e-8
            assert next_point==len(path_points)-1
        old_cost=[];future_cost=[]
        for r,x in matrices_cache:
            old_cost.append(float(abs(valid[0]@r.T+valid[1]@x.T-valid[2]).sum()))
            future_cost.append({mask:float(abs(pp@r.T+qq@x.T-(pp@rh.T+qq@xh.T)).sum()) for mask,(pp,qq) in future.items()})
        assert len(saved['validation_results'])==16
        for detail in saved['validation_results']:
            va,vb=detail['validation_key'];fullkey=(a,b,va,vb)
            scores=[(oc+fc[va]+fc[vb])/(480*n) for oc,fc in zip(old_cost,future_cost)]
            validation_count+=1
            for prefix,count,table in (('wzzt',len(candidates),tables[serial]),('RNJ',15,rnj_tables[serial])):
                best=min(scores[:count]);eligible=[i for i in range(count) if scores[i]<=1.03*best+1e-12]
                expected_index=min(eligible,key=lambda i:(len(candidates[i]['supports']),scores[i],i))
                stored_index=detail[prefix+'_selected_index']
                assert stored_index in eligible and len(candidates[stored_index]['supports'])==min(len(candidates[i]['supports']) for i in eligible)
                if expected_index!=stored_index:
                    assert abs(scores[expected_index]-scores[stored_index])<=1e-12
                    index_tie_differences+=1
                raw=candidates[stored_index];selected=contract(raw,cal);r,x,fam=matrices(selected,n)
                detail_point=detail['selected_wzzt' if prefix=='wzzt' else 'selected_RNJ']
                sr,sx,sfam=matrices(detail_point,n)
                assert fam==sfam and np.max(abs(r-sr))<=1e-12 and np.max(abs(x-sx))<=1e-12
                computed_loss=len(fam^target);assert computed_loss==detail[prefix+'_loss']
                table[fullkey]=computed_loss
                post=(float(abs(valid[0]@r.T+valid[1]@x.T-valid[2]).sum())+
                      sum(float(abs(future[mask][0]@r.T+future[mask][1]@x.T-(future[mask][0]@rh.T+future[mask][1]@xh.T)).sum()) for mask in (va,vb)))/(480*n)
                max_val=max(max_val,abs(scores[stored_index]-detail[prefix+'_raw_selection_mae']),abs(post-detail[prefix+'_postcontract_mae']))
                assert abs(scores[stored_index]-detail[prefix+'_raw_selection_mae'])<=1e-11 and abs(post-detail[prefix+'_postcontract_mae'])<=1e-11
        mask_audits.append(dict(model_serial=serial,training_key=[a,b],path=str(path),sha256=sha(path),
            candidate_points=len(candidates),LP_count=len(saved['LP_solves']),validation_states=16,status='passed'))
    result=dict(status='complete' if len(masks)==32 else 'partial',template=template,
        completed_training_masks=len(masks),expected_training_masks=32,candidate_points_checked=point_count,
        validation_states_checked=validation_count,accepted_moves_checked=accepted,accepted_crossing_moves_checked=crossing,
        maximum_training_L1_difference=max_train,maximum_validation_L1_difference=max_val,
        maximum_LP_saved_violation=max_LP,numerical_tie_selection_index_differences=index_tie_differences,
        missing_or_unresolved_keys=pending,mask_audits=mask_audits,conditional_claim_only=True,
        planner_status=final['status'],planning_source_closure_matches=True,
        nonplanning_source_drift_verified_against_snapshot=nonplanning_drift,source_snapshot_sha256=snapshot_sha)
    if len(masks)==32:
        assert final['status']=='complete' and final['training_pairs_completed']==32
        assert final['accepted_moves']==accepted and final['accepted_crossing_moves']==crossing
        mean={key:sum(F(table[key]) for table in tables)/len(tables) for key in tables[0]}
        mean_r={key:sum(F(table[key]) for table in rnj_tables)/len(rnj_tables) for key in rnj_tables[0]}
        assert len(mean)==256
        for item in final['response_table']:
            key=tuple(item['key']);assert float(mean[key])==item['wzzt_mean'] and float(mean_r[key])==item['RNJ_mean']
            assert item['wzzt_by_hypothesis']==[t[key] for t in tables]
        menus=menu_set();assert len(menus)==50;scores={}
        for law in ('local','common'):
            computed=[]
            for i,menu in enumerate(menus):
                dist=menu_distribution(menu,law);fee,worst=fees(menu,dist)
                val=sum(mass*mean[key] for key,mass in dist.items());rval=sum(mass*mean_r[key] for key,mass in dist.items())
                saved=final['scores'][law]['records'][i]
                assert abs(float(val)-saved['expected_loss'])<=1e-12 and abs(float(fee)-saved['expected_fee'])<=1e-12 and abs(float(worst)-saved['worst_fee'])<=1e-12
                assert abs(float(rval)-final['scores'][law]['RNJ_menu_records'][i]['expected_loss'])<=1e-12
                seed=protocol['identity']['tie_seed'];tie=hashlib.sha256(f'{seed}|2|'.encode()+menu.tobytes()).hexdigest()
                assert tie==saved['tie_key']
                computed.append((val,fee,tie,i))
            optimum=min(float(v[0]) for v in computed);eligible=[v for v in computed if float(v[0])<=optimum+1e-12]
            chosen=min(eligible,key=lambda v:(v[1],v[2],v[3]))[3]
            assert chosen==final['scores'][law]['selected_index']
            assert menus[chosen].tolist()==final['scores'][law]['selected_menu']
            scores[law]=dict(selected_index=chosen,selected_menu=menus[chosen].tolist(),
                best_expected_loss=optimum,expected_fee=float(computed[chosen][1]),
                distinct_menu_losses=len({v[0] for v in computed}),menus_checked=50)
        result.update(price_scores=scores,response_table_states=256,template_result_sha256=sha(saved_result_path))
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--planning-root',type=Path,required=True)
    p.add_argument('--template',choices=['same','opposed','alternating_opposed'],required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--require-complete',action='store_true');a=p.parse_args()
    if a.output.exists():raise RuntimeError('Existing independent audit record retained')
    result=template_audit(a.planning_root,a.template,a.require_complete)
    result.update(created_utc=datetime.now(timezone.utc).isoformat(),audit_source_sha256=sha(__file__),
        solver_calls=0,AC_calls=0,new_profiles_generated=0,actual_or_true_files_read=False,parent_functions_imported=False)
    if result['status']=='pending':print(json.dumps(result));raise SystemExit(3)
    a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='mask_audits'},ensure_ascii=False))
