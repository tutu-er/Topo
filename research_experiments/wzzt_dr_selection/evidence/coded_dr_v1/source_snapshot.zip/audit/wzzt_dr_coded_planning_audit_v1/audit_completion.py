"""Preserve full planning completion/timeout denominators, without re-solving."""
from collections import Counter
from datetime import datetime,timezone
import hashlib,json
from pathlib import Path

root=Path(r'C:\Users\23761\.codex\visualizations\2026\10\25\01a1726e-8ec7-7bc1-9f18-391f9cf79a1a\wzzt_dr_coded_planning_v1')
out=Path(__file__).parent/'planning_completion_index.json'
if out.exists():raise RuntimeError('Existing completion audit retained')
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cfg=read(root/'protocol.json');overall=read(root/'case_plans.json')
summary=[];all_status=Counter();LP_status=Counter();LP_total=0;failed=[]
for template in cfg['templates']:
    td=root/'planning'/template
    local=Counter();local_LP=0
    for model in range(2):
        for a in range(4):
            for b in range(4):
                p=td/'training_masks'/f'm{model}_u{a}_{b}.json'
                if not p.exists():local['not_started']+=1;continue
                r=read(p);local[r['status']]+=1
                solves=r.get('LP_solves',[]);local_LP+=len(solves)
                LP_status.update(str(v['status']) for v in solves)
                if r['status']!='complete':
                    failed.append(dict(template=template,model_serial=model,training_key=[a,b],
                        status=r['status'],exception=r.get('exception'),LP_calls=len(solves),
                        last_LP=solves[-1] if solves else None,path=str(p),sha256=sha(p)))
    result=read(td/'plan_result.json') if (td/'plan_result.json').exists() else None
    if result is not None:assert local_LP==result['LP_calls']
    assert sum(local.values())==32
    all_status.update(local);LP_total+=local_LP
    summary.append(dict(template=template,training_mask_statuses=dict(local),LP_calls=local_LP,
        planner_status=result['status'] if result else 'not_started',
        integrated_menu_scores_available=bool(result is not None and result['status']=='complete'),
        missing_losses_filled=False))
assert overall['status']=='planning_unresolved' and overall['no_zero_fallback']
assert LP_total==overall['LP_calls']==2868
assert dict(all_status)==dict(complete=58,unresolved=1,not_started=37)
assert dict(LP_status)=={'2':2867,'9':1}
receipt=dict(status='passed',created_utc=datetime.now(timezone.utc).isoformat(),
    audit_source_sha256=sha(__file__),overall_status=overall['status'],
    planned_training_mask_records=96,training_mask_statuses=dict(all_status),
    LP_calls=LP_total,LP_statuses=dict(LP_status),templates=summary,partial_records=failed,
    full_three_template_price_rule_available=False,zero_price_fallback_used=False,
    unstarted_locked_panel_cases=7,scope='Saved planning status only; conditional masks are not independent experimental samples',
    inputs_sha256={'protocol.json':sha(root/'protocol.json'),'case_plans.json':sha(root/'case_plans.json')},
    no_new_LP=True,no_new_AC=True,no_new_profile=True,no_actual_or_truth_read=True)
out.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('partial_records','inputs_sha256')},ensure_ascii=False))
