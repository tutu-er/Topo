"""Continuous signed Gaussian DR and frozen-candidate conditional probability.

All residuals use micro p.u.^2.  This is a probability evaluator, not a new
topology identifier.  Its analytic derivative is of the finite conditional
integration approximation at regular points; global interchange of derivative
and expectation is NOT asserted by numerical derivative checks.
"""
from __future__ import annotations

import numpy as np
from scipy.linalg import null_space
from conditional_integral import conditional_probability


class ConditionalProblem:
    def __init__(self, packet, samples, seed):
        self.p = packet
        self.shape = tuple(packet['shape'])
        self.m = int(packet['mu_C'].size)
        self.samples = int(samples)
        self.weights = np.r_[np.ones(self.m), -packet['kappa']*np.ones(self.m)]/self.m
        self.b = np.r_[packet['L_C']@packet['direction'], packet['L_F']@packet['direction']]
        rng = np.random.default_rng(seed)
        eta = rng.normal(size=(samples, packet['complement'].shape[1]))
        zbase = eta@packet['complement'].T
        self.a0 = np.concatenate([
            packet['mu_C'][None]+zbase@packet['L_C'].T,
            packet['mu_F'][None]+zbase@packet['L_F'].T], axis=1)
        zresponse = rng.normal(size=(samples, int(np.prod(self.shape))))
        # Optional fixed factor preserves correlated execution multipliers.
        if packet.get('response_factor') is not None:
            zresponse = zresponse@packet['response_factor'].T
        self.multiplier = 1.+np.asarray(packet['cv'])*zresponse.reshape((samples,)+self.shape)
        self.last_x = self.last_result = None
        self.evaluations = 0

    def evaluate(self, flat_u):
        u = np.asarray(flat_u, float).reshape(self.shape)
        if self.last_x is not None and np.array_equal(u, self.last_x):
            return self.last_result
        delivered = self.multiplier*u[None]
        ec = np.einsum('nr,srt->stn', self.p['effect_C'], delivered).reshape(self.samples,-1)
        ef = np.einsum('nr,srt->stn', self.p['effect_F'], delivered).reshape(self.samples,-1)
        aa = self.a0+np.concatenate([ec,ef],axis=1)
        values, gradients, invalid, diagnostics = [], [], [], []
        for i in range(self.samples):
            r = conditional_probability(aa[i], self.b, self.weights, self.p['threshold'])
            values.append(r['probability'])
            diagnostics.append(r.get('diagnostics', {}))
            if not r['gradient_valid']:
                invalid.append(i)
                gradients.append(np.zeros(self.shape))
                continue
            ga = r['coeff_grad_a']
            gc = ga[:self.m].reshape(self.shape[1],-1)@self.p['effect_C']
            gf = ga[self.m:].reshape(self.shape[1],-1)@self.p['effect_F']
            gradients.append((gc+gf).T*self.multiplier[i])
        result = dict(probability=float(np.mean(values)),
            gradient=np.mean(gradients,axis=0).ravel() if not invalid else None,
            invalid_indices=invalid, conditional_values=np.asarray(values),
            conditional_mc_se=float(np.std(values,ddof=1)/np.sqrt(self.samples)) if self.samples>1 else 0.,
            gradient_scope='finite fixed integration approximation only; no global smoothness theorem',
            diagnostics=diagnostics)
        self.last_x = u.copy();self.last_result = result;self.evaluations += 1
        return result

    def cost(self, flat_u):
        u=np.asarray(flat_u).reshape(self.shape)
        return float(self.p['dt']*np.sum(u*u/self.p['elasticities']))

    def cost_gradient(self, flat_u):
        u=np.asarray(flat_u).reshape(self.shape)
        return (2*self.p['dt']*u/self.p['elasticities']).ravel()


def integration_direction(mu_c,mu_f,lc,lf,kappa):
    """Fix a history-only nonzero base factor; no future or true topology."""
    g=(np.sign(mu_c)@lc-kappa*np.sign(mu_f)@lf)/mu_c.size
    if np.linalg.norm(g)==0:
        _,_,vh=np.linalg.svd(np.vstack([lc,lf]),full_matrices=False)
        g=vh[0]
    if np.linalg.norm(g)==0:
        raise ValueError('no nonzero historical factor for the proposed smoothing direction')
    direction=g/np.linalg.norm(g)
    return direction,null_space(direction[None,:])
