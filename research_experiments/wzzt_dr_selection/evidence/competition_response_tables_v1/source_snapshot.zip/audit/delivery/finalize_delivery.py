"""Update delivery documentation bindings and verify the published archive.

No observed/physical trajectories are loaded and no solver is called.
"""
from __future__ import annotations
import ast
import gzip
import hashlib
import json
from pathlib import Path
import zipfile

BASE = Path(r'C:\Users\23761\.codex\visualizations\2026\10\25\01a1726e-8ec7-7bc1-9f18-391f9cf79a1a')
REPO = Path(r'C:\Users\23761\.codex\worktrees\wzzt-dr-selection\Topo')
ROOT = BASE / 'wzzt_dr_competition_delivery_v1'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    manifest = json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
    source = ROOT/'source_snapshot.zip'
    with zipfile.ZipFile(source) as z:
        contents = {i.filename:(i,z.read(i.filename)) for i in z.infolist()}
    for name in ('README.md','NEXT_CODED_DR.md'):
        member = 'current/research_experiments/wzzt_dr_selection/dr_competition_bridge/' + name
        info,_ = contents[member]
        contents[member] = info,(REPO/member[len('current/'):]).read_bytes()
    export_member = 'audit/delivery/finalize_delivery.py'
    contents[export_member] = zipfile.ZipInfo(export_member),Path(__file__).read_bytes()
    temporary = ROOT/'source_snapshot.updated.zip'
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED) as z:
        for name,(info,data) in sorted(contents.items()):
            z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED)
    temporary.replace(source)
    manifest['source_members'] = {name:sha(data) for name,(_,data) in sorted(contents.items())}
    manifest['files'] = {p.name:dict(sha256=sha(p.read_bytes()),bytes=p.stat().st_size)
                        for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='manifest.json'}
    manifest['delivery_notes'] = 'Read README; published fitted results are filtered copies; doc-only clarifications at delivery.'
    (ROOT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    # Read-back, source bindings, private trajectory extensions and syntax checks.
    for name,m in manifest['files'].items():
        data=(ROOT/name).read_bytes()
        assert sha(data)==m['sha256'] and len(data)==m['bytes'],name
    parsed=0;members=0
    for name in ('source_snapshot.zip','actual_fits.zip','stage_records.zip'):
        with zipfile.ZipFile(ROOT/name) as z:
            assert z.testzip() is None
            for entry in z.namelist():
                assert Path(entry).suffix.lower() not in ('.pkl','.pickle','.npz','.npy','.rdata'),entry
                data=z.read(entry);members+=1
                if name=='source_snapshot.zip':
                    assert sha(data)==manifest['source_members'][entry],entry
                if entry.endswith('.py'):
                    ast.parse(data.decode('utf-8-sig'),filename=entry);parsed+=1
    records=json.loads(gzip.decompress((ROOT/'actual_records.json.gz').read_bytes()))
    assert len(records)==64
    assert sha(gzip.decompress((ROOT/'actual_records.json.gz').read_bytes()))==manifest['compressed_records']['actual_records.json.gz']['uncompressed_sha256']
    print(json.dumps(dict(files=len(manifest['files'])+1,archive_members=members,
                         python_members_parsed=parsed,actual_records=len(records),
                         bytes=sum(p.stat().st_size for p in ROOT.iterdir() if p.is_file()),
                         checked=True)))

if __name__=='__main__':main()
