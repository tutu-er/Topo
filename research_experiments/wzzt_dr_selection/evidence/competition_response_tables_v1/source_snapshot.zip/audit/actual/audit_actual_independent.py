"""Independent actual-pilot replay: data/physics/matrix arithmetic, no solvers.

Does not import parent supports/evaluate_supports/summarize or regenerate any
profile/AC solution. True topology comes from the frozen data-only builder.
"""
from __future__ import annotations
import argparse
from collections import Counter,deque
from datetime import datetime,timezone
import hashlib
import importlib
import json
from pathlib import Path
import pickle
import sys
import numpy as np
import pandas as pd


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def stamp(text):return datetime.fromisoformat(text)


def true_graph(archive):
    sys.path.insert(0,str(archive/'source'))
    module=importlib.import_module('rnj_wzzt.data.paper_style_terminal_lv')
    assert Path(module.__file__).resolve().is_relative_to((archive/'source').resolve())
    net=module.build_paper_style_terminal_lv_case() # data only, no context/profile/AC
    scale=float(net.metadata['impedance_scale'])
    assert net.base_kv==.4 and net.base_mva==.2 and scale==5.
    # The original reference suite replaces builder multiplier5 by1.
    buses=net.buses.copy();branches=net.branches.copy()
    branches.loc[:,['r_ohm','x_ohm']]/=scale
    manifest=read(archive/'manifest.json')
    for name in ('buses.csv','branches.csv','metadata.json'):
        rel='networks/paper15/reference/'+name
        assert sha(archive/rel)==manifest[rel]
    recorded=pd.read_csv(archive/'networks/paper15/reference/branches.csv')
    assert np.allclose(branches[['r_ohm','x_ohm']],recorded[['r_ohm','x_ohm']],rtol=0,atol=1e-15)
    labels=buses.loc[buses.bus_type.eq('observed_terminal'),'bus_id'].astype(int).tolist()
    adjacency={int(v):[] for v in buses.bus_id};edge={}
    for row in branches.itertuples():
        if not bool(row.is_true_closed):continue
        u,v=int(row.from_bus),int(row.to_bus)
        adjacency[u].append(v);adjacency[v].append(u)
        edge[frozenset((u,v))]=(float(row.r_ohm)/(.4**2/.2),float(row.x_ohm)/(.4**2/.2))
    root=int(net.root_bus);parent={root:None};order=[];queue=deque([root])
    while queue:
        u=queue.popleft();order.append(u)
        for v in adjacency[u]:
            if v==parent[u]:continue
            assert v not in parent,'cycle'
            parent[v]=u;queue.append(v)
    assert len(order)==22 and len(edge)==21 and root==1 and labels==list(range(101,116))
    descendants={u:({u} if u in labels else set()) for u in order}
    family=set()
    for u in reversed(order):
        if parent[u] is None:continue
        par=parent[u];r,x=edge[frozenset((par,u))]
        if (r!=0 or x!=0) and descendants[u]:family.add(tuple(sorted(descendants[u])))
        descendants[par]|=descendants[u]
    assert len(family)==21
    return labels,order,parent,edge,family,sha(module.__file__)


def predicted(point,labels):
    supports=point.get('support_indices',point['supports'])
    r=np.asarray(point.get('r_values',point['r']),float)
    x=np.asarray(point.get('x_values',point['x']),float)
    assert len(supports)==len(r)==len(x) and min(r.min(),x.min())>=0
    rr=np.zeros((len(labels),len(labels)));xx=rr.copy();family=set()
    for support,rv,xv in zip(supports,r,x):
        idx=np.asarray(support,int)
        rr[np.ix_(idx,idx)]+=rv;xx[np.ix_(idx,idx)]+=xv
        if rv>0 or xv>0:family.add(tuple(sorted(labels[i] for i in idx)))
    if 'support_labels' in point:
        assert {tuple(sorted(v)) for v in point['support_labels']}=={tuple(sorted(labels[i] for i in s)) for s in supports}
    for key,value in (('r_matrix',rr),('x_matrix',xx),('R',rr),('X',xx)):
        if key in point:assert np.max(abs(np.asarray(point[key])-value))<=1e-12
    return family,rr,xx


def history(row,role,labels):
    entry=row[role];path=Path(entry['path'])
    assert path.name==role+'_observed.npz' and sha(path)==entry['catalog_sha256']
    with np.load(path,allow_pickle=False) as z:
        assert list(z['labels'])==labels
        values={k:z[k].copy() for k in ('P','Q','V','root')}
    assert values['P'].shape==(3,96,15) and values['root'].shape==(3,96)
    start=0 if role=='train' else 3
    index=pd.date_range(pd.Timestamp('2000-01-01')+pd.Timedelta(days=start),periods=288,freq='15min')
    return [pd.DataFrame(values[k].reshape(288,15),index=index,columns=labels) for k in ('P','Q','V')]+[pd.Series(values['root'].reshape(288),index=index)]


def concatenate(old,days):
    keys=('P_terminal','Q_terminal','V_terminal','V_root_observed')
    data=[pd.concat([old[i]]+[d[key] for d in days]) for i,key in enumerate(keys)]
    assert len(data[0])==480 and data[0].index.is_unique
    h=hashlib.sha256()
    for value in data:h.update(pd.util.hash_pandas_object(value,index=True).values.tobytes())
    h.update(json.dumps(list(data[0].columns),default=str).encode())
    h.update(json.dumps([str(t.normalize()) for t in data[0].index]).encode())
    p,q,v,root=(v.to_numpy(float) for v in data)
    return p,q,root[:,None]**2-v**2,h.hexdigest()


def physical_arithmetic(event,labels,buses,edge):
    ac=event['ac'];n=len(buses);pos={v:i for i,v in enumerate(buses)}
    pp=np.zeros((96,n));qq=pp.copy()
    pp[:,[pos[v] for v in labels]]=event['P_pu'];qq[:,[pos[v] for v in labels]]=event['Q_pu']
    vin=ac['V_bus_mag'].reindex(columns=buses).to_numpy()
    pin=np.zeros_like(pp);pout=pin.copy();qin=pin.copy();qout=pin.copy()
    maxloss=maxvoltage=0.
    for branch in ac['metadata']['branch_edges']:
        key,u,v=branch['label'],int(branch['from_bus']),int(branch['to_bus'])
        pf,pt,qf,qt=(ac[name][key].to_numpy() for name in ('branch_p_from_pu','branch_p_to_pu','branch_q_from_pu','branch_q_to_pu'))
        pin[:,pos[v]]+=pt;pout[:,pos[u]]+=pf;qin[:,pos[v]]+=qt;qout[:,pos[u]]+=qf
        r,x=edge[frozenset((u,v))];ell=ac['I_branch_mag'][key].to_numpy()**2
        maxloss=max(maxloss,float(np.max(abs(ac['branch_loss_p_pu'][key].to_numpy()-r*ell))),float(np.max(abs(ac['branch_loss_q_pu'][key].to_numpy()-x*ell))))
        identity=vin[:,pos[u]]**2-vin[:,pos[v]]**2-2*(r*pf+x*qf)+(r*r+x*x)*ell
        maxvoltage=max(maxvoltage,float(np.max(abs(identity))))
    nonroot=[pos[v] for v in buses if v!=1]
    nodal=max(float(np.max(abs((pin-pout-pp)[:,nonroot]))),float(np.max(abs((qin-qout-qq)[:,nonroot]))))
    system=max(float(np.max(abs(pout[:,pos[1]]-pp.sum(axis=1)-ac['branch_loss_p_pu'].sum(axis=1).to_numpy()))),float(np.max(abs(qout[:,pos[1]]-qq.sum(axis=1)-ac['branch_loss_q_pu'].sum(axis=1).to_numpy()))))
    assert bool(ac['converged'].all()) and vin.shape==(96,22)
    assert np.max(abs(vin[:,[pos[v] for v in labels]]-event['V_pu']))<=1e-13
    assert np.max(abs(vin[:,pos[1]]-event['root_pu']))<=1e-13
    assert max(nodal,system,maxloss,maxvoltage)<=1e-8
    assert vin.min()>=.9 and vin.max()<=1.1
    assert np.max(abs(event['P_pu']))*200.<=45.+1e-12
    return dict(nodal=nodal,system=system,branch_loss=maxloss,distflow=maxvoltage)


def run(root):
    cfg=read(root/'protocol.json');actual_cfg=read(root/'actual_protocol.json')
    rows=read(root/'actual_records.json');summary=read(root/'actual_summary.json');prices=read(root/'planning_summary.json')
    assert len(rows)==64 and len({r['record_id'] for r in rows})==64 and summary['planned']==64
    sources={}
    for owner in (cfg,actual_cfg):
        for key in ('source_sha256','physical_source_sha256'):
            for p,h in owner.get(key,{}).items():assert sha(p)==h;sources[p]=h
    archive=Path(r'D:\0-github_workspace\Topo\outputs\wzzt_paper_20261029_full')
    labels,buses,parents,edge,truth,builder_sha=true_graph(archive)
    cases={r['job_id']:r for r in cfg['cases']}
    expected={(r['job_id'],law,path,policy) for r in cfg['cases'] for law in cfg['actual']['dependence'] for path in cfg['actual']['paths'] for policy in actual_cfg['policies']}
    assert {(r['job_id'],r['dependence'],r['path'],r['policy']) for r in rows}==expected
    locks={};earliest=None
    for case in prices['cases']:
        for law,entry in case['locks'].items():
            assert sha(entry['path'])==entry['sha256']
            lock=read(entry['path']);assert lock['status']=='frozen' and lock['future_read_before_freeze'] is False
            locks[(case['job_id'],law)]=(entry,lock)
    old={key:{role:history(row,role,labels) for role in ('train','validation')} for key,row in cases.items()}
    stops={}
    for key,row in cases.items():
        entry=row['existing_result'];assert sha(entry['path'])==entry['catalog_sha256']
        saved=read(entry['path']);stops[key]={}
        for name in ('RNJ_L1_bank','multistart'):
            fam,_,_=predicted(saved['models'][name],labels)
            stops[key][name]=len(fam^truth)
    anchor={};natural_reps=set();fits={};fit_audits=[];record_audits=[];maxphysics={k:0. for k in ('nodal','system','branch_loss','distflow')}
    costs=Counter();unknown=0;events=0;maxmeter=0.;maxdelta=0.;fitlossdiff=0.;LPcount=0;LPviolation=0.
    for row in rows:
        assert row['status']=='complete'
        actual_dir=root/'actual'/row['record_id']/'physical'
        receipt=read(actual_dir/'events_receipt.json');assert receipt==row['physical']
        entry,lock=locks[(row['job_id'],row['dependence'])]
        assert receipt['plan_lock_sha256_expected']==entry['sha256']
        assert stamp(lock['created_utc'])<=stamp(actual_cfg['created_utc'])<=stamp(receipt['started_utc'])<=stamp(receipt['completed_utc'])
        earliest=min(earliest,stamp(receipt['started_utc'])) if earliest else stamp(receipt['started_utc'])
        assert receipt['status']=='complete' and receipt['physical_events_complete']==4 and receipt['zero_clip'] and not receipt['automatic_retry']
        assert receipt['budget_pass'] and receipt['all_operation_checks_pass'] and not receipt['old_test_or_truth_files_read']
        for path,h in receipt['source_sha256'].items():assert sha(path)==h
        for name,spec in receipt['private_files'].items():assert sha(actual_dir/name)==spec['sha256']
        packet=pickle.loads((actual_dir/'packet.pkl').read_bytes());private=pickle.loads((actual_dir/'physical_truth.pkl').read_bytes())
        assert set(packet)=={'training','validation','metadata'} and len(packet['training'])==len(packet['validation'])==2
        assert packet['metadata']['base_kw']==200. and packet['metadata']['base_mva']==.2 and packet['metadata']['base_kv']==.4
        assert packet['metadata']['interval_hours']==.25 and packet['metadata']['observed_only']
        truefile=read(actual_dir/'truth_evaluation.json');assert {tuple(v) for v in truefile['true_supports']}==truth
        plan=np.asarray(lock['plans'][row['policy']],int);assert plan.shape==(2,15) and np.isin(plan,[0,1,2]).all()
        worst=.4*plan.sum();assert worst<=1.6+1e-12 and abs(receipt['worst_payment']-worst)<=1e-12
        payment=0.
        for event_index,(event,er,observed) in enumerate(zip(private['events'],receipt['event_records'],packet['training']+packet['validation'])):
            events+=1;natural_reps.add(er['replicate'])
            assert event['event']==event_index==er['event'] and er['status']=='complete'
            assert er['replicate']==cfg['actual']['replicate_base']+10*row['path']+event_index
            assert er['profile_index']==cfg['actual']['event_profiles'][event_index]
            uniform=np.random.default_rng(np.random.SeedSequence([cfg['seeds']['participation'],row['path'],event_index]))
            u=uniform.random(15) if row['dependence']=='local' else np.repeat(uniform.random(),15)
            z=u<np.array([0.,.5,.75])[plan[event_index%2]]
            assert np.array_equal(z,event['participants']) and z.astype(int).tolist()==er['participants']
            dp=np.zeros((96,15));dq=dp.copy();dp[76:80]=-.001*z;dp[80:84]=.001*z;dq[76:80]=-.00035*z;dq[80:84]=.00035*z
            natural_p,natural_q=event['P_pu']-dp,event['Q_pu']-dq
            key=(row['path'],event_index)
            if key not in anchor:anchor[key]=(natural_p.copy(),natural_q.copy(),event['root_pu'].copy())
            deviation=max(float(np.max(abs(natural_p-anchor[key][0]))),float(np.max(abs(natural_q-anchor[key][1]))),float(np.max(abs(event['root_pu']-anchor[key][2]))))
            maxdelta=max(maxdelta,deviation);assert deviation<=2e-15
            assert np.max(abs(dp.sum(axis=0)*200*.25))<=1e-12
            fee=.2*float(plan[event_index%2]@z);payment+=fee
            assert abs(fee-er['actual_payment'])<=1e-12 and abs(fee-er['checks']['actual_payment'])<=1e-12
            metric=physical_arithmetic(event,labels,buses,edge)
            for k,v in metric.items():maxphysics[k]=max(maxphysics[k],v)
            # Replay only metering draws; no natural profiles or AC are generated.
            profile_seed=([42,7,21][er['profile_index']]+100003*er['replicate'])
            assert profile_seed==er['profile_seed']
            rng=np.random.default_rng(profile_seed+2000)
            truths=(event['P_pu'],event['Q_pu'],event['V_pu'])
            sigmas=(.005,.005,row['voltage_sigma'])
            for name,true,sigma in zip(('P_terminal','Q_terminal','V_terminal'),truths,sigmas):
                expected_meter=true+rng.normal(0,sigma*np.maximum(abs(true),1e-12),size=true.shape)
                error=float(np.max(abs(observed[name].to_numpy()-expected_meter)));maxmeter=max(maxmeter,error);assert error<=1e-13
            rng=np.random.default_rng(70000019+100003*er['replicate']+er['profile_index'])
            expected_root=event['root_pu']+rng.normal(0,row['voltage_sigma']*np.maximum(abs(event['root_pu']),1e-12),size=96)
            maxmeter=max(maxmeter,float(np.max(abs(observed['V_root_observed'].to_numpy()-expected_root))))
            assert np.max(abs(observed['V_root_observed'].to_numpy()-expected_root))<=1e-13
            target=expected_root[:,None]**2-observed['V_terminal'].to_numpy()**2
            assert np.array_equal(target,observed['drop_target'].to_numpy())
        if row.get('actual_payment') is None:unknown+=1
        else:assert abs(row['actual_payment']-payment)<=1e-12
        costs[row['policy']]+=payment
        assert abs(receipt['actual_payment']-payment)<=1e-12 and payment<=worst+1e-12
        train=concatenate(old[row['job_id']]['train'],packet['training'])
        valid=concatenate(old[row['job_id']]['validation'],packet['validation'])
        hashes={'training':train[3],'validation':valid[3]}
        finger=hashlib.sha256(json.dumps([train[3],valid[3]],sort_keys=True,separators=(',',':')).encode()).hexdigest()
        assert finger==row['observed_fingerprint'] and hashes==row['fit_input_sha256']
        if row['fit_path'] not in fits:
            fit=read(row['fit_path']);assert fit['status']=='complete' and not fit['truth_input_allowed']
            assert fit['input_sha256']==hashes and fit['training_rows']==fit['validation_rows']==480 and fit['terminal_labels']==labels
            for lp in fit['LP_solves']:
                assert lp['status']==2 and lp['accepted']
                violation=max(lp['max_constraint_violation'],lp['max_bound_violation']);LPviolation=max(LPviolation,violation)
                assert violation<=1e-7 and abs(lp['objective']-lp['physical'])<=1e-8
            LPcount+=len(fit['LP_solves']);per_model={}
            for name,point in fit['models'].items():
                fam,rr,xx=predicted(point,labels)
                losses=[]
                for split,arrays in (('training',train),('validation',valid)):
                    p,q,y,_=arrays;mae=float(np.mean(abs(p@rr.T+q@xx.T-y)))
                    stored=point['train_mae'] if split=='training' else point['validation_mae']
                    diff=abs(mae-stored);fitlossdiff=max(fitlossdiff,diff);assert diff<=1e-11
                    losses.append(mae)
                errors=len(fam^truth)
                assert errors==row['evaluation'][name]['full_block_errors']==0
                per_model[name]=dict(full_block_errors=errors,training_L1=losses[0],validation_L1=losses[1])
            fits[row['fit_path']]=per_model
            fit_audits.append(dict(fit_path=row['fit_path'],fit_sha256=sha(row['fit_path']),LP_calls=len(fit['LP_solves']),models=per_model))
        for name,metrics in fits[row['fit_path']].items():assert row['evaluation'][name]['full_block_errors']==metrics['full_block_errors']
        for name,errors in stops[row['job_id']].items():assert row['stop_evaluation'][name]['full_block_errors']==errors
        assert row['all_local_scans_complete'] and row['training_rows']==row['validation_rows']==480
        record_audits.append(dict(record_id=row['record_id'],status='passed',actual_payment=payment,fit_path=row['fit_path']))
    assert unknown==0 and len(fits)==44 and events==256 and len(natural_reps)==4
    for group in summary['policy_groups']:
        assert group['records']==group['complete']==group['payment_known_records']==group['structure_denominator']==8
        assert group['payment_unknown_records']==0 and group['wzzt_total_errors']==group['RNJ_total_errors']==0
        assert abs(group['known_actual_payment']-costs[group['policy']])<=1e-10
    return dict(status='passed',independent_implementation=True,parent_evaluation_imported=False,
        actual_records=64,unique_fits=44,models_per_fit=3,LP_calls_unique=LPcount,physical_events=256,
        physical_times=256*96,distinct_natural_replicates=sorted(natural_reps),independent_natural_paths=1,
        actual_payment_known_records=64,actual_payment_unknown_records=unknown,policy_payment=dict(costs),
        max_original_L1_replay_difference=fitlossdiff,max_LP_constraint_or_bound_violation=LPviolation,
        max_replayed_physical_residuals=maxphysics,max_meter_replay_error=maxmeter,
        max_common_natural_trajectory_difference=maxdelta,true_effective_supports=[list(s) for s in sorted(truth)],
        stop_errors=stops,all_RNJ_and_WZZT_actual_errors_zero=True,source_hashes_checked=len(sources),
        true_builder_sha256=builder_sha,price_freeze_precedes_every_actual_event=True,
        no_new_solver_calls=True,no_new_AC_calls=True,no_new_profiles_generated=True,
        claim='One paired synthetic four-day path; no statistical coverage or independent64 sample claim; no paid-DR recovery gain',
        fit_audits=fit_audits,record_audits=record_audits)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=Path(__file__).parent)
    args=parser.parse_args();output=args.root/'audit_actual_independent.json'
    if output.exists():raise RuntimeError('Existing audit receipt retained')
    result=run(args.root);result['created_utc']=datetime.now(timezone.utc).isoformat();result['audit_source_sha256']=sha(__file__)
    result['input_sha256']={name:sha(args.root/name) for name in ('protocol.json','actual_protocol.json','actual_records.json','actual_summary.json','planning_summary.json')}
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('fit_audits','record_audits','true_effective_supports','input_sha256','stop_errors')},ensure_ascii=False))
