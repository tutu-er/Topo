"""Independent metadata-only supplement for original/derived price locks."""
from datetime import datetime,timezone
import hashlib,json
from pathlib import Path

root=Path(__file__).parent
read=lambda path:json.loads(Path(path).read_text(encoding='utf-8'))
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
output=root/'audit_freeze_bindings.json'
if output.exists():raise RuntimeError('Existing supplementary receipt retained')
cfg=read(root/'actual_protocol.json');original=Path(cfg['planning_root'])
assert sha(root/'planning_summary.json')==cfg['derived_summary_sha256']
assert sha(root/'protocol.json')==cfg['planning_protocol_sha256']
assert sha(original/'protocol.json')==cfg['planning_protocol_sha256']
assert sha(original/'planning_summary.json')==cfg['planning_summary_sha256']
checks=0
for record in read(root/'actual_records.json'):
    for name,digest in record['physical']['runtime_sha256'].items():
        path=(Path(r'D:\0-github_workspace\Topo\outputs\wzzt_paper_20261029_full\source')
              .joinpath(*name.split('.')).with_suffix('.py')) if name.startswith('rnj_wzzt.') else Path(name)
        assert sha(path)==digest
        checks+=1
assert checks==512
receipt=dict(status='passed',created_utc=datetime.now(timezone.utc).isoformat(),
    independent_implementation=True,protocol_summary_bindings=4,runtime_source_hash_checks=checks,
    main_audit_sha256=sha(root/'audit_actual_independent.json'),audit_source_sha256=sha(__file__),
    NPZ_reads=0,new_profiles=0,solver_calls=0,AC_calls=0,
    note='Metadata-only supplement; no new samples or recovery experiments')
output.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
