"""Post-hoc observable-X control, kept separate from the 96 locked checks."""
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np

sys.path.insert(0,str(Path.cwd()))
from research_experiments.wzzt_dr_selection import completion_bounds as bounds
from research_experiments.wzzt_dr_selection.completion_audit import BranchCache
from research_experiments.wzzt_dr_selection.experiment import save

run=Path(__file__).resolve().parent
target=run/'x_only_followup.json'
if target.exists():
    raise RuntimeError('Post-hoc evidence already exists; do not overwrite')
source=run/'x_sum.json'
prior=json.loads(source.read_text(encoding='utf-8'))
P,Q,Y=(np.asarray(prior['history'][k],float) for k in ('P','Q','Y'))
assert np.all(P==0) and np.linalg.matrix_rank(Q)==P.shape[0]
cache=BranchCache(P,Q,Y)
rows=[]
with patch.object(bounds,'matrix_relaxation_fit',side_effect=cache):
    for old in prior['candidates']:
        C=old['C']
        b=bounds.block_omission_lower_bound(P,Q,Y,C,coefficient=(0,1))
        assert b['success']
        assert b['lower_bound']<=old['reference_upper']+1e-7
        rows.append({'C':C,'reference_lower':old['reference_lower'],
                     'reference_upper':old['reference_upper'],
                     'sum_matrix_lower':old['matrix_lower'],
                     'X_matrix_lower':b['lower_bound'],'bound':b})
save(target,{'scope':'post-hoc channel control; not part of locked 96 checks',
             'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
             'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'coefficient':[0,1],'selection_reason':'P is zero and Q has full row rank; X is observable',
             'new_complete_family_fits':0,'reused_complete_family_fits':len(prior['family_fits']),
             'matrix_branch_calls':cache.calls,'cache_hits':cache.hits,'blocks':rows})
print([(r['C'],r['sum_matrix_lower'],r['X_matrix_lower']) for r in rows])
