"""Read-only final AC/PQV replay; no optimizer calls."""
from pathlib import Path
import json,pickle,hashlib
import numpy as np
from research_experiments.wzzt_dr_selection.dr_paper15_update.study import inputs,read,sha
from research_experiments.wzzt_dr_selection.dr_paper15_update.eiv_diagnostic import fixed_sigmas
from research_experiments.wzzt_dr_selection.dr_paper15_update.ac_family_refit import predict_ac
from research_experiments.wzzt_dr_selection.dr_pool_v2.observations import normalize
root=Path(r'C:\Users\23761\.codex\visualizations\2026\10\25\01a1726e-8ec7-7bc1-9f18-391f9cf79a1a\wzzt_dr_paper15_eiv_scale_v2')
p=read(root/'protocol.json');rows=[]
for path,h in p['source_sha256'].items():
    if sha(path)!=h:raise RuntimeError('frozen source drift '+path)
for case in p['cases']:
    tr,va=inputs(case['parent_case']);obs=normalize(tr,'training')[0];sigma=fixed_sigmas(obs,case['voltage_sigma_relative'])
    for cand in case['candidates']:
        folder=root/case['id']/str(cand['index']);result=read(folder/'result.json');f=result['training']
        private=folder/'latent_training.pkl'
        if sha(private)!=f['private_latent_sha256']:raise RuntimeError('latent hash mismatch')
        state=pickle.loads(private.read_bytes());values=state['fitted']
        latent=(values['P_terminal'],values['Q_terminal'],obs[2],values['root_voltage'])
        pred=predict_ac(f['point'],latent,base_kv=.4,base_mva=.2)['voltage']
        residuals=dict(P_terminal=(values['P_terminal']-obs[0])/sigma.p,
            Q_terminal=(values['Q_terminal']-obs[1])/sigma.q,V_terminal=(pred-obs[2])/sigma.v,
            root_voltage=(values['root_voltage']-obs[3])/sigma.root_v)
        loss=sum(float(np.sum(x.to_numpy()**2)) for x in residuals.values())
        max_error=max(float(np.max(np.abs(residuals[k].to_numpy()-state['standardized_residuals'][k].to_numpy()))) for k in residuals)
        if abs(loss-f['loss'])>1e-8*max(1.,loss) or max_error>1e-7:raise RuntimeError('final EIV physical replay mismatch')
        rows.append(dict(case=case['id'],candidate=cand['index'],status=result['status'],loss_replayed=loss,
            reported_loss=f['loss'],max_standardized_residual_difference=max_error,private_hash_matched=True,
            scale_variant=f['numerical_scaling'][0]['variant'],success_flag=f['success']))
out=dict(status='passed',scope='four final training physical/residual replays; no optimization or convergence claim',
         optimizer_calls=0,records=rows,source_sha256=sha(__file__),protocol_sha256=sha(root/'protocol.json'))
(root/'audit_latent_replay.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=out['status'],records=len(rows),max_residual_difference=max(r['max_standardized_residual_difference'] for r in rows))))
