"""Independent raw/contract output audit. No fitting, solver or AC calls.

Deliberately does not import guard/select/measure or their input loaders.
Only standard JSON/pickle and direct frame/matrix arithmetic are used for the
selection check. Physical reference, if needed, is loaded after outputs exist.
"""
from __future__ import annotations
from pathlib import Path
import json,hashlib,pickle
import numpy as np
import pandas as pd

SCRATCH=Path(r'C:\Users\23761\.codex\visualizations\2026\10\25\01a1726e-8ec7-7bc1-9f18-391f9cf79a1a')

def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):return pickle.loads(Path(path).read_bytes())

def observation(scene):
    root=scene.get('V_root_observed',scene.get('root_voltage'))
    p,q,v=[scene[k] for k in ('P_terminal','Q_terminal','V_terminal')]
    assert isinstance(root,pd.Series)
    assert p.index.equals(q.index) and p.index.equals(v.index) and p.index.equals(root.index)
    assert p.columns.equals(q.columns) and p.columns.equals(v.columns)
    assert p.index.is_unique and p.columns.is_unique
    assert all(np.isfinite(x.to_numpy()).all() for x in (p,q,v,root))
    return p,q,v,root

def combine(scenes):
    frames=list(zip(*(observation(s) for s in scenes)))
    obs=tuple(pd.concat(x,axis=0) for x in frames)
    assert obs[0].index.is_unique and obs[0].index.is_monotonic_increasing
    return obs

def old_inputs(case):
    if case['kind']=='strict_past':
        p=load(case['packet']);return combine(p['training']),combine(p['validation'])
    source=Path(case['source_run']);summary=read(source/'summary.json')
    scenes=[load(source/'history'/(d+'.pkl'))['observed'] for d in summary['wzzt_training_dates']]
    scenes.append(load(source/'strategies/no_reward/action.pkl')['simulation']['observed'])
    assert len(scenes)==4
    step=96//case['N'];rows=np.arange(0,24,step)
    training=[]
    for scene in scenes:
        p,q,v,root=observation(scene)
        assert len(p)==24 and isinstance(p.index,pd.DatetimeIndex)
        expected=pd.date_range(p.index[0].normalize(),periods=24,freq='h')
        assert p.index.equals(expected)
        training.append(dict(P_terminal=p.iloc[rows],Q_terminal=q.iloc[rows],V_terminal=v.iloc[rows],root_voltage=root.iloc[rows]))
    valid=load(source/'strategies/no_reward/validation.pkl')['simulation']['observed']
    result=combine(training),combine([valid])
    assert len(result[0][0])==case['N'] and len(result[1][0])==24
    assert not result[0][0].index.intersection(result[1][0].index).size
    return result

def point(point):
    return {k:point[k] for k in ('supports','r','x')}

def fingerprint(point):
    p=point
    entries=sorted((tuple(s),float(r),float(x)) for s,r,x in zip(p['supports'],p['r'],p['x'],strict=True))
    return hashlib.sha256(json.dumps(entries,separators=(',',':')).encode()).hexdigest()

def contract_independent(raw,cal):
    entries=[]
    tau=.16*float(cal['median_root_depth'])
    for s,r,x in zip(raw['supports'],raw['r'],raw['x'],strict=True):
        if len(s)==1 or float(cal['a'])*r+float(cal['b'])*x+1e-10>=tau:entries.append((s,r,x))
    return dict(supports=[x[0] for x in entries],r=[x[1] for x in entries],x=[x[2] for x in entries])

def response_matrices(point,n):
    rmat=np.zeros((n,n));xmat=np.zeros((n,n))
    for support,r,x in zip(point['supports'],point['r'],point['x'],strict=True):
        assert r>=0 and x>=0
        z=np.zeros(n);z[np.asarray(support,dtype=int)]=1
        rmat+=float(r)*np.outer(z,z);xmat+=float(x)*np.outer(z,z)
    return rmat,xmat

def losses(p,obs):
    pp,qq,v,root=obs;r,x=response_matrices(p,len(pp.columns))
    target=np.square(root.to_numpy())[:,None]-np.square(v.to_numpy())
    error=pp.to_numpy()@r.T+qq.to_numpy()@x.T-target
    return float(np.sum(np.abs(error))/error.size)

def choose_independent(raw,cal,train,val):
    contracted=contract_independent(raw,cal);pts=[point(raw),contracted]
    rows=[dict(variant=name,point=p,train_mae=losses(p,train),validation_mae=losses(p,val))
          for name,p in zip(('raw','contract'),pts,strict=True)]
    best=min(r['validation_mae'] for r in rows)
    eligible=[i for i,r in enumerate(rows) if r['validation_mae']<=1.03*best+1e-12]
    winner=min(eligible,key=lambda i:(len(rows[i]['point']['supports']),rows[i]['validation_mae'],i))
    return rows,winner,eligible

def obs_identity(obs):
    h=hashlib.sha256()
    for frame in obs:h.update(pd.util.hash_pandas_object(frame,index=True).values.tobytes())
    h.update(json.dumps(list(obs[0].columns)).encode())
    return h.hexdigest()

def effective(point,labels):
    return {tuple(sorted(labels[i] for i in s)) for s,r,x in zip(point['supports'],point['r'],point['x'],strict=True)
            if max(r,x)>1e-9}

def truth_after_outputs(labels):
    # Network construction only. No AC or estimation function is called.
    from research_experiments.wzzt_dr_selection.end_to_end.physical_case import build_reference_case
    net=build_reference_case('paper15');graph=net.to_networkx_graph()
    root=int(net.root_bus);parents={root:None};order=[root]
    for node in order:
        for child in graph.neighbors(node):
            if child==parents[node]:continue
            if child in parents:raise AssertionError('not a tree')
            parents[child]=node;order.append(child)
    descendants={node:({node} if node in labels else set()) for node in order}
    actual=set()
    for node in reversed(order):
        par=parents[node]
        if par is None:continue
        edge=graph.edges[par,node]
        if edge['r_ohm']!=0 or edge['x_ohm']!=0:
            support=tuple(sorted(descendants[node]))
            if support:actual.add(support)
        descendants[par].update(descendants[node])
    return actual

def metric(p,labels,truth):
    active=effective(p,labels)
    return dict(all_block_errors=len(active-truth)+len(truth-active),complete_effective_family=active==truth,
                extra=[list(s) for s in sorted(active-truth,key=lambda x:(len(x),x))],
                missing=[list(s) for s in sorted(truth-active,key=lambda x:(len(x),x))])

def normalized_input_hash(obs):
    h=hashlib.sha256()
    for frame in obs:h.update(pd.util.hash_pandas_object(frame,index=True).values.tobytes())
    h.update(json.dumps(list(obs[0].columns),default=str).encode())
    days=[str(v) for v in obs[0].index.normalize()]
    h.update(json.dumps(days).encode())
    return h.hexdigest()

def close(actual,expected,name):
    if not np.isclose(actual,expected,rtol=1e-11,atol=1e-12):
        raise AssertionError(f'{name}: {actual} != {expected}')

def compare_choice(choice,rows,winner,eligible):
    assert choice['status']=='complete' and choice['chosen_index']==winner
    assert choice['eligible_indices']==eligible
    assert not choice['fitted'] and not choice['AC_called'] and not choice['truth_input']
    for saved,replay in zip(choice['candidate_points'],rows,strict=True):
        assert fingerprint(saved)==fingerprint(replay['point'])
        close(saved['objective'],replay['train_mae'],'candidate train MAE')
        close(saved['validation_mae'],replay['validation_mae'],'candidate validation MAE')
    assert fingerprint(choice['point'])==fingerprint(rows[winner]['point'])
    close(choice['point']['objective'],rows[winner]['train_mae'],'selected train')
    close(choice['point']['validation_mae'],rows[winner]['validation_mae'],'selected validation')
    best=min(row['validation_mae'] for row in rows)
    close(choice['best_validation'],best,'best validation')
    close(choice['eligibility_threshold'],1.03*best+1e-12,'eligibility threshold')

def independent_mechanism(common):
    raw=dict(supports=[[0],[1],[0,1]],r=[.1,.1,common],x=[.1,.1,common])
    r,x=response_matrices(raw,2)
    means=[]
    for m in (r,x):
        distances=np.diag(m)[:,None]+np.diag(m)[None,:]-2*m
        means.append(float(np.mean(distances[distances>0])))
    a=.75/means[0];b=.25/means[1];median=float(np.median(np.diag(a*r+b*x)))
    cal=dict(a=a,b=b,median_root_depth=median)
    def obs(scale,date):
        u=scale*(np.eye(4)+np.ones((4,4)));p,q=u[:,:2],u[:,2:]
        y=p@r.T+q@x.T;ix=pd.date_range(date,periods=4,freq='h');labels=[101,102]
        return (pd.DataFrame(p,index=ix,columns=labels),pd.DataFrame(q,index=ix,columns=labels),
                pd.DataFrame(np.sqrt(1-y),index=ix,columns=labels),pd.Series(np.ones(4),index=ix))
    return raw,cal,obs(.01,'2021-01-01'),obs(.013,'2021-01-02')

def audit(root):
    root=Path(root);protocol=read(root/'protocol.json');summary=read(root/'summary.json')
    assert summary['status']=='complete' and summary['planned']==summary['finished']==summary['complete']==15
    assert summary['failed']==0 and summary['new_LP_calls']==summary['new_AC_calls']==summary['new_fits']==0
    assert summary['new_future_data'] is False and summary['protocol_sha256']==sha(root/'protocol.json')
    assert protocol['planned_development_records']==15 and protocol['planned_mechanism_checks']==2
    assert protocol['settings']['compare']==['given fitted raw','original contract of that raw']
    assert protocol['settings']['final_contraction'] is False
    for f,h in protocol['source_sha256'].items():assert sha(f)==h,('source drift',f)
    for f,h in protocol['input_sha256'].items():assert sha(f)==h,('input drift',f)
    mechanisms=[]
    for name,common,expected in [('positive_weak',.01,0),('zero_common',0.,1)]:
        item=next(c for c in summary['mechanism_checks'] if c['name']==name)
        assert item==read(root/('mechanism_'+name+'.json'))
        assert item['status']=='passed' and item['expected_chosen_index']==expected
        raw,cal,train,val=independent_mechanism(common)
        rows,winner,eligible=choose_independent(raw,cal,train,val)
        assert winner==expected
        compare_choice(item['choice'],rows,winner,eligible)
        for k in ('a','b','median_root_depth'):close(item['calibration'][k],cal[k],'mechanism '+k)
        close(item['calibration']['tau'],.16*cal['median_root_depth'],'mechanism tau')
        assert np.linalg.matrix_rank(np.c_[train[0].to_numpy(),train[1].to_numpy()])==item['input_rank']==4
        mechanisms.append(dict(name=name,status='passed',chosen_index=winner,
            raw_validation=rows[0]['validation_mae'],contract_validation=rows[1]['validation_mae']))
    records=[];seen={};identities=set();selected_points=[]
    assert len(summary['records'])==15 and len(summary['evaluations'])==15
    for case in protocol['cases']:
        train,val=old_inputs(case);original=read(case['original_fit']);labels=list(train[0].columns)
        assert list(val[0].columns)==labels==original['terminal_labels']
        hashes=dict(training=normalized_input_hash(train),validation=normalized_input_hash(val))
        assert hashes==original['input_sha256']
        for model in protocol['models']:
            item=next(r for r in summary['records'] if r['case']==case['id'] and r['model']==model)
            assert item==read(root/(case['id']+'__'+model+'.json'))
            assert item['status']=='complete' and item['original_fit_sha256']==sha(case['original_fit'])
            assert item['input_sha256']==hashes
            old=original['models'][model];raw=point(old['selected_uncontracted']);cal=original['calibrations']['raw']
            raw={k:([[int(i) for i in s] for s in v] if k=='supports' else [float(a) for a in v]) for k,v in raw.items()}
            rows,winner,eligible=choose_independent(raw,cal,train,val)
            assert fingerprint(rows[1]['point'])==fingerprint(old)
            compare_choice(item['choice'],rows,winner,eligible)
            encoded=dict(point=raw,observations=hashes,calibration=cal)
            identity=hashlib.sha256(json.dumps(encoded,sort_keys=True,separators=(',',':')).encode()).hexdigest()
            assert item['identity']==identity
            assert item['reused_choice']==(identity in seen)
            if identity in seen:assert item['choice']==seen[identity]
            else:seen[identity]=item['choice']
            identities.add(identity)
            changed=fingerprint(rows[winner]['point'])!=fingerprint(rows[1]['point'])
            assert item['changed_output']==changed
            close(item['validation_change'],rows[winner]['validation_mae']-rows[1]['validation_mae'],'validation change')
            assert rows[winner]['validation_mae']<=rows[1]['validation_mae']+1e-12
            selected_points.append((case['id'],model,labels,rows,winner))
            records.append(dict(case=case['id'],model=model,status='passed',chosen_index=winner,
                changed_output=changed,reused=item['reused_choice'],identity=identity,
                raw_train_mae=rows[0]['train_mae'],raw_validation_mae=rows[0]['validation_mae'],
                contract_validation_mae=rows[1]['validation_mae'],new_validation_mae=rows[winner]['validation_mae']))
    assert len(identities)==summary['unique_choices']==7
    assert sum(r['changed_output'] for r in records)==summary['changed_outputs']==2
    # Only after all 15 independent selections have passed, load physical net.
    truth=truth_after_outputs(selected_points[0][2]);evaluations=[]
    for case,model,labels,rows,winner in selected_points:
        saved=next(r for r in summary['evaluations'] if r['case']==case and r['model']==model)
        m={name:metric(p,labels,truth) for name,p in [('raw',rows[0]['point']),('old_contract',rows[1]['point']),('new',rows[winner]['point'])]}
        for name,item in m.items():
            expected=saved['metrics'][name]
            assert item['all_block_errors']==expected['all_block_errors']
            assert item['complete_effective_family']==expected['complete_effective_family']
            assert item['extra']==expected['extra_effective_supports'] and item['missing']==expected['missing_effective_supports']
        evaluations.append(dict(case=case,model=model,old_errors=m['old_contract']['all_block_errors'],
            new_errors=m['new']['all_block_errors'],old_complete=m['old_contract']['complete_effective_family'],
            new_complete=m['new']['complete_effective_family']))
    out=dict(status='passed',scope='independent matrices, raw observed losses, contraction/selection, dedup and post-selection physical structure',
        protocol_sha256=sha(root/'protocol.json'),summary_sha256=sha(root/'summary.json'),audit_script_sha256=sha(__file__),
        source_files_verified=len(protocol['source_sha256']),input_files_verified=len(protocol['input_sha256']),
        mechanism_checks=mechanisms,model_records=len(records),unique_choices=len(identities),changed_outputs=2,
        rows=records,evaluations=evaluations,
        new_LP_calls=0,new_AC_calls=0,new_fits=0,new_future_data=False,
        guard_select_measure_imported=False,truth_loaded_after_selection_replay=True,
        conclusions='postprocessing-only development check; no independent DR benefit or global identification guarantee')
    (root/'audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:out[k] for k in ('status','model_records','unique_choices','changed_outputs')},ensure_ascii=False))
    print(json.dumps([e for e in evaluations if e['old_errors']!=e['new_errors']],ensure_ascii=False))
    return out

if __name__=='__main__':
    audit(SCRATCH/'wzzt_dr_output_guard_v1')
