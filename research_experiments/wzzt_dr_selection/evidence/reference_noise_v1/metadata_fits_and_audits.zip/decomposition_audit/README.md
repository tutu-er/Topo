# One saved-fit decomposition witness

This is a bounded, post-selection algebra check for `voltage_only`, `case_007`, truth pair `[0,2]`, b=.4, c=.6, snapshot `s_602c8cc264d072fcc944`, method `current_root_augmented_rnj`. It uses existing outputs and observations only. Truth is used solely to check the saved raw and final support after identification.

Observed Q equals .35P to numerical precision (maximum discrepancy 2.17e-19 in both splits). Consequently the raw prediction depends on each block through `cfit = r + .35x`. Holding this value fixed while allowing the unchanged `0 <= r,x <= 2` gives

```text
max(0,(cfit-2)/.35) <= x <= min(2,cfit/.35),
r = cfit - .35x.
```

The output strength is `s = a*r + b*x = a*cfit + (b-.35a)*x`. In this example `a=.4191994476596714`, `b=.39922326906543193` and `tau=.1134318692957733`. For the common-root block, `cfit=.2082623052696725`, so `x` may range from 0 to .59503515791335. Strength ranges from .08730344333737658 to .23755188095103313 and crosses tau at x=.10347749576045323.

The saved solution uses `(r,x)=(.2082623052696725,0)` and loses the true positive common-root block in contraction. Replacing only that pair by `(0,.59503515791335)` leaves every combined block coefficient and the full `K=R+.35X` matrix unchanged in exact arithmetic, stays in the original coefficient box, and retains the root under the same contraction. In the corrected v2 numerical arrays the maximum combined-matrix difference is 2.78e-17. Other coefficients and all rules remain unchanged.

Training and validation each contain 480 observations. Maximum raw prediction difference is 3.47e-18 in both splits; training L1 is exactly unchanged and validation L1 differs by 1.08e-19. The original contracted validation L1 is .0031299301733922753, whereas contraction of the alternative raw decomposition gives .00044309017946166063, equal to raw validation L1 at rounding accuracy. Raw and alternative contracted supports both match the saved evaluation target; the original contraction omits the root.

This establishes output dependence on an unidentifiable R/X decomposition in this case. For fixed cfit, `a*r+b*x` is invariant only when `b=.35a`, or when the feasible x interval is a point. Neither condition holds here. This diagnosis concerns the fixed calibration/contraction after raw fitting. It does not establish a new parameter estimate, justify removing contraction, or demonstrate a deployable recovery improvement. Arbitrarily weak blocks may still lie below the threshold for every feasible decomposition. No conclusion for the power-noise groups is inferred from this single collinear-input witness.

The first numerical implementation computed the endpoint r as `cfit-.35*(cfit/.35)`, which produced -2.78e-17 through floating-point cancellation. That implementation and output are preserved as `audit_v1.py`, `receipt_v1.json`, and `algebra_arrays_v1.npz` (the original unversioned output files are also retained). Version 2 explicitly sets the endpoint r to 0.0 and checks every r/x against the strict nonnegative [0,2] box. This makes the numerical witness itself nonnegative rather than relying on tolerance. The resulting tiny combined-matrix difference is reported rather than hidden.

The current `audit.py` records source/input hashes, checks predictions and raw losses, and writes `receipt_v2.json` plus small coefficient/matrix arrays in `algebra_arrays_v2.npz`. V2 also records hashes of all three preserved v1 files. No observations or full trajectories are copied into this output. No LP, QP, AC calculation, simulation, new data generation, or changes to saved records were performed.
