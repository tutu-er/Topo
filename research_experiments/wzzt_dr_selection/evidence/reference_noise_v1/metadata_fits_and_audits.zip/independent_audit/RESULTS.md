# Independent reference-noise mechanism audit

Completed saved-output audit only. No new fitting, LP, QP, or AC calls.

33 snapshots; 72 truth-policy mappings; 5536 independent checks passed. Every regime has 12 named cases but 10 distinct generating R/X models. One shared random stream was used, so the following are conditional case counts, not recovery probabilities.

## Raw and final support results

Errors are complete missed-plus-extra effective blocks; full denotes zero errors. The same current calibration, 3% validation selection, and .16 contraction were replayed.

| Noise | Policy | Method | Raw errors | Final errors | Raw full | Final full |
|---|---|---|---:|---:|---:|---:|
| combined_reference | pair_random | all_legal_family_reference | 8 | 8 | 4/12 | 4/12 |
| combined_reference | pair_random | current_pool_wzzt | 8 | 8 | 4/12 | 4/12 |
| combined_reference | pair_random | current_rebuilt_rnj | 20 | 20 | 1/12 | 1/12 |
| combined_reference | pair_random | current_root_augmented_rnj | 10 | 8 | 4/12 | 4/12 |
| combined_reference | zero_sham | all_legal_family_reference | 18 | 18 | 0/12 | 0/12 |
| combined_reference | zero_sham | current_pool_wzzt | 24 | 24 | 1/12 | 1/12 |
| combined_reference | zero_sham | current_rebuilt_rnj | 24 | 24 | 1/12 | 1/12 |
| combined_reference | zero_sham | current_root_augmented_rnj | 18 | 18 | 2/12 | 2/12 |
| power_only | pair_random | all_legal_family_reference | 5 | 5 | 8/12 | 8/12 |
| power_only | pair_random | current_pool_wzzt | 4 | 3 | 8/12 | 9/12 |
| power_only | pair_random | current_rebuilt_rnj | 16 | 16 | 3/12 | 3/12 |
| power_only | pair_random | current_root_augmented_rnj | 6 | 3 | 6/12 | 9/12 |
| power_only | zero_sham | all_legal_family_reference | 12 | 12 | 3/12 | 3/12 |
| power_only | zero_sham | current_pool_wzzt | 12 | 12 | 3/12 | 3/12 |
| power_only | zero_sham | current_rebuilt_rnj | 24 | 24 | 1/12 | 1/12 |
| power_only | zero_sham | current_root_augmented_rnj | 12 | 12 | 3/12 | 3/12 |
| voltage_only | pair_random | all_legal_family_reference | 8 | 8 | 4/12 | 4/12 |
| voltage_only | pair_random | current_pool_wzzt | 13 | 14 | 2/12 | 2/12 |
| voltage_only | pair_random | current_rebuilt_rnj | 17 | 17 | 1/12 | 1/12 |
| voltage_only | pair_random | current_root_augmented_rnj | 4 | 12 | 8/12 | 3/12 |
| voltage_only | zero_sham | all_legal_family_reference | 18 | 18 | 0/12 | 0/12 |
| voltage_only | zero_sham | current_pool_wzzt | 18 | 18 | 0/12 | 0/12 |
| voltage_only | zero_sham | current_rebuilt_rnj | 18 | 18 | 0/12 | 0/12 |
| voltage_only | zero_sham | current_root_augmented_rnj | 18 | 18 | 0/12 | 0/12 |

## WZZT versus same-information formal RNJ plus optional root

| Noise | Policy | W better | Same | W worse |
|---|---|---:|---:|---:|
| voltage_only | zero_sham | 0 | 12 | 0 |
| voltage_only | pair_random | 2 | 6 | 4 |
| power_only | zero_sham | 0 | 12 | 0 |
| power_only | pair_random | 0 | 12 | 0 |
| combined_reference | zero_sham | 4 | 0 | 8 |
| combined_reference | pair_random | 0 | 12 | 0 |

The old RNJ result without an optional common root cannot isolate a WZZT advantage. Under power-only and combined reference noise, the formal RNJ+root and WZZT final errors are equal in every DR case. Under voltage-only noise, neither method dominates.

## Where the missing blocks were lost

In voltage-only DR, current WZZT had a saved exact-support family in eight named cases where final output missed a true block: five lost to the 3% simplicity rule; three duplicate c=0 cases selected another eligible equal-size family by validation/index. Two other missing blocks were positive in some saved fit but no complete true family was saved. One additional true root block was removed at contraction. These are stored-path observations, not a proof that the omitted truth is globally excluded.

For formal RNJ+root in voltage-only DR, raw complete recovery was 8/12 and final 3/12. Contraction removed eight true blocks: seven full-root blocks (including the three duplicate c=0 names) and one strong internal block. The same rule helped under power-only DR: raw 6/12 became final 9/12 because three false roots in the b=0 cases were removed. Uniformly reducing the contraction threshold is therefore unsupported.

For combined reference-noise DR, current WZZT missed eight true blocks: six after 3% simplicity chose a smaller saved family, one positive in a saved fit but not in the raw selected point, and one absent from the fitted/pool support slots. The latter describes only this candidate source, not mathematical impossibility.

## Scope

All 72 mappings had unresolved direct-control discovery and unchanged expanded/current pools. The source requires a predeclared response/model-error band and none was supplied in these regimes. Thus this run evaluates raw randomized DR input and current identifiers; it does not validate a noisy code-derived candidate rule or a new price optimizer.

The data establish a useful conditional DR effect versus the matched no-reward observations in this deliberately synchronized input example. They do not establish a WZZT-specific price-design benefit, multi-seed recovery probability, or general network performance.

Machine-readable per-case block traces and replay checks remain in audit_v1.json. mechanism_summary_v1.json contains the compact aggregate and formal-root contraction cases.
