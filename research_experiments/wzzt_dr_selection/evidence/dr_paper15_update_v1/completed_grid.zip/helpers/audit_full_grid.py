"""Independent first-development-case arithmetic/AC replay; no optimizers."""
from __future__ import annotations
from collections import Counter
import hashlib,json,pickle
from pathlib import Path
import numpy as np
import pandas as pd
import networkx as nx
from rnj_wzzt.models.network import TerminalizedNetwork
from rnj_wzzt.models.ac_powerflow import solve_ac_power_flow_timeseries
from research_experiments.rnj.graph_adapters import rooted_tree_from_clades

REPO=Path(r'C:\Users\23761\.codex\worktrees\wzzt-dr-selection\Topo')
ROOT=Path(r'C:\Users\23761\.codex\visualizations\2026\10\25\01a1726e-8ec7-7bc1-9f18-391f9cf79a1a\wzzt_dr_paper15_update_v1')

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return pickle.loads(Path(p).read_bytes())
def canonical(f):return tuple(sorted(set(tuple(sorted(s)) for s in f),key=lambda s:(len(s),s)))

def pack(item,rows=None):
    d=item['observed'];p=d['P_terminal'];rows=np.arange(len(p)) if rows is None else rows
    return tuple(d[k].iloc[rows].copy() for k in ('P_terminal','Q_terminal','V_terminal','root_voltage'))

def collect(case):
    if case['kind']=='strict_past':
        data=load(case['packet'])
        def scene(s):return tuple(s[k] for k in ('P_terminal','Q_terminal','V_terminal','V_root_observed'))
        train=[scene(s) for s in data['training']];valid=[scene(s) for s in data['validation']]
        return tuple(pd.concat([p[j] for p in train]) for j in range(4)),tuple(pd.concat([p[j] for p in valid]) for j in range(4))
    src=Path(case['source_run']);s=read(src/'summary.json');step=96//case['N']
    parts=[pack(load(src/'history'/(d+'.pkl')),np.arange(0,24,step)) for d in s['wzzt_training_dates']]
    parts.append(pack(load(src/'strategies/no_reward/action.pkl')['simulation'],np.arange(0,24,step)))
    return tuple(pd.concat([p[j] for p in parts]) for j in range(4)),pack(load(src/'strategies/no_reward/validation.pkl')['simulation'])

def input_hash(obs):
    h=hashlib.sha256()
    for v in obs:h.update(pd.util.hash_pandas_object(v,index=True).values.tobytes())
    h.update(json.dumps(list(obs[0].columns),default=str).encode());h.update(json.dumps([str(v) for v in obs[0].index.normalize()]).encode())
    return h.hexdigest()

def kernels(point,n):
    r=np.zeros((n,n));x=r.copy()
    for s,ri,xi in zip(point['supports'],point['r'],point['x'],strict=True):
        r[np.ix_(s,s)]+=ri;x[np.ix_(s,s)]+=xi
    return r,x

def linear_loss(point,obs):
    p,q,v,root=obs;r,x=kernels(point,p.shape[1]);y=root.to_numpy()[:,None]**2-v.to_numpy()**2
    return float(np.mean(np.abs(p.to_numpy()@r.T+q.to_numpy()@x.T-y)))

def independent_net(point,labels,kv,mva):
    # Different converter: build graph from clades, then map each edge by its
    # descendant terminals. No algorithm bridge or physical network input.
    n=len(labels);family=canonical(point['supports']);full=tuple(range(n))
    clades=frozenset(frozenset(labels[i] for i in s) for s in family if 1<len(s)<n)
    tree=rooted_tree_from_clades(clades,labels,1,include_hidden_root_stem=full in family)
    g=nx.Graph();g.add_weighted_edges_from(tree.edges);dg=nx.bfs_tree(g,1)
    values={tuple(s):(ri,xi) for s,ri,xi in zip(point['supports'],point['r'],point['x'],strict=True)}
    positions={v:i for i,v in enumerate(labels)};branches=[];seen=set()
    for parent,child in dg.edges:
        desc=nx.descendants(dg,child)|{child};support=tuple(sorted(positions[t] for t in labels if t in desc))
        assert support in values,support;seen.add(support);ri,xi=values[support]
        branches.append(dict(from_bus=parent,to_bus=child,r_ohm=.5*ri*kv**2/mva,x_ohm=.5*xi*kv**2/mva,
                             is_true_closed=True,branch_type='independent_audit'))
    assert seen==set(family)
    buses=pd.DataFrame([dict(bus_id=node,bus_type='root' if node==1 else 'observed_terminal' if node in labels else 'hidden_internal',
                            is_observed=node==1 or node in labels,has_load=node in labels) for node in g.nodes])
    return TerminalizedNetwork(buses,pd.DataFrame(branches),1,kv,mva,{v:v for v in labels},{v:v for v in labels},{'scope':'candidate-only audit'})

def ac_loss(point,obs,kv,mva):
    p,q,v,root=obs;net=independent_net(point,list(p.columns),kv,mva)
    ac=solve_ac_power_flow_timeseries(net,p,q,v_root=root,max_iter=200,tol=1e-12)
    assert ac['converged'].all()
    pred=ac['V_bus_mag'].loc[:,list(p.columns)].to_numpy()
    return float(np.mean(np.abs(pred**2-v.to_numpy()**2)))

def contract(point,cal):
    keep=[i for i,s in enumerate(point['supports']) if len(s)==1 or cal['a']*point['r'][i]+cal['b']*point['x'][i]+1e-10>=.16*cal['median_root_depth']]
    return {k:[point[k][i] for i in keep] for k in ('supports','r','x')}

def ismember(prov):
    return dict(rnj_refit=any(p['source']=='rnj_bank' and p['operation']=='parent' for p in prov),
                wzzt_refit=any(p['operation']=='parent' for p in prov),
                rnj_contractions=any(p['source']=='rnj_bank' for p in prov),wzzt_contractions=True)

def audit_one(case_id):
    protocol=read(ROOT/'development_protocol.json');case=next(c for c in protocol['cases'] if c['id']==case_id)
    folder=ROOT/'development'/case_id;linear=read(folder/'linear.json');ac=read(folder/'ac.json');result=read(folder/'case_result.json')
    original=read(case['original_fit']);train,valid=collect(case);labels=list(train[0].columns);n=len(labels)
    kv=protocol['settings']['base_kv'];mva=protocol['settings']['base_mva'];issues=[]
    def check(condition,message):
        if not condition:issues.append(message)
    def close(a,b,tol=2e-11):return abs(a-b)<=tol
    check(all(Path(p).exists() and sha(p)==h for p,h in protocol['source_sha256'].items()),'frozen source hash')
    check(all(Path(p).exists() and sha(p)==h for p,h in protocol['input_sha256'].items()),'frozen input hash')
    check(linear['input_sha256']=={'training':input_hash(train),'validation':input_hash(valid)},'input hashes')
    check(len(linear['candidates'])==len(ac['candidates'])==case['planned_families'],'candidate denominator')
    check(not linear['failures'] and not ac['failures'],'failures')
    expected={}
    def add_parent(family,source,identifier):
        family=canonical(family)
        for deleted in [None,*[s for s in family if len(s)>1]]:
            target=family if deleted is None else tuple(s for s in family if s!=deleted)
            event=dict(source=source,parent=identifier,operation='parent' if deleted is None else 'delete_one',deleted=deleted)
            expected.setdefault(target,set()).add(json.dumps(event,sort_keys=True))
    for index,point in enumerate(original['bank']):add_parent(point.get('native_family',point['supports']),'rnj_bank',f'bank_{index}:{point.get("config","")}')
    for name,path in original['searches'].items():
        for index,point in enumerate(path['path']):add_parent(point['supports'],'wzzt_path',f'{name}:{index}')
    ordered=sorted(expected,key=lambda f:(len(f),f))
    check(len(ordered)==case['planned_families'],'independent contraction count')
    for c,family in zip(linear['candidates'],ordered,strict=True):
        check(canonical(c['family'])==family,'independent family enumeration')
        check({json.dumps(v,sort_keys=True) for v in c['provenance']}==expected[family],'independent parent/delete provenance')
    for receipt in linear['LP_solves']:
        check(receipt['status']==2 and receipt['accepted'],'linear LP status')
        check(max(receipt['max_constraint_violation'],receipt['max_bound_violation'])<=1e-7,'linear LP constraint receipt')
    lc={c['index']:c for c in linear['candidates']};all_checks=[];inner_LPs=0;accepted=trials=0
    for c in ac['candidates']:
        index=c['index'];fit=c['fit'];family=canonical(c['family']);seed=lc[index]['point'];p=c['point']
        check(c['family']==lc[index]['family'] and c['provenance']==lc[index]['provenance'],f'candidate identity {index}')
        check(fit['success'] and fit['settings']['coefficient_bound']=='unbounded' and not fit['settings']['validation_used'],f'fit domain {index}')
        check(set(map(tuple,fit['native_point']['supports']))==set(family),f'native family {index}')
        check(all(np.isfinite(v) and v>=0 for k in ('r','x') for v in fit['native_point'][k]),f'nonnegative {index}')
        seed_lookup={tuple(s):(r,x) for s,r,x in zip(seed['supports'],seed['r'],seed['x'])}
        check(fit['initial_native_point']['r']==[seed_lookup.get(s,(0.,0.))[0] for s in family] and
              fit['initial_native_point']['x']==[seed_lookup.get(s,(0.,0.))[1] for s in family],f'training-only linear seed {index}')
        native=fit['native_point'];keep=[j for j,s in enumerate(native['supports']) if len(s)==1 or max(native['r'][j],native['x'][j])>fit['settings']['zero_tolerance']]
        check(all(p[k]==[native[k][j] for j in keep] for k in ('supports','r','x')),f'native effective pruning {index}')
        linear_tr=linear_loss(seed,train);linear_va=linear_loss(seed,valid)
        initial=ac_loss(fit['initial_native_point'],train,kv,mva);final=ac_loss(fit['native_point'],train,kv,mva)
        effective_tr=ac_loss(p,train,kv,mva);effective_va=ac_loss(p,valid,kv,mva)
        check(close(linear_tr,seed['objective']) and close(linear_va,seed['validation_mae']),f'linear loss {index}')
        check(close(initial,fit['initial_objective']) and close(final,fit['objective']),f'initial/final AC loss {index}')
        check(close(effective_tr,p['objective']) and close(effective_va,p['validation_mae']),f'effective AC score {index}')
        check(final<=initial+1e-12,f'AC monotonic final {index}')
        previous=initial
        check(len(fit['iterations'])<=3,f'iteration cap {index}')
        for step in fit['iterations']:
            check(close(step['current_objective'],previous),f'iteration chain {index}')
            check(all(t['alpha'] in (1.,.5,.25) for t in step['trials']),f'line steps {index}')
            trials+=len(step['trials'])
            if step['accepted']:
                accepted+=1;chosen=step['trials'][-1]
                check(chosen['alpha']==step['accepted_alpha'] and chosen['objective']<previous-1e-12,f'accepted threshold {index}')
                check(not any(t.get('objective',float('inf'))<previous-1e-12 for t in step['trials'][:-1]),f'first improving alpha {index}')
                previous=chosen['objective']
        check(close(previous,final),f'final trace chain {index}')
        inner_LPs+=len(fit['LP_solves'])
        for receipt in fit['LP_solves']:
            check(canonical(receipt['family'])==family,f'inner joint family {index}')
            check(receipt['status']==2 and receipt['accepted'],'inner LP status')
            check(max(receipt['max_constraint_violation'],receipt['max_bound_violation'])<=1e-7,'inner LP numerical constraint receipt')
        all_checks.append(dict(index=index,linear_train=linear_tr,linear_validation=linear_va,AC_initial_train=initial,AC_final_train=final,AC_validation=effective_va))
    selection=[]
    for mode,data in [('linear',linear),('AC',ac)]:
        for name,chosen in data['models'].items():
            members=[c for c in data['candidates'] if ismember(c['provenance'])[name]]
            points=[c['point'] for c in members];best=min(p['validation_mae'] for p in points)
            if 'candidate_counts' in data:check(data['candidate_counts'][name]==len(points),f'group count {mode}/{name}')
            if 'group_candidate_count' in chosen:check(chosen['group_candidate_count']==len(points),f'group count {mode}/{name}')
            eligible=[i for i,p in enumerate(points) if p['validation_mae']<=1.03*best+1e-12]
            index=min(eligible,key=lambda i:(len(points[i]['supports']),points[i]['validation_mae'],i));before=points[index]
            after=contract(before,original['calibrations']['raw'])
            check(chosen['selection_index']==index,f'select index {mode}/{name}')
            check(all(chosen[k]==after[k] for k in ('supports','r','x')),f'contract {mode}/{name}')
            lossfun=(lambda p,o:linear_loss(p,o)) if mode=='linear' else (lambda p,o:ac_loss(p,o,kv,mva))
            tr,va=lossfun(chosen,train),lossfun(chosen,valid)
            check(close(tr,chosen['objective']) and close(va,chosen['validation_mae']),f'contract rescore {mode}/{name}')
            selection.append(dict(mode=mode,group=name,members=len(points),index=index,global_candidate=members[index]['index'],train=tr,validation=va))
    # Reference topology/impedances enter after all fit and selection checks.
    from research_experiments.wzzt_dr_selection.end_to_end.physical_case import build_reference_case
    ref=build_reference_case('paper15');graph=ref.to_networkx_graph();dg=nx.bfs_tree(graph,ref.root_bus)
    true_r=np.zeros((n,n));true_x=true_r.copy();truth=set();zbase=ref.base_kv**2/ref.base_mva
    for parent,child in dg.edges:
        desc=nx.descendants(dg,child)|{child};support=tuple(i for i,t in enumerate(labels) if t in desc)
        ri=graph.edges[parent,child]['r_ohm'];xi=graph.edges[parent,child]['x_ohm']
        if not support or (ri==0 and xi==0):continue
        truth.add(support);true_r[np.ix_(support,support)]+=2*ri/zbase;true_x[np.ix_(support,support)]+=2*xi/zbase
    denom=np.sum(true_r**2)+np.sum(true_x**2);evaluation=[]
    for mode,data in [('original',original),('linear',linear),('AC',ac)]:
        for name,p in data['models'].items():
            rr,xx=kernels(p,n);relative=float(np.sqrt((np.sum((rr-true_r)**2)+np.sum((xx-true_x)**2))/denom))
            active={tuple(s) for s,r,x in zip(p['supports'],p['r'],p['x']) if max(r,x)>1e-9}
            reported=result[{'original':'original_evaluation','linear':'linear_evaluation','AC':'AC_evaluation'}[mode]][name]
            check(close(relative,reported['kernel_relative_RMSE']),f'kernel RMSE {mode}/{name}')
            check(len(active^truth)==reported['all_block_errors'],f'effective family errors {mode}/{name}')
            if mode=='original':
                check(close(ac_loss(p,train,kv,mva),reported['AC_training_mae']) and
                      close(ac_loss(p,valid,kv,mva),reported['AC_validation_mae']),f'original baseline AC score {name}')
            evaluation.append(dict(mode=mode,group=name,kernel_relative_RMSE=relative,all_block_errors=len(active^truth),complete=active==truth))
    receipt=dict(status='passed' if not issues else 'failed',issues=issues,no_new_fits=True,no_new_optimization=True,
        AC_forward_replay_only=True,candidates=case['planned_families'],linear_LP_receipts=len(linear['LP_solves']),AC_inner_LP_receipts=inner_LPs,
        trace_steps_accepted=accepted,trace_trials=trials,train_rows=len(train[0]),validation_rows=len(valid[0]),
        selection=selection,evaluation=evaluation,candidate_checks=all_checks,independent_family_enumeration_count=len(ordered),
        source_sha256={'audit_script':sha(__file__)},input_sha256={n:sha(folder/(n+'.json')) for n in ('linear','ac','case_result')},
        limitations=['Intermediate trial coefficients and corrected-target arrays were not recorded by frozen code. All numeric trace chains and solver status/constraint receipts checked, but intermediate trial physical predictions and LP primal solutions cannot be independently reconstructed without new fitting.',
        'Independent AC predictions use the existing core forward solver; candidate topology conversion is separately implemented via clade graph descendants, with no physical reference branch input.',
        'Truth kernel is reconstructed only for post-fit evaluation from repository-built paper15 reference branches with factor2; this is not an externally measured or published-network ground truth.',
        'This is a development case, not independent confirmation. Improved AC validation error does not prove improved line parameters.'])
    (ROOT/('audit_case_'+case_id+'.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:receipt[k] for k in ('status','issues','candidates','linear_LP_receipts','AC_inner_LP_receipts','trace_steps_accepted','trace_trials','train_rows','validation_rows','evaluation')}))
    return receipt


def audit_face(case):
    folder=ROOT/'development'/case['id'];data=read(folder/'zero_leaf_face.json');original=read(case['original_fit'])
    train,_=collect(case);issues=[]
    def check(condition,message):
        if not condition:issues.append(message)
    check(data['status']=='complete','face status')
    check(data['training_sha256']==input_hash(train),'face input hash')
    check(data['settings']['bound']=='unbounded' and not data['settings']['positive_weight_floor'],'face domain')
    tasks={}
    for name in data['model_names']:
        model=original['models'][name];source=model.get('selected_uncontracted',model)
        family=canonical(source.get('native_family',source['supports']))
        for block,r,x in zip(source['supports'],source['r'],source['x']):
            if len(block)==1 and max(r,x)<=data['settings']['zero_tolerance']:tasks.setdefault((family,tuple(block)),[]).append(name)
    check(len(tasks)==data['detected_zero_leaf_tasks'],'automatic zero-leaf tasks')
    base={canonical(v['family']):v for v in data['base_fits']}
    pool=canonical(s for family in base for s in family);k=len(pool);ranges={}
    for family,b in base.items():check(abs(linear_loss(b['point'],train)-b['solver_optimum'])<2e-11,'face base objective')
    for row in data['face_solves']:
        family=canonical(row['family']);leaf=tuple(row['leaf']);check((family,leaf) in tasks,'face target is automatic')
        check(row['status'] in (2,5),'face solver unresolved')
        if row['status']==5:
            check(row['value'] is None and row['classification']=='unbounded','unbounded face classification');continue
        values=np.asarray(row['all_coefficients']);check(len(values)==2*k,'face coefficient dimensions')
        check(np.isfinite(values).all() and values.min()>=-1e-7,'face nonnegative finite coefficients')
        idx=pool.index(leaf);value=float(values[idx]+values[k+idx])
        point=dict(supports=[list(s) for s in pool],r=values[:k],x=values[k:]);objective=linear_loss(point,train)
        check(abs(value-row['value'])<2e-10 and abs(objective-row['physical_mean_abs_error'])<2e-11,'face primal/value replay')
        check(objective<=row['base_optimum']+row['loss_tolerance']+2e-10,'face L1 constraint')
        check(max(row['max_constraint_violation'],row['max_bound_violation'])<=1e-7,'face numerical constraint receipts')
        key=(leaf,row['loss_tolerance']);ranges.setdefault(key,{})[row['direction']]=value
    for pair in ranges.values():check('minimum' in pair and 'maximum' in pair and pair['minimum']<=pair['maximum']+2e-10,'face minmax order')
    check(data['LP_records']==len(data['base_fits'])+len(data['face_solves']),'face denominator')
    out=dict(case=case['id'],status='passed' if not issues else 'failed',issues=issues,LP_records=data['LP_records'],
       detected_zero_leaf_tasks=len(tasks),ranges=[dict(leaf=list(key[0]),loss_tolerance=key[1],**v) for key,v in ranges.items()],
       input_sha256=sha(folder/'zero_leaf_face.json'),interpretation='Numerical ranges on the supplied native family only; no line probability or global structural necessity conclusion.')
    return out


def run_grid():
    protocol=read(ROOT/'development_protocol.json');first=read(ROOT/'audit_first_case.json')
    first_case=next(c for c in protocol['cases'] if c['id']=='reference__N24');firstfolder=ROOT/'development/reference__N24'
    assert first['status']=='passed' and not first['issues']
    assert all(sha(firstfolder/(name+'.json'))==expected for name,expected in first['input_sha256'].items())
    first_source=Path(__file__).with_name('audit_first_case.py')
    assert sha(first_source)==first['source_sha256']['audit_script']
    rows=[dict(case='reference__N24',receipt=str(ROOT/'audit_first_case.json'),sha256=sha(ROOT/'audit_first_case.json'),reused_matching_first_audit=True)]
    all_evaluation=[dict(case='reference__N24',**v) for v in first['evaluation']]
    for case in protocol['cases']:
        if case['id']=='reference__N24':continue
        receipt=audit_one(case['id']);path=ROOT/('audit_case_'+case['id']+'.json')
        rows.append(dict(case=case['id'],receipt=str(path),sha256=sha(path),status=receipt['status'],issues=receipt['issues'],
                         candidates=receipt['candidates'],linear_LP_receipts=receipt['linear_LP_receipts'],AC_inner_LP_receipts=receipt['AC_inner_LP_receipts']))
        all_evaluation.extend(dict(case=case['id'],**v) for v in receipt['evaluation'])
    faces=[audit_face(case) for case in protocol['cases']]
    comparison=[]
    for case in protocol['cases']:
        r=read(ROOT/'development'/case['id']/'case_result.json')
        linear=r['linear_evaluation']['rnj_refit'];ac=r['AC_evaluation']['rnj_refit']
        comparison.append(dict(case=case['id'],linear_parent_errors=linear['all_block_errors'],AC_parent_errors=ac['all_block_errors'],
              linear_parent_kernel_relative_RMSE=linear['kernel_relative_RMSE'],AC_parent_kernel_relative_RMSE=ac['kernel_relative_RMSE'],
              linear_parent_AC_validation=linear['AC_validation_mae'],AC_parent_AC_validation=ac['AC_validation_mae'],
              linear_wzzt_contraction_errors=r['linear_evaluation']['wzzt_contractions']['all_block_errors'],
              AC_wzzt_contraction_errors=r['AC_evaluation']['wzzt_contractions']['all_block_errors']))
    passed=all(row.get('status','passed')=='passed' for row in rows) and all(f['status']=='passed' for f in faces)
    out=dict(status='passed' if passed else 'failed',all_passed=passed,cases=rows,face_checks=faces,
        first_audit_reused_without_AC_replay=True,no_new_fitting=True,no_new_optimization=True,
        candidate_total=sum(c['planned_families'] for c in protocol['cases']),
        evaluation=all_evaluation,comparison=comparison,
        source_sha256={'full_grid_audit':sha(__file__),'first_audit':sha(first_source)},
        development_protocol_sha256=sha(ROOT/'development_protocol.json'),
        limitations=first['limitations'])
    (ROOT/'audit_full_grid.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=out['status'],candidate_total=out['candidate_total'],cases=len(rows),face_LP_records=sum(f['LP_records'] for f in faces),comparison=comparison)))
    return out


if __name__=='__main__':run_grid()


