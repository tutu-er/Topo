"""Independent first-development-case arithmetic/AC replay; no optimizers."""
from __future__ import annotations
from collections import Counter
import hashlib,json,pickle
from pathlib import Path
import numpy as np
import pandas as pd
import networkx as nx
from rnj_wzzt.models.network import TerminalizedNetwork
from rnj_wzzt.models.ac_powerflow import solve_ac_power_flow_timeseries
from research_experiments.rnj.graph_adapters import rooted_tree_from_clades

REPO=Path(r'C:\Users\23761\.codex\worktrees\wzzt-dr-selection\Topo')
ROOT=Path(r'C:\Users\23761\.codex\visualizations\2026\10\25\01a1726e-8ec7-7bc1-9f18-391f9cf79a1a\wzzt_dr_paper15_update_v1')

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return pickle.loads(Path(p).read_bytes())
def canonical(f):return tuple(sorted(set(tuple(sorted(s)) for s in f),key=lambda s:(len(s),s)))

def pack(item,rows=None):
    d=item['observed'];p=d['P_terminal'];rows=np.arange(len(p)) if rows is None else rows
    return tuple(d[k].iloc[rows].copy() for k in ('P_terminal','Q_terminal','V_terminal','root_voltage'))

def collect(case):
    src=Path(case['source_run']);s=read(src/'summary.json');step=96//case['N']
    parts=[pack(load(src/'history'/(d+'.pkl')),np.arange(0,24,step)) for d in s['wzzt_training_dates']]
    parts.append(pack(load(src/'strategies/no_reward/action.pkl')['simulation'],np.arange(0,24,step)))
    return tuple(pd.concat([p[j] for p in parts]) for j in range(4)),pack(load(src/'strategies/no_reward/validation.pkl')['simulation'])

def input_hash(obs):
    h=hashlib.sha256()
    for v in obs:h.update(pd.util.hash_pandas_object(v,index=True).values.tobytes())
    h.update(json.dumps(list(obs[0].columns),default=str).encode());h.update(json.dumps([str(v) for v in obs[0].index.normalize()]).encode())
    return h.hexdigest()

def kernels(point,n):
    r=np.zeros((n,n));x=r.copy()
    for s,ri,xi in zip(point['supports'],point['r'],point['x'],strict=True):
        r[np.ix_(s,s)]+=ri;x[np.ix_(s,s)]+=xi
    return r,x

def linear_loss(point,obs):
    p,q,v,root=obs;r,x=kernels(point,p.shape[1]);y=root.to_numpy()[:,None]**2-v.to_numpy()**2
    return float(np.mean(np.abs(p.to_numpy()@r.T+q.to_numpy()@x.T-y)))

def independent_net(point,labels,kv,mva):
    # Different converter: build graph from clades, then map each edge by its
    # descendant terminals. No algorithm bridge or physical network input.
    n=len(labels);family=canonical(point['supports']);full=tuple(range(n))
    clades=frozenset(frozenset(labels[i] for i in s) for s in family if 1<len(s)<n)
    tree=rooted_tree_from_clades(clades,labels,1,include_hidden_root_stem=full in family)
    g=nx.Graph();g.add_weighted_edges_from(tree.edges);dg=nx.bfs_tree(g,1)
    values={tuple(s):(ri,xi) for s,ri,xi in zip(point['supports'],point['r'],point['x'],strict=True)}
    positions={v:i for i,v in enumerate(labels)};branches=[];seen=set()
    for parent,child in dg.edges:
        desc=nx.descendants(dg,child)|{child};support=tuple(sorted(positions[t] for t in labels if t in desc))
        assert support in values,support;seen.add(support);ri,xi=values[support]
        branches.append(dict(from_bus=parent,to_bus=child,r_ohm=.5*ri*kv**2/mva,x_ohm=.5*xi*kv**2/mva,
                             is_true_closed=True,branch_type='independent_audit'))
    assert seen==set(family)
    buses=pd.DataFrame([dict(bus_id=node,bus_type='root' if node==1 else 'observed_terminal' if node in labels else 'hidden_internal',
                            is_observed=node==1 or node in labels,has_load=node in labels) for node in g.nodes])
    return TerminalizedNetwork(buses,pd.DataFrame(branches),1,kv,mva,{v:v for v in labels},{v:v for v in labels},{'scope':'candidate-only audit'})

def ac_loss(point,obs,kv,mva):
    p,q,v,root=obs;net=independent_net(point,list(p.columns),kv,mva)
    ac=solve_ac_power_flow_timeseries(net,p,q,v_root=root,max_iter=200,tol=1e-12)
    assert ac['converged'].all()
    pred=ac['V_bus_mag'].loc[:,list(p.columns)].to_numpy()
    return float(np.mean(np.abs(pred**2-v.to_numpy()**2)))

def contract(point,cal):
    keep=[i for i,s in enumerate(point['supports']) if len(s)==1 or cal['a']*point['r'][i]+cal['b']*point['x'][i]+1e-10>=.16*cal['median_root_depth']]
    return {k:[point[k][i] for i in keep] for k in ('supports','r','x')}

def ismember(prov):
    return dict(rnj_refit=any(p['source']=='rnj_bank' and p['operation']=='parent' for p in prov),
                wzzt_refit=any(p['operation']=='parent' for p in prov),
                rnj_contractions=any(p['source']=='rnj_bank' for p in prov),wzzt_contractions=True)

def run():
    protocol=read(ROOT/'development_protocol.json');case=next(c for c in protocol['cases'] if c['id']=='reference__N24')
    folder=ROOT/'development/reference__N24';linear=read(folder/'linear.json');ac=read(folder/'ac.json');result=read(folder/'case_result.json')
    original=read(case['original_fit']);train,valid=collect(case);labels=list(train[0].columns);n=len(labels)
    kv=protocol['settings']['base_kv'];mva=protocol['settings']['base_mva'];issues=[]
    def check(condition,message):
        if not condition:issues.append(message)
    def close(a,b,tol=2e-11):return abs(a-b)<=tol
    check(all(Path(p).exists() and sha(p)==h for p,h in protocol['source_sha256'].items()),'frozen source hash')
    check(all(Path(p).exists() and sha(p)==h for p,h in protocol['input_sha256'].items()),'frozen input hash')
    check(linear['input_sha256']=={'training':input_hash(train),'validation':input_hash(valid)},'input hashes')
    check(len(linear['candidates'])==len(ac['candidates'])==243,'candidate denominator')
    check(not linear['failures'] and not ac['failures'],'failures')
    expected={}
    def add_parent(family,source,identifier):
        family=canonical(family)
        for deleted in [None,*[s for s in family if len(s)>1]]:
            target=family if deleted is None else tuple(s for s in family if s!=deleted)
            event=dict(source=source,parent=identifier,operation='parent' if deleted is None else 'delete_one',deleted=deleted)
            expected.setdefault(target,set()).add(json.dumps(event,sort_keys=True))
    for index,point in enumerate(original['bank']):add_parent(point.get('native_family',point['supports']),'rnj_bank',f'bank_{index}:{point.get("config","")}')
    for name,path in original['searches'].items():
        for index,point in enumerate(path['path']):add_parent(point['supports'],'wzzt_path',f'{name}:{index}')
    ordered=sorted(expected,key=lambda f:(len(f),f))
    check(len(ordered)==243,'independent contraction count')
    for c,family in zip(linear['candidates'],ordered,strict=True):
        check(canonical(c['family'])==family,'independent family enumeration')
        check({json.dumps(v,sort_keys=True) for v in c['provenance']}==expected[family],'independent parent/delete provenance')
    for receipt in linear['LP_solves']:
        check(receipt['status']==2 and receipt['accepted'],'linear LP status')
        check(max(receipt['max_constraint_violation'],receipt['max_bound_violation'])<=1e-7,'linear LP constraint receipt')
    lc={c['index']:c for c in linear['candidates']};all_checks=[];inner_LPs=0;accepted=trials=0
    for c in ac['candidates']:
        index=c['index'];fit=c['fit'];family=canonical(c['family']);seed=lc[index]['point'];p=c['point']
        check(c['family']==lc[index]['family'] and c['provenance']==lc[index]['provenance'],f'candidate identity {index}')
        check(fit['success'] and fit['settings']['coefficient_bound']=='unbounded' and not fit['settings']['validation_used'],f'fit domain {index}')
        check(set(map(tuple,fit['native_point']['supports']))==set(family),f'native family {index}')
        check(all(np.isfinite(v) and v>=0 for k in ('r','x') for v in fit['native_point'][k]),f'nonnegative {index}')
        linear_tr=linear_loss(seed,train);linear_va=linear_loss(seed,valid)
        initial=ac_loss(fit['initial_native_point'],train,kv,mva);final=ac_loss(fit['native_point'],train,kv,mva)
        effective_tr=ac_loss(p,train,kv,mva);effective_va=ac_loss(p,valid,kv,mva)
        check(close(linear_tr,seed['objective']) and close(linear_va,seed['validation_mae']),f'linear loss {index}')
        check(close(initial,fit['initial_objective']) and close(final,fit['objective']),f'initial/final AC loss {index}')
        check(close(effective_tr,p['objective']) and close(effective_va,p['validation_mae']),f'effective AC score {index}')
        check(final<=initial+1e-12,f'AC monotonic final {index}')
        previous=initial
        check(len(fit['iterations'])<=3,f'iteration cap {index}')
        for step in fit['iterations']:
            check(close(step['current_objective'],previous),f'iteration chain {index}')
            check(all(t['alpha'] in (1.,.5,.25) for t in step['trials']),f'line steps {index}')
            trials+=len(step['trials'])
            if step['accepted']:
                accepted+=1;chosen=step['trials'][-1]
                check(chosen['alpha']==step['accepted_alpha'] and chosen['objective']<previous-1e-12,f'accepted threshold {index}')
                check(not any(t.get('objective',float('inf'))<previous-1e-12 for t in step['trials'][:-1]),f'first improving alpha {index}')
                previous=chosen['objective']
        check(close(previous,final),f'final trace chain {index}')
        inner_LPs+=len(fit['LP_solves'])
        for receipt in fit['LP_solves']:
            check(receipt['status']==2 and receipt['accepted'],'inner LP status')
            check(max(receipt['max_constraint_violation'],receipt['max_bound_violation'])<=1e-7,'inner LP numerical constraint receipt')
        all_checks.append(dict(index=index,linear_train=linear_tr,linear_validation=linear_va,AC_initial_train=initial,AC_final_train=final,AC_validation=effective_va))
    selection=[]
    for mode,data in [('linear',linear),('AC',ac)]:
        for name,chosen in data['models'].items():
            members=[c for c in data['candidates'] if ismember(c['provenance'])[name]]
            points=[c['point'] for c in members];best=min(p['validation_mae'] for p in points)
            eligible=[i for i,p in enumerate(points) if p['validation_mae']<=1.03*best+1e-12]
            index=min(eligible,key=lambda i:(len(points[i]['supports']),points[i]['validation_mae'],i));before=points[index]
            after=contract(before,original['calibrations']['raw'])
            check(chosen['selection_index']==index,f'select index {mode}/{name}')
            check(all(chosen[k]==after[k] for k in ('supports','r','x')),f'contract {mode}/{name}')
            lossfun=(lambda p,o:linear_loss(p,o)) if mode=='linear' else (lambda p,o:ac_loss(p,o,kv,mva))
            tr,va=lossfun(chosen,train),lossfun(chosen,valid)
            check(close(tr,chosen['objective']) and close(va,chosen['validation_mae']),f'contract rescore {mode}/{name}')
            selection.append(dict(mode=mode,group=name,members=len(points),index=index,global_candidate=members[index]['index'],train=tr,validation=va))
    # Reference topology/impedances enter after all fit and selection checks.
    from research_experiments.wzzt_dr_selection.end_to_end.physical_case import build_reference_case
    ref=build_reference_case('paper15');graph=ref.to_networkx_graph();dg=nx.bfs_tree(graph,ref.root_bus)
    true_r=np.zeros((n,n));true_x=true_r.copy();truth=set();zbase=ref.base_kv**2/ref.base_mva
    for parent,child in dg.edges:
        desc=nx.descendants(dg,child)|{child};support=tuple(i for i,t in enumerate(labels) if t in desc)
        ri=graph.edges[parent,child]['r_ohm'];xi=graph.edges[parent,child]['x_ohm']
        if not support or (ri==0 and xi==0):continue
        truth.add(support);true_r[np.ix_(support,support)]+=2*ri/zbase;true_x[np.ix_(support,support)]+=2*xi/zbase
    denom=np.sum(true_r**2)+np.sum(true_x**2);evaluation=[]
    for mode,data in [('linear',linear),('AC',ac)]:
        for name,p in data['models'].items():
            rr,xx=kernels(p,n);relative=float(np.sqrt((np.sum((rr-true_r)**2)+np.sum((xx-true_x)**2))/denom))
            active={tuple(s) for s,r,x in zip(p['supports'],p['r'],p['x']) if max(r,x)>1e-9}
            reported=result['linear_evaluation' if mode=='linear' else 'AC_evaluation'][name]
            check(close(relative,reported['kernel_relative_RMSE']),f'kernel RMSE {mode}/{name}')
            check(len(active^truth)==reported['all_block_errors'],f'effective family errors {mode}/{name}')
            evaluation.append(dict(mode=mode,group=name,kernel_relative_RMSE=relative,all_block_errors=len(active^truth),complete=active==truth))
    receipt=dict(status='passed' if not issues else 'failed',issues=issues,no_new_fits=True,no_new_optimization=True,
        AC_forward_replay_only=True,candidates=243,linear_LP_receipts=len(linear['LP_solves']),AC_inner_LP_receipts=inner_LPs,
        trace_steps_accepted=accepted,trace_trials=trials,train_rows=len(train[0]),validation_rows=len(valid[0]),
        selection=selection,evaluation=evaluation,candidate_checks=all_checks,independent_family_enumeration_count=len(ordered),
        source_sha256={'audit_script':sha(__file__)},input_sha256={n:sha(folder/(n+'.json')) for n in ('linear','ac','case_result')},
        limitations=['Intermediate trial coefficients and corrected-target arrays were not recorded by frozen code. All numeric trace chains and solver status/constraint receipts checked, but intermediate trial physical predictions and LP primal solutions cannot be independently reconstructed without new fitting.',
        'Independent AC predictions use the existing core forward solver; candidate topology conversion is separately implemented via clade graph descendants, with no physical reference branch input.',
        'Truth kernel is reconstructed only for post-fit evaluation from repository-built paper15 reference branches with factor2; this is not an externally measured or published-network ground truth.',
        'Reference N24 was previously inspected development data, not independent confirmation. Improved AC validation error does not prove improved line parameters.'])
    (ROOT/'audit_first_case.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:receipt[k] for k in ('status','issues','candidates','linear_LP_receipts','AC_inner_LP_receipts','trace_steps_accepted','trace_trials','train_rows','validation_rows','evaluation')}))
    return receipt

if __name__=='__main__':run()
