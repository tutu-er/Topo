"""Reporting-only repair: preserve all solved records, correct empty-domain fields."""
from pathlib import Path
import hashlib,json,shutil
from research_experiments.wzzt_dr_selection import presence_width_audit as a
from research_experiments.wzzt_dr_selection.experiment import save
r=a.ROOT;old=r/'outputs/a2d_presence_width_v1';out=r/'outputs/a2d_reporting_v2'
assert not out.exists();out.mkdir()
manifest=json.loads((old/'manifest.json').read_text())
names=list(json.loads((a.INPUT/'manifest.json').read_text())['protocol']['cases'])
screens={n:json.loads((old/('presence_'+n+'.json')).read_text()) for n in names}
record=json.loads((a.INPUT/'incompatible_observations.json').read_text())
fixed=a.presence(record);assert fixed['lp_calls']==0
assert [x['classification'] for x in fixed['rows']]==[x['classification'] for x in screens['incompatible_observations']['rows']]
screens['incompatible_observations']=fixed
save(out/'presence_incompatible_observations.json',fixed)
designs={n:json.loads((old/('design_'+n+'.json')).read_text()) for n in manifest['protocol']['width']['histories']}
evaluation=json.loads((old/'evaluation.json').read_text())
save(out/'summary.json',a.summarize(screens,designs,evaluation))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest2={'scope':'reporting correction only; four empty-domain channel states changed to incompatible, no optimization or actual evaluation repeated',
 'previous_run_manifest':sha(old/'manifest.json'),'previous_run_sources':manifest['sources'],
 'current_sources':{n:sha(r/n) for n in manifest['sources']},'protocol':manifest['protocol'],
 'new_lp_calls':0,'new_actual_evaluations':0,
 'carried_records':{str(p.relative_to(r)):sha(p) for p in old.glob('*.json')},
 'environment':manifest['environment']}
snap=out/'source_snapshot';snap.mkdir()
for name,h in manifest2['current_sources'].items():shutil.copyfile(r/name,snap/name)
save(out/'manifest.json',manifest2)
print(json.dumps(json.loads((out/'summary.json').read_text())['channel_statuses'],indent=2))
