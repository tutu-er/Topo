"""全类非枚举 AC 证书：从一个可行模型点排除所有不同约化拓扑。

不假定参考拓扑正确；对 CURRENT fitted_net/P/Q/root 重新求解 AC，
用原始通道计算 U，再以 uniform_ac_separation 证明每个不同拓扑
的全局最小损失 >= (d_ref-sqrt(U))_+²。浮点 AC 解的数值可行性
检查不是区间认证。统计解释另需预声明域覆盖和正确噪声校准。
"""

from __future__ import annotations

from dataclasses import dataclass
from math import isfinite, sqrt

import numpy as np
import pandas as pd

from rnj_wzzt.estimation.ac_measurement_fit import (
    ACMeasurementFit, ACMeasurementSigma, _aligned_frame, _series_on_index,
    _sigma_array,
)
from rnj_wzzt.estimation.ac_topology_alternatives import path_incidence
from rnj_wzzt.estimation.ac_topology_bounds import _measurement_arrays
from rnj_wzzt.estimation.ac_uniform_separation import (
    UniformACDomain, UniformACSeparation, uniform_ac_separation,
)
from rnj_wzzt.estimation.topology_hypothesis_test import gaussian_loss_threshold
from rnj_wzzt.models.ac_powerflow import solve_ac_power_flow_timeseries


@dataclass(frozen=True)
class AllTopologyCertificate:
    separation: UniformACSeparation
    reference_loss_upper: float
    all_other_loss_lower: float
    all_other_quality_upper: float
    residual_count: int
    rejection_threshold: float
    confidence_level: float | None
    noise_model: str
    assumptions_checked: tuple[str, ...]
    reference_topology_assumed_true: bool = False
    topology_enumeration_used: bool = False
    certificate_kind: str = "feasible_reference_all_other_port_topologies"

    @property
    def strictly_better_than_all_other_topologies(self) -> bool:
        return self.all_other_loss_lower > self.reference_loss_upper

    @property
    def all_other_topologies_rejected(self) -> bool:
        """覆盖域与噪声事件成立时排除全部其他树；不是后验正确概率。"""
        return self.all_other_loss_lower > self.rejection_threshold


def _check_reference_network(net, terminals, domain):
    """Check aggregate series edges without generating alternative topologies."""
    incidence, oriented = path_incidence(net, terminals)
    zbase = float(net.base_kv) ** 2 / float(net.base_mva)
    lookup = {
        frozenset((int(row.from_bus), int(row.to_bus))):
            complex(row.r_ohm, row.x_ohm) / zbase
        for row in net.branches.loc[net.branches.is_true_closed.astype(bool)].itertuples()
    }
    clades = {}
    for k, edge in enumerate(oriented):
        support = tuple(np.flatnonzero(incidence[:, k]).tolist())
        clades[support] = clades.get(support, 0j) + lookup[frozenset(edge)]
    magnitudes = np.abs(list(clades.values()))
    if ((magnitudes < domain.z_min_pu) | (magnitudes > domain.z_max_pu)).any():
        raise ValueError("reference aggregate edge impedances are outside the uniform domain")
    depth = max(sum(i in support for support in clades) for i in range(len(terminals)))
    if depth > domain.max_depth:
        raise ValueError("reference aggregate depth exceeds uniform domain max_depth")


def certify_all_other_topologies(
    fit: ACMeasurementFit,
    observed,
    *,
    sigma: ACMeasurementSigma,
    domain: UniformACDomain,
    alpha: float = 0.05,
    noise_radius: float | None = None,
) -> AllTopologyCertificate:
    """Non-enumerative global-loss lower bound for all different port trees.

    fit.success is not required: optimization success is irrelevant to a
    recomputed AC feasible point. Supplied cached fit.loss/voltages are unused.
    Domain terminal caps follow the observed P column order. Bounds on |z|
    apply to series-reduced edges in pu, not physical ohm segments. Reference
    domain checks say nothing about the unknown truth's domain membership.

    By default a known independent Gaussian raw-noise model is ASSUMED, giving
    a level-alpha joint ball. A nonnegative deterministic noise_radius instead
    gives eventwise exclusion with no attached probability. For a truth within
    the full declared class, returning all_other_topologies_rejected means that
    a wrong single-tree return occurs only outside this common noise event.
    This does not guarantee power of this algorithm, or correctness conditional
    on returning a certificate. No general global optimizer is implemented.
    """
    if not isinstance(domain, UniformACDomain):
        raise ValueError("domain must be UniformACDomain")
    if not isinstance(fit, ACMeasurementFit):
        raise ValueError("fit must be ACMeasurementFit")
    if fit.diagnostics.get("has_extra_source") is not False:
        raise ValueError("uniform certificate requires verified source=None")
    ref, _, spq, sv, sr, m = _measurement_arrays(fit.fitted_net, observed, sigma)
    if ref.shape != (domain.time_count, domain.terminal_count):
        raise ValueError("uniform domain sample/terminal counts do not match measurements")
    _check_reference_network(fit.fitted_net, ref.columns, domain)
    p = _aligned_frame(fit.fitted["P_terminal"], ref, "fitted.P_terminal")
    q = _aligned_frame(fit.fitted["Q_terminal"], ref, "fitted.Q_terminal")
    if (np.hypot(p, q) > np.asarray(domain.terminal_smax_pu)[None, :]).any():
        raise ValueError("reference terminal power is outside uniform domain")
    root = _series_on_index(fit.fitted["root_voltage"], ref.index, "fitted.root_voltage")
    if sigma.root_v is None:
        root_obs = _series_on_index(observed["root_voltage"], ref.index, "root_voltage")
        if not np.array_equal(root, root_obs):
            raise ValueError("fixed root voltage must equal reference prediction")
    p_frame = pd.DataFrame(p, index=ref.index, columns=ref.columns)
    q_frame = pd.DataFrame(q, index=ref.index, columns=ref.columns)
    ac = solve_ac_power_flow_timeseries(
        fit.fitted_net, p_frame, q_frame, v_root=root, max_iter=1000, tol=1e-12,
    )
    voltage, converged = ac["V_bus_mag"], ac["converged"]
    if (not isinstance(voltage, pd.DataFrame) or not voltage.index.equals(ref.index)
            or not voltage.columns.is_unique
            or set(voltage.columns) != set(fit.fitted_net.buses.bus_id)
            or not isinstance(converged, pd.Series) or not converged.index.equals(ref.index)
            or converged.empty or not bool(converged.all())):
        raise RuntimeError("reference AC point could not be recomputed completely")
    v = voltage.to_numpy(dtype=float)
    if (not np.isfinite(v).all() or (v < domain.voltage_min_pu).any()
            or (v > domain.voltage_max_pu).any()):
        raise ValueError("recomputed reference all-bus voltages are outside uniform domain")
    heads = [edge["label"] for edge in ac["metadata"]["branch_edges"]
             if edge["from_bus"] == fit.fitted_net.root_bus]
    center = {
        "P_terminal": p_frame, "Q_terminal": q_frame,
        "V_terminal": voltage.loc[:, ref.columns],
        "root_voltage": pd.Series(root, index=ref.index),
        "P0_measured": ac["branch_p_from_pu"][heads].sum(axis=1),
        "Q0_measured": ac["branch_q_from_pu"][heads].sum(axis=1),
    }
    loss = 0.0
    for key, scale, terminal in (
        ("P_terminal", sigma.p, True), ("Q_terminal", sigma.q, True),
        ("V_terminal", sigma.v, True), ("root_voltage", sigma.root_v, False),
        ("P0_measured", sigma.master_p, False), ("Q0_measured", sigma.master_q, False),
    ):
        if scale is None:
            continue
        prediction = (_aligned_frame(center[key], ref, key) if terminal
                      else _series_on_index(center[key], ref.index, key))
        measurement = (_aligned_frame(observed[key], ref, key) if terminal
                       else _series_on_index(observed[key], ref.index, key))
        sd = _sigma_array(scale, ref, key, terminal=terminal)
        loss += float(np.sum(((prediction - measurement) / sd) ** 2))
    if not isfinite(loss):
        raise ValueError("reference standardized loss must be finite")
    inputs = np.r_[p.T, q.T]
    gamma = float(np.linalg.svd(inputs, compute_uv=False)[-1]) if inputs.shape[1] >= inputs.shape[0] else 0.0
    separation = uniform_ac_separation(domain, gamma, sigma_pq_max=spq,
                                       sigma_v_max=sv, sigma_root_max=sr)
    lower = max(separation.distance_lower - sqrt(loss), 0.0) ** 2
    if not isfinite(lower):
        raise ValueError("all-other loss bound exceeds finite floating point range")
    if noise_radius is None:
        threshold = gaussian_loss_threshold(m, alpha=alpha)
        level = 1.0 - float(alpha)
        noise_model = "assumed_known_independent_gaussian_raw_measurements"
    else:
        if isinstance(noise_radius, (bool, np.bool_)):
            raise ValueError("noise_radius must be finite and nonnegative")
        radius = float(noise_radius)
        if not isfinite(radius) or radius < 0.0 or not isfinite(radius * radius):
            raise ValueError("noise_radius must be finite and nonnegative with finite square")
        threshold, level = radius * radius, None
        noise_model = "supplied_deterministic_joint_raw_noise_ball"
    return AllTopologyCertificate(
        separation=separation, reference_loss_upper=loss, all_other_loss_lower=lower,
        all_other_quality_upper=1.0 / (1.0 + lower / m), residual_count=m,
        rejection_threshold=threshold, confidence_level=level, noise_model=noise_model,
        assumptions_checked=("radial_terminal_only_network", "aggregate_impedance_and_depth_domain",
                             "reference_terminal_power_domain", "reference_all_bus_voltage_domain",
                             "reference_ac_prediction_recomputed", "source_none",
                             "raw_reference_distance_recomputed", "fixed_root_consistency"),
    )


__all__ = ["AllTopologyCertificate", "certify_all_other_topologies"]
