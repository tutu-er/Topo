"""Conditional AC separation bounds for labelled terminal two-line swaps.

The reference topology is ASSUMED to generate the data. This is an audit of its
explicit swap neighbourhood, not a test proving the reference is true. Bounds
cover arbitrary shared R/X refitting and charged latent P/Q corrections within
the declared physical domain. A local least-squares loss has the opposite bound
direction. All measurements/sigmas are pu; impedance priors are ohm.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from types import SimpleNamespace

import numpy as np
import pandas as pd
from scipy.stats import chi2

from rnj_wzzt.estimation.ac_measurement_fit import (
    ACMeasurementFit, ACMeasurementSigma, _aligned_frame, _positive_scalar,
    _series_on_index, _sigma_array, _terminal_values, _validate_network,
)
from rnj_wzzt.estimation.ac_topology_alternatives import (
    TerminalSwap, path_incidence, terminal_swap_alternatives,
)
from rnj_wzzt.models.network import TerminalizedNetwork
from rnj_wzzt.models.ac_powerflow import solve_ac_power_flow_timeseries


@dataclass(frozen=True)
class ACPhysicalDomain:
    """Independent priors for every reference/alternative admissible AC state.

    Bounds must be fixed independently of candidate residuals. All buses,
    including the root, have voltage magnitudes in voltage_bounds_pu; internal
    buses have zero injection. apparent_power_max_pu is a positive scalar or a
    terminal-labelled Series bounding |P+jQ| at every time, including export.
    The local fitter does not enforce this domain: check its returned state
    before using it as a feasible point of this restricted model class.
    """

    r_bounds_ohm: tuple[float, float]
    x_bounds_ohm: tuple[float, float]
    voltage_bounds_pu: tuple[float, float]
    apparent_power_max_pu: float | pd.Series


@dataclass(frozen=True)
class TreeEnvelopes:
    eta_upper: np.ndarray  # per-terminal squared-voltage remainder, one time
    h_norm_upper: float


@dataclass(frozen=True)
class ACTopologyCertificate:
    alternative: TerminalSwap
    loss_lower: float
    quality_upper: float
    excitation_lower: float
    excitation_observed: float
    input_error_upper: float
    linear_separation_lower: float
    ac_remainder_upper: float
    distance_lower: float
    noise_radius: float
    residual_count: int
    compensation_scale: float
    status: str
    assumptions: tuple[str, ...]
    noise_model: str
    confidence_level: float | None
    reference_topology_assumed_true: bool = True
    certificate_kind: str = "conditional_analytic_ac_terminal_swap"
    alternative_scope: str = "non_equivalent_labelled_terminal_two_line_swaps"
    assumptions_checked: tuple[str, ...] = (
        "connected_acyclic_closed_network", "all_nonroot_leaf_terminal_labels_covered",
        "reference_initial_impedances_in_domain", "nonnegative_finite_impedances",
        "fixed_raw_measurement_sigmas_and_exact_channel_count",
    )

    @property
    def strictly_separated_from_true(self) -> bool:
        """Sufficient true/alternative best-loss separation on the noise event."""
        return self.reference_topology_assumed_true and self.strictly_separated_from_reference

    @property
    def strictly_separated_from_reference(self) -> bool:
        """Alternative global best loss exceeds the reference loss upper bound."""
        return self.distance_lower > 2.0 * self.noise_radius


def _interval(value, name, *, positive_lower=False):
    try:
        values = np.asarray(value, dtype=float)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a finite lower/upper pair") from exc
    if (values.shape != (2,) or not np.isfinite(values).all()
            or not 0 <= values[0] < values[1]
            or (positive_lower and values[0] <= 0)):
        raise ValueError(f"{name} requires {'0 <' if positive_lower else '0 <='} lower < upper < infinity")
    return float(values[0]), float(values[1])


def _domain_values(domain: ACPhysicalDomain, terminals: pd.Index):
    if not isinstance(domain, ACPhysicalDomain):
        raise ValueError("domain must be ACPhysicalDomain")
    rlo, rhi = _interval(domain.r_bounds_ohm, "r_bounds_ohm", positive_lower=True)
    xlo, xhi = _interval(domain.x_bounds_ohm, "x_bounds_ohm")
    vlo, vhi = _interval(domain.voltage_bounds_pu, "voltage_bounds_pu", positive_lower=True)
    if isinstance(domain.apparent_power_max_pu, pd.Series):
        values = domain.apparent_power_max_pu
        if not values.index.is_unique or set(values.index) != set(terminals):
            raise ValueError("apparent_power_max_pu must cover the exact terminal labels")
        smax = values.loc[terminals].to_numpy(dtype=float)
        if not np.isfinite(smax).all() or (smax <= 0).any():
            raise ValueError("apparent_power_max_pu must be finite and positive")
    else:
        smax = np.full(len(terminals), _positive_scalar(domain.apparent_power_max_pu, "apparent_power_max_pu"))
    return rlo, rhi, xlo, xhi, vlo, vhi, smax


def resistance_lower_from_impedance(z_min: float, xr_max: float) -> float:
    """|z|>=z_min and 0<=x/r<=xr_max imply this resistance lower bound."""
    z_min = _positive_scalar(z_min, "z_min")
    if isinstance(xr_max, (bool, np.bool_)):
        raise ValueError("xr_max must be finite and nonnegative")
    xr_max = float(xr_max)
    if not np.isfinite(xr_max) or xr_max < 0:
        raise ValueError("xr_max must be finite and nonnegative")
    return float(z_min / np.hypot(1.0, xr_max))


def tree_envelopes(net: TerminalizedNetwork, terminals, domain: ACPhysicalDomain) -> TreeEnvelopes:
    """Uniform KCL/DistFlow remainder and H=2[R X] norm upper bounds.

    eta_v=sum_path |z_e|² ell_e + 2 sum_path sum_f_strictly_below_e
    (r_e*r_f+x_e*x_f) ell_f. KCL gives ell_e <= (sum_down |S_i|/Vmin)²,
    including reverse flow. No random-sample maxima enter this calculation.
    """
    terminals = pd.Index(terminals)
    _positive_scalar(net.base_kv, "base_kv")
    _positive_scalar(net.base_mva, "base_mva")
    _, rhi, _, xhi, vlo, _, smax = _domain_values(domain, terminals)
    incidence, edges = path_incidence(net, terminals)
    current_squared = (incidence.T @ smax / vlo) ** 2
    parent = {child: par for par, child in edges}
    below = np.zeros((len(edges), len(edges)), dtype=bool)
    positions = {child: k for k, (_, child) in enumerate(edges)}
    for f, (par, _) in enumerate(edges):
        node = par
        while node != net.root_bus:
            below[positions[node], f] = True
            node = parent[node]
    coeff = (rhi * rhi + xhi * xhi) / (net.base_kv ** 2 / net.base_mva) ** 2
    eta_upper = incidence @ (coeff * (current_squared + 2.0 * below @ current_squared))
    kernel = incidence @ incidence.T
    zbase = net.base_kv ** 2 / net.base_mva
    h_upper = 2.0 * np.hstack((rhi / zbase * kernel, xhi / zbase * kernel))
    return TreeEnvelopes(eta_upper, float(np.linalg.norm(h_upper, 2)))


def _measurement_arrays(net, observed, sigma):
    if not isinstance(sigma, ACMeasurementSigma):
        raise ValueError("sigma must be ACMeasurementSigma")
    reference = observed["P_terminal"]
    p = _terminal_values(reference, "P_terminal")
    q = _aligned_frame(observed["Q_terminal"], reference, "Q_terminal")
    v = _aligned_frame(observed["V_terminal"], reference, "V_terminal")
    root = _series_on_index(observed["root_voltage"], reference.index, "root_voltage")
    if (v <= 0).any() or (root <= 0).any():
        raise ValueError("observed voltage magnitudes must be positive")
    _validate_network(net, reference.columns)
    sp = _sigma_array(sigma.p, reference, "sigma.p", terminal=True)
    sq = _sigma_array(sigma.q, reference, "sigma.q", terminal=True)
    sv = _sigma_array(sigma.v, reference, "sigma.v", terminal=True)
    ntime, n = p.shape
    width = 3 * n
    sr = 0.0
    if sigma.root_v is not None:
        sr = float(np.max(_sigma_array(sigma.root_v, reference, "sigma.root_v", terminal=False)))
        width += 1
    elif observed.get("root_observation") == "noisy":
        raise ValueError("noisy root voltage requires sigma.root_v")
    for key, value in (("P0_measured", sigma.master_p), ("Q0_measured", sigma.master_q)):
        if value is not None:
            _series_on_index(observed[key], reference.index, key)
            _sigma_array(value, reference, key, terminal=False)
            width += 1
    return reference, np.r_[p.T, q.T], max(float(sp.max()), float(sq.max())), float(sv.max()), sr, ntime * width


def certify_terminal_swaps(
    reference_net: TerminalizedNetwork, observed, *, sigma: ACMeasurementSigma,
    domain: ACPhysicalDomain, noise_radius: float | None = None,
    alpha: float = 0.05, source=None,
) -> list[ACTopologyCertificate]:
    """Return one conditional bound for EVERY non-equivalent terminal swap.

    A deterministic bound on ||W(y-y0)|| may be supplied. Otherwise the caller
    assumes independently calibrated, zero-mean independent Gaussian errors
    with the supplied sigmas: b=sqrt(chi2.ppf(1-alpha,m)). It uses one joint raw
    measurement event, also covering noisy P/Q excitation; not fitted degrees
    of freedom. Correlation/systematic bias requires a calibrated noise radius.
    Reference truth, physical-domain coverage and absence of unmetered load are
    explicit assumptions, not inferred by this function. No local fit is needed.
    """
    if source is not None:
        raise ValueError("AC swap certificate supports zero internal injection and source=None only")
    ref, inputs, ss, sv, sr, m = _measurement_arrays(reference_net, observed, sigma)
    terminals = ref.columns
    rlo, _, _, _, _, vmax, _ = _domain_values(domain, terminals)
    active = reference_net.branches.loc[reference_net.branches["is_true_closed"].astype(bool)]
    for col, limits in (("r_ohm", domain.r_bounds_ohm), ("x_ohm", domain.x_bounds_ohm)):
        values = active[col].to_numpy(dtype=float)
        if ((values < limits[0]) | (values > limits[1])).any():
            raise ValueError(f"reference initial {col} is outside the physical domain")
    if noise_radius is None:
        alpha = _positive_scalar(alpha, "alpha")
        if alpha >= 1.0:
            raise ValueError("alpha must lie in (0,1)")
        b = float(np.sqrt(chi2.ppf(1.0 - alpha, m)))
        noise_model, confidence = "assumed_known_independent_gaussian_raw_measurements", 1.0 - alpha
    else:
        if isinstance(noise_radius, (bool, np.bool_)):
            raise ValueError("noise_radius must be finite and nonnegative")
        b = float(noise_radius)
        if not np.isfinite(b) or b < 0.0:
            raise ValueError("noise_radius must be finite and nonnegative")
        noise_model, confidence = "supplied_deterministic_whitened_noise_ball", None
    # Economy SVD omits null directions when N<2n; explicitly guard this case.
    gamma_obs = float(np.linalg.svd(inputs, compute_uv=False)[-1]) if inputs.shape[1] >= inputs.shape[0] else 0.0
    input_error = ss * b
    gamma = max(gamma_obs - input_error, 0.0)
    env0 = tree_envelopes(reference_net, terminals, domain)
    assumptions = (
        "reference_topology_is_data_generating", "all_nonroot_leaves_are_metered",
        "internal_injection_is_zero_no_shunts", "balanced_radial_ac_model",
        "positive_resistance_and_nonnegative_reactance_in_declared_bounds",
        "all_admissible_states_in_independently_declared_physical_domain",
        "raw_measurement_noise_is_in_declared_joint_ball",
        "shared_impedances_across_time_latent_pq_corrections_are_charged",
        "floating_point_evaluation_of_analytic_bound_not_interval_arithmetic",
    )
    results = []
    for swap in terminal_swap_alternatives(reference_net, terminals):
        # An equivalent port structure can have different physical segment
        # counts after a swap. Finite per-segment priors require covering every
        # member's envelope, not merely the chosen representative network.
        members = swap.equivalent_nets or (swap.net,)
        member_envelopes = [tree_envelopes(net, terminals, domain) for net in members]
        env1 = TreeEnvelopes(
            np.maximum.reduce([item.eta_upper for item in member_envelopes]),
            max(item.h_norm_upper for item in member_envelopes),
        )
        ac_upper = float(np.sqrt(len(ref)) * np.linalg.norm(np.maximum(env0.eta_upper, env1.eta_upper)))
        hbar = max(env0.h_norm_upper, env1.h_norm_upper)
        k = float(np.sqrt((hbar * ss) ** 2 + (2 * vmax * sv) ** 2 + (2 * vmax * np.sqrt(len(terminals)) * sr) ** 2))
        delta = 2.0 * np.sqrt(2.0) * rlo / (reference_net.base_kv ** 2 / reference_net.base_mva) * gamma if swap.quartet is not None else 0.0
        distance = max(delta - ac_upper, 0.0) / k
        lower = max(distance - b, 0.0) ** 2
        if swap.quartet is None:
            status = "no_opposing_resolved_quartet"
        elif gamma <= 0:
            status = "excitation_not_certified"
        elif delta <= ac_upper:
            status = "ac_envelope_dominates"
        elif distance <= b:
            status = "noise_dominates"
        else:
            status = "nontrivial_conditional_bound"
        results.append(ACTopologyCertificate(
            swap, lower, 1.0 / (1.0 + lower / m), gamma, gamma_obs,
            input_error, float(delta), ac_upper, float(distance), b, m, k,
            status, assumptions, noise_model, confidence,
        ))
    return results


def fit_domain_checks(fit: ACMeasurementFit, domain: ACPhysicalDomain) -> dict[str, bool]:
    """Check a local AC point for membership in the restricted model class.

    An out-of-domain fit remains a numerical diagnostic, and must not be placed
    in the certificate's quality interval. Solver success is separate: a budget
    exhausted but physically feasible point still supplies a mathematical U.
    """
    terminals = fit.fitted["P_terminal"].columns
    rlo, rhi, xlo, xhi, vlo, vhi, smax = _domain_values(domain, terminals)
    active = fit.fitted_net.branches.loc[fit.fitted_net.branches["is_true_closed"].astype(bool)]
    r = active["r_ohm"].to_numpy(dtype=float)
    x = active["x_ohm"].to_numpy(dtype=float)
    reference = fit.fitted["P_terminal"]
    p = _terminal_values(reference, "P_terminal")
    q = _aligned_frame(fit.fitted["Q_terminal"], reference, "Q_terminal")
    power = np.hypot(p, q)
    path_incidence(fit.fitted_net, terminals)  # topology and terminal-only contract
    voltage_frame = fit.ac["V_bus_mag"]
    convergence = fit.ac["converged"]
    voltage_labels_complete = (
        isinstance(voltage_frame, pd.DataFrame) and not voltage_frame.empty
        and voltage_frame.index.is_unique and voltage_frame.columns.is_unique
        and set(voltage_frame.index) == set(reference.index)
        and set(voltage_frame.columns) == set(fit.fitted_net.buses["bus_id"])
    )
    convergence_labels_complete = (
        isinstance(convergence, pd.Series) and not convergence.empty
        and convergence.index.is_unique and set(convergence.index) == set(reference.index)
    )
    voltage = np.asarray(voltage_frame, dtype=float)
    return {
        "resistance_in_domain": bool(((r >= rlo) & (r <= rhi)).all()),
        "reactance_in_domain": bool(((x >= xlo) & (x <= xhi)).all()),
        "all_bus_voltages_in_domain": bool(np.isfinite(voltage).all() and ((voltage >= vlo) & (voltage <= vhi)).all()),
        "terminal_apparent_power_in_domain": bool(np.isfinite(power).all() and (power <= smax[None, :]).all()),
        "ac_voltage_labels_complete": bool(voltage_labels_complete),
        "ac_convergence_labels_complete": bool(convergence_labels_complete),
        "ac_converged": bool(convergence_labels_complete and convergence.all()),
        "no_extra_source": fit.diagnostics.get("has_extra_source") is False,
    }


def certify_swaps_from_feasible_reference(
    fit: ACMeasurementFit, observed, *, sigma: ACMeasurementSigma,
    domain: ACPhysicalDomain,
) -> list[ACTopologyCertificate]:
    """Deterministic neighbour exclusion around an in-domain AC feasible fit.

    This version does NOT assume the reference tree is true. Its AC prediction
    is a known model point y_ref. Recompute U=||W(y-y_ref)||² with the supplied
    raw observations/sigmas; excitation is that point's exact P/Q. AC is solved
    again using the CURRENT fitted network/P/Q/root, so mutable cached voltages
    cannot masquerade as a feasible model point. Then every
    admissible swapped model has L* >= (d_ref-sqrt(U))_+². If d_ref>2sqrt(U),
    that alternative's GLOBAL best loss exceeds the reference feasible loss U.
    The conclusion is confined to this neighbourhood/domain, not true recovery.
    AC numerical feasibility is checked to the fitter's reported tolerances;
    this floating-point bound is not a verified interval arithmetic certificate.
    """
    checks = fit_domain_checks(fit, domain)
    if not all(checks.values()):
        raise ValueError(f"reference feasible fit is outside the certificate domain: {checks}")
    reference, _, _, _, _, m = _measurement_arrays(fit.fitted_net, observed, sigma)
    p = _aligned_frame(fit.fitted["P_terminal"], reference, "P_terminal")
    q = _aligned_frame(fit.fitted["Q_terminal"], reference, "Q_terminal")
    root_fit = _series_on_index(fit.fitted["root_voltage"], reference.index, "root_voltage")
    if sigma.root_v is None:
        root_obs = _series_on_index(observed["root_voltage"], reference.index, "root_voltage")
        if not np.array_equal(root_fit, root_obs):
            raise ValueError("fixed root voltage must equal reference prediction")
    p_frame = pd.DataFrame(p, index=reference.index, columns=reference.columns)
    q_frame = pd.DataFrame(q, index=reference.index, columns=reference.columns)
    ac = solve_ac_power_flow_timeseries(fit.fitted_net, p_frame, q_frame,
                                      v_root=root_fit, max_iter=1000, tol=1e-12)
    if not bool(ac["converged"].all()):
        raise RuntimeError("reference AC point could not be recomputed; no certificate returned")
    heads = [edge["label"] for edge in ac["metadata"]["branch_edges"]
             if edge["from_bus"] == fit.fitted_net.root_bus]
    center = {
        "P_terminal": p_frame, "Q_terminal": q_frame,
        "V_terminal": ac["V_bus_mag"].loc[:, reference.columns].copy(),
        "root_voltage": pd.Series(root_fit, index=reference.index),
        "P0_measured": ac["branch_p_from_pu"][heads].sum(axis=1),
        "Q0_measured": ac["branch_q_from_pu"][heads].sum(axis=1),
    }
    checks = fit_domain_checks(SimpleNamespace(fitted_net=fit.fitted_net, fitted=center,
                                              ac=ac, diagnostics=fit.diagnostics), domain)
    if not all(checks.values()):
        raise ValueError(f"recomputed reference AC point is outside the certificate domain: {checks}")
    checks["ac_prediction_recomputed"] = True
    loss = 0.0
    channels = [("P_terminal", sigma.p, True), ("Q_terminal", sigma.q, True),
                ("V_terminal", sigma.v, True), ("root_voltage", sigma.root_v, False),
                ("P0_measured", sigma.master_p, False), ("Q0_measured", sigma.master_q, False)]
    for key, scale, terminal in channels:
        if scale is None:
            continue
        prediction = (_aligned_frame(center[key], reference, key) if terminal
                      else _series_on_index(center[key], reference.index, key))
        measurement = (_aligned_frame(observed[key], reference, key) if terminal
                       else _series_on_index(observed[key], reference.index, key))
        sd = _sigma_array(scale, reference, key, terminal=terminal)
        loss += float(np.sum(((prediction - measurement) / sd) ** 2))
    certificates = certify_terminal_swaps(fit.fitted_net, center, sigma=sigma, domain=domain, noise_radius=0.0)
    radius = float(np.sqrt(loss))
    result = []
    for cert in certificates:
        lower = max(cert.distance_lower - radius, 0.0) ** 2
        status = cert.status
        if cert.distance_lower > 0.0:
            status = "nontrivial_feasible_reference_bound" if lower > 0 else "reference_residual_dominates"
        assumptions = tuple("reference_is_an_ac_feasible_point_in_domain" if a == "reference_topology_is_data_generating"
                            else "raw_observation_distance_to_reference_is_recomputed" if a == "raw_measurement_noise_is_in_declared_joint_ball"
                            else a for a in cert.assumptions)
        result.append(replace(cert, loss_lower=lower, quality_upper=1.0 / (1.0 + lower / m),
                              noise_radius=radius, status=status, assumptions=assumptions,
                              noise_model="deterministic_distance_to_ac_feasible_reference", confidence_level=None,
                              reference_topology_assumed_true=False,
                              assumptions_checked=cert.assumptions_checked + tuple(checks) + (
                                  "reference_is_numerically_ac_feasible", "raw_distance_to_reference_recomputed"),
                              certificate_kind="deterministic_feasible_reference_neighbour_exclusion"))
    return result


__all__ = ["ACPhysicalDomain", "ACTopologyCertificate", "TreeEnvelopes",
           "certify_terminal_swaps", "tree_envelopes", "fit_domain_checks",
           "resistance_lower_from_impedance", "certify_swaps_from_feasible_reference"]
