"""Non-enumerative AC separation from every different rooted port tree.

The canonical tree preserves the labelled observed root and all non-root leaf
ports.  Unobserved zero-injection degree-two vertices are suppressed by summing
their series impedances.  Impedance bounds below apply to those aggregate port
edges, not merely to their individual physical segments.  This module receives
an excitation lower bound for fixed, exact P/Q inputs; it does not turn an SVD
of noisy observations into a valid bound or attach a probability to a topology.

For Z=R+jX, distinct canonical rooted trees with first-quadrant edge impedances
and |z_e|>=z_min have ||Z-Z0||_F >= 2*z_min/sqrt(3).  A distinguishing rooted
triple covers resolution, contraction and refinement.  A zero-versus-positive
rooted pair covers a change in the observed root's common stem, which quartet
split tests can miss.  Thus H=2[R X] has Frobenius gap 4*z_min/sqrt(3).

The calculations use per unit, squared voltage, and ordinary floating point.
No candidate networks, optimizers, simulated maxima, or fitted degrees of
freedom enter the bound.  The gap constant and uniform depth envelope are
derived here; they are not attributed to a cited recovery theorem.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import hypot, isfinite, sqrt
from numbers import Integral, Real


def _real(value, name: str, *, positive: bool) -> float:
    # NumPy boolean scalars are not Real, so they are rejected too.
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a finite real number")
    result = float(value)
    if not isfinite(result) or (result <= 0.0 if positive else result < 0.0):
        raise ValueError(f"{name} must be finite and {'positive' if positive else 'nonnegative'}")
    return result


def _count(value, name: str, minimum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return int(value)


def _terminal_limits(value, count: int) -> tuple[float, ...]:
    if isinstance(value, Real):
        scalar = _real(value, "terminal_smax_pu", positive=True)
        return (scalar,) * count
    try:
        values = tuple(value)
    except TypeError as exc:
        raise ValueError("terminal_smax_pu must be a positive scalar or one limit per terminal") from exc
    if len(values) != count:
        raise ValueError("terminal_smax_pu must contain exactly terminal_count limits")
    return tuple(_real(item, "terminal_smax_pu", positive=True) for item in values)


@dataclass(frozen=True)
class UniformACDomain:
    """Independent physical bounds for the entire canonical tree class.

    Counts are n terminals and N time samples.  The exact input matrix is
    S=[P.T; Q.T] with shape (2*n, N), with power in pu on one common base.  Edge
    norm bounds are pu on the corresponding common impedance base.  max_depth
    counts aggregate root-to-terminal edges.  terminal_smax_pu bounds |P+jQ|
    at each port and time; a scalar declares the same cap for every port.

    The root remains an observed port even when its degree is one or two.  All
    non-root internal buses have zero injection.  The root has zero local load,
    and its slack injection supplies the feeder through its outgoing lines.
    There are no shunts, hidden leaf ports, or
    time-varying edge impedances.  Every admissible AC state's ALL bus voltage
    magnitudes, including the root, must obey the voltage bounds.

    Domain coverage is an assumption supplied independently of residuals.  A
    numerical parameter validator cannot check these statements against an
    unknown physical feeder.  For canonical trees max_depth=n is a universal
    safe depth cap, but a smaller independently justified cap may be supplied.
    """

    terminal_count: int
    time_count: int
    z_min_pu: float
    z_max_pu: float
    max_depth: int
    voltage_min_pu: float
    voltage_max_pu: float
    terminal_smax_pu: float | tuple[float, ...]

    def __post_init__(self):
        count = _count(self.terminal_count, "terminal_count", 3)
        samples = _count(self.time_count, "time_count", 1)
        depth = _count(self.max_depth, "max_depth", 1)
        zmin = _real(self.z_min_pu, "z_min_pu", positive=True)
        zmax = _real(self.z_max_pu, "z_max_pu", positive=True)
        vmin = _real(self.voltage_min_pu, "voltage_min_pu", positive=True)
        vmax = _real(self.voltage_max_pu, "voltage_max_pu", positive=True)
        if zmax < zmin:
            raise ValueError("z_max_pu must be >= z_min_pu")
        if vmax < vmin:
            raise ValueError("voltage_max_pu must be >= voltage_min_pu")
        limits = _terminal_limits(self.terminal_smax_pu, count)
        for name, value in (
            ("terminal_count", count), ("time_count", samples), ("max_depth", depth),
            ("z_min_pu", zmin), ("z_max_pu", zmax),
            ("voltage_min_pu", vmin), ("voltage_max_pu", vmax),
            ("terminal_smax_pu", limits),
        ):
            object.__setattr__(self, name, value)


@dataclass(frozen=True)
class UniformACSeparation:
    """Conditional analytic distances; no statistical rejection is performed.

    H has shape (n, 2*n).  structural_h_separation_lower and h_norm_upper are
    operator-coefficient pu bounds (the structural gap uses Frobenius norm).
    linear_separation_lower and ac_remainder_upper bound Frobenius norms of
    (n,N) squared-voltage arrays.  unstandardized_separation_lower is their
    positive difference.  compensation_scale converts the full standardized
    raw P/Q/V/(root V) Euclidean distance into that squared-voltage norm;
    distance_lower is the resulting dimensionless standardized distance.

    Master-meter channels can be charged in the full distance as well; their
    inclusion can only increase it.  They are not needed by this lower bound.
    """

    domain: UniformACDomain
    excitation_lower: float
    terminal_apparent_power_sum_pu: float
    structural_h_separation_lower: float
    linear_separation_lower: float
    per_terminal_ac_remainder_upper: float
    ac_remainder_upper: float
    h_norm_upper: float
    unstandardized_separation_lower: float
    compensation_scale: float
    distance_lower: float
    status: str
    assumptions: tuple[str, ...]
    certificate_kind: str = "uniform_analytic_ac_separation"
    topology_scope: str = "all_different_labelled_rooted_port_reduced_trees_in_domain"
    topology_enumeration_used: bool = False
    excitation_is_fixed_input_lower_bound: bool = True


def uniform_ac_separation(
    domain: UniformACDomain,
    gamma: float,
    *,
    sigma_pq_max: float,
    sigma_v_max: float,
    sigma_root_max: float = 0.0,
) -> UniformACSeparation:
    """Bound distance to EVERY different admissible rooted port topology.

    gamma is sigma_min(S) for one fixed exact reference input matrix, or a
    separately valid nonnegative lower bound on it.  With fewer than 2*n
    samples the full row excitation is zero; a positive gamma is rejected.
    A noisy observed SVD requires its own error correction/calibration before
    being passed here.  Full row excitation is sufficient, not necessary for
    topology identifiability under stronger structured excitation assumptions.

    Alternative P/Q and root voltage may be refitted, but every change is
    charged in the raw measurement distance.  Impedances can be refitted
    arbitrarily within the declared aggregate-edge domain, shared over time.
    sigma_pq_max is a positive upper bound for ALL terminal P/Q channel sigmas,
    sigma_v_max for terminal voltage sigmas, and sigma_root_max for root sigmas.
    Root sigma zero means a trusted fixed root voltage, not a free root state.
    All sigmas are pu and independently supplied; none are fit residual scales.

    The reference is assumed AC feasible and in this domain.  This is not an
    assumption that its topology is physically true.  Applying a noise event,
    observed-data loss comparison, or recovery decision is a caller's task.
    """
    if not isinstance(domain, UniformACDomain):
        raise ValueError("domain must be UniformACDomain")
    gamma = _real(gamma, "gamma", positive=False)
    spq = _real(sigma_pq_max, "sigma_pq_max", positive=True)
    sv = _real(sigma_v_max, "sigma_v_max", positive=True)
    sr = _real(sigma_root_max, "sigma_root_max", positive=False)
    n, samples = domain.terminal_count, domain.time_count
    if samples < 2 * n and gamma > 0.0:
        raise ValueError("gamma must be zero when time_count < 2*terminal_count")
    try:
        ssum = sum(domain.terminal_smax_pu)
        rho_h = 4.0 / sqrt(3.0) * domain.z_min_pu
        eta = (domain.max_depth * domain.z_max_pu * ssum / domain.voltage_min_pu) ** 2
        ac_upper = sqrt(n * samples) * eta
        hbar = 2.0 * n * domain.max_depth * domain.z_max_pu
        linear_lower = rho_h * gamma
        unstandardized_lower = max(linear_lower - ac_upper, 0.0)
        scale = hypot(hbar * spq, 2.0 * domain.voltage_max_pu * sv,
                      2.0 * domain.voltage_max_pu * sqrt(n) * sr)
        distance = unstandardized_lower / scale
    except (OverflowError, ZeroDivisionError) as exc:
        raise ValueError("parameters exceed finite floating-point separation calculation") from exc
    if not all(isfinite(value) for value in (
        ssum, rho_h, eta, ac_upper, hbar, linear_lower, unstandardized_lower, scale, distance,
    )) or scale <= 0.0:
        raise ValueError("parameters must give finite bounds and a positive compensation scale")
    status = ("excitation_not_certified" if gamma == 0.0 else
              "ac_envelope_dominates" if unstandardized_lower == 0.0 else
              "nontrivial_uniform_separation")
    assumptions = (
        "reference_is_an_ac_feasible_point_in_declared_domain",
        "root_and_all_nonroot_leaf_ports_have_fixed_observed_labels",
        "hidden_zero_injection_degree_two_vertices_are_series_reduced",
        "first_quadrant_aggregate_edge_impedances_with_declared_norm_bounds",
        "every_admissible_canonical_tree_obeys_declared_max_depth",
        "zero_internal_injection_no_shunts_balanced_radial_ac",
        "all_admissible_states_obey_all_bus_voltage_and_terminal_power_caps",
        "edge_impedances_are_shared_across_time",
        "gamma_is_a_valid_lower_bound_for_fixed_exact_pq_inputs",
        "all_latent_pq_and_noisy_root_corrections_are_charged",
        "root_voltage_is_fixed_when_sigma_root_max_is_zero",
        "fixed_raw_channel_sigmas_have_the_supplied_pu_upper_bounds",
        "floating_point_evaluation_not_verified_interval_arithmetic",
    )
    return UniformACSeparation(
        domain=domain, excitation_lower=gamma, terminal_apparent_power_sum_pu=ssum,
        structural_h_separation_lower=rho_h, linear_separation_lower=linear_lower,
        per_terminal_ac_remainder_upper=eta, ac_remainder_upper=ac_upper,
        h_norm_upper=hbar, unstandardized_separation_lower=unstandardized_lower,
        compensation_scale=scale, distance_lower=distance, status=status,
        assumptions=assumptions,
    )


__all__ = ["UniformACDomain", "UniformACSeparation", "uniform_ac_separation"]
