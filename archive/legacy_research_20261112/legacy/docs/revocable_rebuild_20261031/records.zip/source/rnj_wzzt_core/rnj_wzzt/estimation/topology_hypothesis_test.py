"""已知高斯量测误差下，复合拓扑假设的保守检验和理论功效。

令 M0 包含零假设拓扑类内所有允许的共享 R/X、逐时段潜在 P/Q、
根电压和 AC 状态，L*=inf_{mu in M0} ||Sigma^(-1/2)(y-mu)||^2。
已知正定 Sigma 时，m 是原始量测通道总数，不是 m-参数数或局部
Jacobian 秩修正。相关量测需要完整协方差白化，不能直接当作独立误差。
奇异 Sigma 还必须保留无噪声方向的支持域约束；本模块不实现这种处理，
不能简单缩小 m 后丢弃这些约束。

零假设下 L* <= ||Z||^2，Z~N(0,I_m)，故任何有效全局下界 B<=L*
超过 chi2(m,1-alpha) 均可安全拒绝。局部拟合给出的损失上界不能用于
这个拒绝条件。本模块只计算阈值，不验证调用方提供的全局下界。

功效函数另要求固定的真实备择均值到整个 M0 的统一白化距离 d，以及
对所有相关数据成立的已认证优化误差 0<=L*-B<=epsilon_opt。理想全局
profile 统计量可取 epsilon_opt=0；局部优化成功不是这种误差认证。
仅有 B<=L* 可以保证检验大小，不能继承这里的功效保证。当前量测中
估计出的随机距离不能未经事件概率处理便替代固定的 d。

这些量是频率学误拒水平和拒绝功效，不是拓扑正确概率。结论要求真实
均值属于声明的完整物理模型类、噪声零均值且协方差正确已知；未建模
偏差或从同一候选残差调出的 sigma 不自动满足这些条件。
"""

from __future__ import annotations

from math import isfinite, sqrt
from numbers import Integral, Real

import numpy as np
from scipy.stats import chi2


def _finite_real(value, name: str) -> float:
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a finite real scalar")
    try:
        result = float(value)
    except (ValueError, TypeError, OverflowError) as exc:
        raise ValueError(f"{name} must be a finite real scalar") from exc
    if not isfinite(result):
        raise ValueError(f"{name} must be a finite real scalar")
    return result


def _nonnegative(value, name: str) -> float:
    result = _finite_real(value, name)
    if result < 0.0:
        raise ValueError(f"{name} must be nonnegative")
    return result


def _probability(value, name: str) -> float:
    result = _finite_real(value, name)
    if not 0.0 < result < 1.0:
        raise ValueError(f"{name} must lie strictly between 0 and 1")
    return result


def _dimension(value) -> int:
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Integral) or value < 1:
        raise ValueError("residual_count must be a positive integer")
    # NumPy/SciPy distribution arguments must fit the supported integer range.
    if value > np.iinfo(np.int64).max:
        raise ValueError("residual_count exceeds the supported integer range")
    return int(value)


def gaussian_loss_threshold(residual_count: int, *, alpha: float = 0.05) -> float:
    """q_alpha=chi2(m,1-alpha)，m 为正确白化后的完整随机量测维数。

    使用 inverse survival function，避免很小 alpha 时 1-alpha 舍入为1。
    本阈值针对完整复合模型距离，未使用 Wilks 或拟合残差自由度近似。
    """
    m = _dimension(residual_count)
    alpha = _probability(alpha, "alpha")
    return float(chi2.isf(alpha, m))


def reject_from_global_loss_lower(
    loss_lower: float, residual_count: int, *, alpha: float = 0.05,
) -> bool:
    """有效 B<=L* 且 B>q_alpha 时拒绝；无需假设优化误差足够小。

    loss_lower 必须由调用方证明对完整零假设模型集合有效。负的有限
    下界也合法，只是无法拒绝；局部可行损失 U>=L* 不满足该接口前提。
    不对输入下界的有效性、真实噪声分布或物理域覆盖作自动认证。
    """
    lower = _finite_real(loss_lower, "loss_lower")
    return bool(lower > gaussian_loss_threshold(residual_count, alpha=alpha))


def gaussian_profile_power_lower(
    mean_distance_lower: float,
    residual_count: int,
    *,
    optimization_error_upper: float,
    alpha: float = 0.05,
) -> float:
    """F_chi2_m((d-sqrt(q_alpha+epsilon_opt))_+^2) 的理论功效下界。

    d 必须是固定真实备择均值到整个零假设量测集合的统一白化距离
    下界，epsilon_opt 必须统一保证 L*-epsilon_opt<=B<=L*。因此
    epsilon_opt 显式必填；理想精确全局 profile 统计量填0。距离为0
    时返回0，表示本充分界不提供功效，而非声称实际功效为0。

    证明：sqrt(L*) >= (d-||Z||)_+；若 ||Z||<d-sqrt(q+epsilon_opt)，
    则 L*>q+epsilon_opt，进而 B>q。这里没有把非线性 profile 损失
    误当作非中心 chi2 分布。计算为浮点值，不是区间算术认证。
    """
    distance = _nonnegative(mean_distance_lower, "mean_distance_lower")
    epsilon = _nonnegative(optimization_error_upper, "optimization_error_upper")
    m = _dimension(residual_count)
    threshold = gaussian_loss_threshold(m, alpha=alpha)
    margin = max(distance - sqrt(threshold + epsilon), 0.0)
    # Multiplication saturates to infinity for a valid extremely large distance;
    # its chi-square CDF is one to floating-point precision.
    return float(chi2.cdf(margin * margin, m))


def gaussian_profile_required_distance(
    residual_count: int,
    *,
    beta: float,
    optimization_error_upper: float,
    alpha: float = 0.05,
) -> float:
    """达到 power>=1-beta 的充分距离 sqrt(q+epsilon_opt)+sqrt(chi2_m,1-beta)。

    前提与 gaussian_profile_power_lower 一致；这是保守充分条件，未
    声称最小必要分离距离。不能把实际局部拟合的损失差当作 epsilon_opt。
    """
    m = _dimension(residual_count)
    beta = _probability(beta, "beta")
    epsilon = _nonnegative(optimization_error_upper, "optimization_error_upper")
    threshold = gaussian_loss_threshold(m, alpha=alpha)
    return float(sqrt(threshold + epsilon) + sqrt(float(chi2.isf(beta, m))))


__all__ = [
    "gaussian_loss_threshold", "reject_from_global_loss_lower",
    "gaussian_profile_power_lower", "gaussian_profile_required_distance",
]
