"""Minimal labelled-terminal swaps in a radial terminal-load-only network.

Only the two terminal endpoints are exchanged; meter labels, branch row labels,
and row R/X values stay fixed.  Those R/X values are starting values, not a
restriction on a subsequent fit.  Rooted port equivalence suppresses unobserved
degree-two vertices and hidden-node names.  Enumerating this family does not
enumerate every wrong topology or certify AC feasibility.
"""

from __future__ import annotations

from collections.abc import Sequence
from copy import deepcopy
from dataclasses import dataclass, replace
from itertools import combinations
from numbers import Integral

import networkx as nx
import numpy as np
import pandas as pd

from rnj_wzzt.models.network import TerminalizedNetwork


QuartetSplit = tuple[tuple[int, int], tuple[int, int]]
TopologyKey = tuple[tuple[int, ...], ...]


@dataclass(frozen=True)
class TerminalSwap:
    """One distinct rooted port topology and an optional quartet witness.

    ``terminals`` identifies the exchanged meter labels.  A quartet partition
    contains two unordered pairs, each sorted, and its pairs are sorted too.
    When found, both witness partitions have an internal path of at least one
    physical edge.  Missing witnesses are retained as ``None`` for a caller to
    report as unsupported.  The key compares fixed root/terminal label sets.
    ``equivalent_nets`` and ``equivalent_swaps`` retain every physical member
    of this class, including the first representative.  Suppressing hidden
    degree-two vertices does not preserve per-edge bounded parameter domains,
    so an electrical envelope must cover every retained member.
    """

    net: TerminalizedNetwork
    terminals: tuple[int, int]
    quartet: tuple[int, int, int, int] | None
    reference_split: QuartetSplit | None
    alternative_split: QuartetSplit | None
    key: TopologyKey
    equivalent_nets: tuple[TerminalizedNetwork, ...] = ()
    equivalent_swaps: tuple[tuple[int, int], ...] = ()


def _integer_labels(values, name: str) -> tuple[int, ...]:
    try:
        labels = tuple(values)
    except TypeError as exc:
        raise ValueError(f"{name} must be a sequence of integer bus IDs") from exc
    if any(isinstance(value, (bool, np.bool_)) or not isinstance(value, Integral)
           for value in labels):
        raise ValueError(f"{name} must contain integer bus IDs")
    labels = tuple(int(value) for value in labels)
    if len(set(labels)) != len(labels):
        raise ValueError(f"{name} bus IDs must be unique")
    return labels


def _network_tree(net: TerminalizedNetwork) -> nx.Graph:
    if not isinstance(net, TerminalizedNetwork):
        raise ValueError("net must be a TerminalizedNetwork")
    if not isinstance(net.buses, pd.DataFrame) or "bus_id" not in net.buses:
        raise ValueError("buses must contain bus_id")
    required = {"from_bus", "to_bus", "is_true_closed", "r_ohm", "x_ohm"}
    if not isinstance(net.branches, pd.DataFrame) or not required.issubset(net.branches):
        raise ValueError("branches must contain endpoints, closed status, and R/X")
    buses = _integer_labels(net.buses["bus_id"].tolist(), "bus")
    root, = _integer_labels([net.root_bus], "root")
    if root not in buses or len(buses) < 2:
        raise ValueError("network must contain its root and a non-root bus")
    if not net.branches.index.is_unique:
        raise ValueError("branch row labels must be unique")
    statuses = net.branches["is_true_closed"].tolist()
    if any(not isinstance(value, (bool, np.bool_, Integral)) or value not in (0, 1)
           for value in statuses):
        raise ValueError("is_true_closed must contain boolean statuses")
    active = net.branches.loc[np.asarray(statuses, dtype=bool)]
    graph = nx.Graph()
    graph.add_nodes_from(buses)
    for row in active.itertuples():
        endpoints = _integer_labels([row.from_bus, row.to_bus], "branch endpoint")
        left, right = endpoints
        if left not in graph or right not in graph:
            raise ValueError("branch endpoints must identify existing buses")
        if graph.has_edge(left, right):
            raise ValueError("duplicate closed branches are not supported")
        graph.add_edge(left, right)
    try:
        rx = active[["r_ohm", "x_ohm"]].to_numpy(dtype=float)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("closed-branch R/X must be finite and nonnegative") from exc
    if not np.isfinite(rx).all() or np.any(rx < 0.0):
        raise ValueError("closed-branch R/X must be finite and nonnegative")
    if not nx.is_tree(graph):
        raise ValueError("closed network must be connected and acyclic")
    return graph


def _terminal_tree(net: TerminalizedNetwork, terminals: Sequence[int]):
    graph = _network_tree(net)
    labels = _integer_labels(terminals, "terminal")
    leaves = {node for node, degree in graph.degree() if degree == 1 and node != net.root_bus}
    if not labels or set(labels) != leaves:
        raise ValueError("terminals must cover exactly all non-root leaf buses")
    if "has_load" in net.buses:
        internal = net.buses.loc[~net.buses["bus_id"].isin(labels), "has_load"]
        if internal.isna().any() or any(bool(value) for value in internal):
            raise ValueError("internal buses, including the root, must have has_load=False")
    return graph, labels


def _rooted_key(graph: nx.Graph, root: int, terminals: tuple[int, ...]) -> TopologyKey:
    oriented = tuple(nx.bfs_edges(graph, root, sort_neighbors=sorted))
    descendants = {node: ({node} if node in terminals else set()) for node in graph}
    clades = set()
    for parent, child in reversed(oriented):
        if len(descendants[child]) >= 2:
            clades.add(tuple(sorted(descendants[child])))
        descendants[parent].update(descendants[child])
    # A non-root full clade records a stem below the observed root.  Repetition
    # along a chain of hidden degree-two nodes contributes no extra topology.
    return tuple(sorted(clades, key=lambda clade: (len(clade), clade)))


def terminal_topology_key(net: TerminalizedNetwork, terminals: Sequence[int]) -> TopologyKey:
    """Return the rooted non-singleton clade set for fixed labelled ports.

    Hidden bus renaming and insertion/removal of hidden degree-two vertices do
    not affect this key.  A stem below an observed root remains distinguishable.
    Terminal labels must cover all non-root leaves; internal loads are forbidden.
    """
    graph, labels = _terminal_tree(net, terminals)
    return _rooted_key(graph, int(net.root_bus), labels)


def path_incidence(
    net: TerminalizedNetwork, terminals: Sequence[int],
) -> tuple[np.ndarray, tuple[tuple[int, int], ...]]:
    """Return root-to-terminal incidence and deterministically oriented edges.

    Rows follow the supplied terminal order; columns follow root BFS with sorted
    neighbours.  ``A[i,e]`` is one exactly when edge ``e`` lies on that port path.
    This is purely structural: no impedance conversion or aggregation is done.
    """
    graph, labels = _terminal_tree(net, terminals)
    edges = tuple((int(parent), int(child)) for parent, child in
                  nx.bfs_edges(graph, int(net.root_bus), sort_neighbors=sorted))
    parents = {child: (parent, column) for column, (parent, child) in enumerate(edges)}
    incidence = np.zeros((len(labels), len(edges)), dtype=float)
    for row, terminal in enumerate(labels):
        node = terminal
        while node != net.root_bus:
            node, column = parents[node]
            incidence[row, column] = 1.0
    return incidence, edges


def _split(distances, quartet: tuple[int, int, int, int]) -> QuartetSplit | None:
    a, b, c, d = quartet
    partitions = (((a, b), (c, d)), ((a, c), (b, d)), ((a, d), (b, c)))
    sums = [sum(distances[left][right] for left, right in partition) for partition in partitions]
    best = min(sums)
    indices = [index for index, value in enumerate(sums) if value == best]
    if len(indices) != 1:
        return None
    index = indices[0]
    others = [value for position, value in enumerate(sums) if position != index]
    if others[0] != others[1] or others[0] <= best:
        return None
    return tuple(sorted(tuple(sorted(pair)) for pair in partitions[index]))


def quartet_split(
    net: TerminalizedNetwork, quartet: Sequence[int],
) -> QuartetSplit | None:
    """Return the resolved four-point split using unweighted graph distances.

    The ports can include the observed root even when it is an internal vertex.
    Equal four-point sums give an unresolved quartet and return ``None``.  Each
    resolved split has an internal path containing at least one closed edge;
    no numerical R/X threshold or positive-impedance claim is inferred here.
    """
    graph = _network_tree(net)
    labels = _integer_labels(quartet, "quartet")
    if len(labels) != 4 or any(label not in graph for label in labels):
        raise ValueError("quartet must contain four distinct existing bus IDs")
    if any(label != net.root_bus and graph.degree(label) != 1 for label in labels):
        raise ValueError("quartet ports must be the root or non-root leaves")
    distances = {label: dict(nx.single_source_shortest_path_length(graph, label)) for label in labels}
    return _split(distances, labels)


def terminal_swap_alternatives(
    net: TerminalizedNetwork, terminals: Sequence[int],
) -> list[TerminalSwap]:
    """Enumerate inequivalent swaps of two leaf attachments at different parents.

    A pair of branch rows is edited by exchanging its terminal endpoints, with
    the orientation in each row preserved.  Candidates are checked as trees,
    and same-parent and reference-equivalent swaps are discarded.  Swaps with
    the same changed port topology are grouped, retaining all physical networks
    for subsequent bounds with finite per-edge impedance domains.  A witness
    is sought among ports including the observed root, which detects rooted
    changes that terminal-only unrooted quartets would miss.
    """
    graph, labels = _terminal_tree(net, terminals)
    labels = tuple(sorted(labels))
    root = int(net.root_bus)
    reference_key = _rooted_key(graph, root, labels)
    groups: dict[TopologyKey, int] = {}
    parents = {terminal: next(iter(graph.neighbors(terminal))) for terminal in labels}
    reference_distances = dict(nx.all_pairs_shortest_path_length(graph))
    active = net.branches["is_true_closed"].astype(bool)
    results = []
    for a, b in combinations(labels, 2):
        if parents[a] == parents[b]:
            continue
        candidate = deepcopy(net)
        for terminal, replacement in ((a, b), (b, a)):
            rows = net.branches.index[active & (
                net.branches["from_bus"].eq(terminal) | net.branches["to_bus"].eq(terminal)
            )]
            row = rows[0]
            column = "from_bus" if net.branches.at[row, "from_bus"] == terminal else "to_bus"
            candidate.branches.at[row, column] = replacement
        alternative_graph, _ = _terminal_tree(candidate, labels)
        key = _rooted_key(alternative_graph, root, labels)
        if key == reference_key:
            continue
        if key in groups:
            position = groups[key]
            representative = results[position]
            results[position] = replace(
                representative,
                equivalent_nets=representative.equivalent_nets + (candidate,),
                equivalent_swaps=representative.equivalent_swaps + ((a, b),),
            )
            continue
        alternative_distances = dict(nx.all_pairs_shortest_path_length(alternative_graph))
        # For a transposition, a distinguishing quartet with both exchanged
        # leaves has two resolved, different splits.  Include the observed root
        # among the other ports and try its witnesses first.
        other_ports = (root,) + tuple(label for label in labels if label not in (a, b))
        witness = None
        for c, d in combinations(other_ports, 2):
            quartet = (a, b, c, d)
            reference_split = _split(reference_distances, quartet)
            alternative_split = _split(alternative_distances, quartet)
            if reference_split is not None and alternative_split is not None and reference_split != alternative_split:
                witness = quartet, reference_split, alternative_split
                break
        groups[key] = len(results)
        quartet, reference_split, alternative_split = witness if witness is not None else (None, None, None)
        results.append(TerminalSwap(
            net=candidate, terminals=(a, b), quartet=quartet,
            reference_split=reference_split, alternative_split=alternative_split, key=key,
            equivalent_nets=(candidate,), equivalent_swaps=((a, b),),
        ))
    return results


__all__ = [
    "TerminalSwap", "path_incidence", "quartet_split", "terminal_swap_alternatives",
    "terminal_topology_key",
]
