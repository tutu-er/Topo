"""Strict JSON measurement loader for the public observed-data workflow.

Only measured terminal P/Q/drop arrays and external fixed source amplitudes
are accepted. Simulation truth, a source bus ID, and fitted validation paths
have no fields in this schema. P/Q/source arrays use pu; drop is squared pu.
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from rnj_wzzt.estimation.unmetered_inputs import SourceInputs


def _keys(value, allowed: set[str], required: set[str], name: str) -> None:
    if not isinstance(value, dict) or set(value) - allowed or required - set(value):
        raise ValueError(f"{name} must contain {sorted(required)} and only allowed measurement fields")


def _split(entries, name: str):
    if not isinstance(entries, list) or not entries:
        raise ValueError(f"{name} must be a nonempty scenario list")
    scenarios, sources = [], []
    for number, entry in enumerate(entries):
        required = {"terminal_labels", "time_index", "P_terminal", "Q_terminal", "drop_target"}
        _keys(entry, required | {"name", "source"}, required, f"{name}[{number}]")
        if not isinstance(entry["terminal_labels"], list) or not isinstance(entry["time_index"], list):
            raise ValueError("terminal_labels and time_index must be lists")
        index = pd.Index(entry["time_index"])
        columns = pd.Index(entry["terminal_labels"])
        frames = {}
        for key in ("P_terminal", "Q_terminal", "drop_target"):
            values = entry[key]
            if not isinstance(values, list) or len(values) != len(index) or any(
                not isinstance(row, list) or len(row) != len(columns) for row in values
            ):
                raise ValueError(f"{name}[{number}].{key} must be a complete time-by-terminal array")
            try:
                frames[key] = pd.DataFrame(values, index=index, columns=columns, dtype=float)
            except (TypeError, ValueError) as exc:
                raise ValueError(f"{name}[{number}].{key} must be a numeric time-by-terminal array") from exc
        scenarios.append({"name": str(entry.get("name", f"{name}_{number}")), **frames})
        source = entry.get("source")
        if source is None:
            sources.append(None)
        else:
            required_source = {"mode", "p_pu", "q_pu", "provenance"}
            _keys(source, required_source, required_source, f"{name}[{number}].source")
            if source["mode"] != "fixed_amplitude":
                raise ValueError("source.mode must be fixed_amplitude; source location is estimated")
            if any(not isinstance(source[key], list) or len(source[key]) != len(index) for key in ("p_pu", "q_pu")):
                raise ValueError("source p_pu/q_pu must be complete time arrays, without broadcasting")
            try:
                sources.append(SourceInputs(pd.Series(source["p_pu"], index=index, dtype=float),
                                            pd.Series(source["q_pu"], index=index, dtype=float),
                                            source["provenance"]))
            except (TypeError, ValueError) as exc:
                raise ValueError("source p_pu/q_pu must be numeric arrays on the complete scenario time index") from exc
    if any(source is not None for source in sources) and any(source is None for source in sources):
        raise ValueError(f"{name} source amplitudes must cover every scenario when supplied")
    return scenarios, sources if sources[0] is not None else None


def load_observed_input(path: str | Path) -> dict:
    """Return validated-schema arguments for ``pipeline.run_observed``.

    The top level is {root, case_name?, training, validation?}. Each split is a
    list of {name?, terminal_labels, time_index, P_terminal, Q_terminal,
    drop_target, source?}. The optional source contains mode=fixed_amplitude,
    p_pu, q_pu, provenance. Numeric alignment/range checks run in run_observed.
    """
    try:
        payload = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read observed-input JSON: {exc}") from exc
    _keys(payload, {"root", "case_name", "training", "validation"}, {"root", "training"}, "observed input")
    training, source = _split(payload["training"], "training")
    result = {"root": payload["root"], "training_scenarios": training, "source_inputs": source}
    if "case_name" in payload:
        result["case_name"] = payload["case_name"]
    if "validation" in payload:
        validation, validation_source = _split(payload["validation"], "validation")
        result.update(validation_scenarios=validation, validation_source_inputs=validation_source)
    return result


__all__ = ["load_observed_input"]
