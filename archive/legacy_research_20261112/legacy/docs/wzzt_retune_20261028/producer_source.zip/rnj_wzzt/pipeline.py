"""Fix selected RX75-RNJ blocks, then search new laminar L1-MILP supports.

Fit raw squared-voltage drops relative to the observed root, without terminal
offsets. Defaults use three noisy AC scenarios, 96 samples per scenario,
ordered R/X least-squares QP, RX75 score, and RNJ tolerance factor 0.16.
"""

from __future__ import annotations

import json
from collections import Counter
from collections.abc import Iterator, Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from time import perf_counter

import numpy as np
import pandas as pd

from rnj_wzzt.graph.bootstrap import (
    _boundary_cherries, _moving_block_bootstrap_copy, _select_disjoint,
)
from rnj_wzzt.scenario.simulation import _integer, _simulate_pool, _terminal_buses
from rnj_wzzt.scenario.settings import _finite_number, resolve_scenario_settings
from rnj_wzzt.reporting import (
    _milp_result_row, _rnj_candidate_rows, _rnj_summary_row,
    _truth_nontrivial_clades,
)
from rnj_wzzt.data.paper_style_case_bank import CASE_BUILDERS
from rnj_wzzt.estimation.laminar_l1_milp import (
    _validate_solver, fit_laminar_l1_sensitivity,
)
from rnj_wzzt.estimation.multiscenario import (
    align_scenarios,
    fit_projected_sensitivity,
)
from rnj_wzzt.estimation.unmetered_inputs import PreparedSourceInputs, SourceInputs, prepare_source_inputs
from rnj_wzzt.graph.rooted_hierarchy import rooted_clades, terminal_sibling_clades
from rnj_wzzt.graph.rooted_neighbor_joining import rooted_neighbor_joining
from rnj_wzzt.graph.sensitivity_geometry import sensitivity_geometry
from rnj_wzzt.solver_budgets import DEFAULT_MILP_TIME_LIMIT


DEFAULT_OUTPUT = Path("outputs/reference")
DEFAULT_CASES = tuple(CASE_BUILDERS)
SensitivityFit = tuple[np.ndarray, np.ndarray, float, float]


@dataclass(frozen=True)
class _CaseData:
    name: str
    training: list[dict]
    validation: list[dict] | None
    terminals: list[int]
    root: int
    truth_clades: set[frozenset[int]] | None
    truth_cherries: set[frozenset[int]] | None
    source_inputs: PreparedSourceInputs | None = None
    validation_source_inputs: PreparedSourceInputs | None = None


@dataclass(frozen=True)
class _RnjSelection:
    full_clades: set[frozenset[int]]
    full_cherries: set[frozenset[int]]
    confidence: dict[frozenset[int], float]
    selected: list[frozenset[int]]
    r2_score: float
    condition: float
    elapsed: float
    block_audit: dict = field(default_factory=dict)


def _validate_run_options(
    *,
    scenario_suite: str,
    samples_per_scenario: int,
    scenario_count: int,
    bootstrap_replicates: int,
    block_length: int,
    confidence_threshold: float,
    maximum_candidate_count: int,
    tolerance_factor: float,
    time_limit: float,
    coefficient_bound: float,
    root_observation: str,
    maximum_subclade_frequency: float = 0.1,
    fine_tolerance_ratio: float = 0.5,
) -> None:
    """Reject invalid orchestration settings before creating output files."""

    _integer(samples_per_scenario, "samples_per_scenario", 1)
    _integer(scenario_count, "scenario_count", 1)
    _validate_estimation_options(
        bootstrap_replicates=bootstrap_replicates, block_length=block_length,
        maximum_candidate_count=maximum_candidate_count, confidence_threshold=confidence_threshold,
        tolerance_factor=tolerance_factor, time_limit=time_limit, coefficient_bound=coefficient_bound,
        maximum_subclade_frequency=maximum_subclade_frequency, fine_tolerance_ratio=fine_tolerance_ratio,
    )
    if scenario_suite == "legacy" and samples_per_scenario < 96:
        raise ValueError("at least 96 samples per scenario are required")
    if scenario_suite != "legacy" and (
        samples_per_scenario < 4
        or 96 % samples_per_scenario != 0
    ):
        raise ValueError("new scenario suites require 4..96 samples dividing 96")
    if root_observation not in {"exact", "noisy"}:
        raise ValueError("the model requires observed root voltage (exact or noisy)")


def _validate_estimation_options(
    *, bootstrap_replicates: int, block_length: int, maximum_candidate_count: int,
    confidence_threshold: float, tolerance_factor: float, time_limit: float, coefficient_bound: float,
    maximum_subclade_frequency: float, fine_tolerance_ratio: float,
) -> None:
    """Validate estimation options independently of a synthetic 96-point grid."""
    _integer(bootstrap_replicates, "bootstrap_replicates", 1)
    _integer(block_length, "block_length", 1)
    _integer(maximum_candidate_count, "maximum_candidate_count", 0)
    confidence = _finite_number(confidence_threshold, "confidence_threshold")
    _finite_number(tolerance_factor, "tolerance_factor")
    _finite_number(time_limit, "time_limit", positive=True)
    _finite_number(coefficient_bound, "coefficient_bound", positive=True)
    if confidence > 1.0:
        raise ValueError("confidence_threshold must be in [0, 1]")
    if not 0.0 <= _finite_number(maximum_subclade_frequency, "maximum_subclade_frequency") <= 1.0:
        raise ValueError("maximum_subclade_frequency must be in [0, 1]")
    if not 0.0 < _finite_number(fine_tolerance_ratio, "fine_tolerance_ratio") <= 1.0:
        raise ValueError("fine_tolerance_ratio must be in (0, 1]")


def _scenario_manifest_rows(
    *,
    case_name: str,
    split: str,
    scenarios: list[dict],
    impedance_scale: float,
    root_observation: str,
) -> list[dict]:
    """Describe actual scenario inputs without estimator-only details."""

    return [
        {
            "case": case_name,
            "split": split,
            "name": scenario["name"],
            "impedance_scale": float(impedance_scale),
            "root_observation": root_observation,
            "samples": len(scenario["P_terminal"]),
        }
        for scenario in scenarios
    ]


def _rx75_rnj_clades(
    scenarios: list[dict],
    terminals: list[int],
    root: int,
    *,
    tolerance_factor: float,
    sensitivity_fit: SensitivityFit | None = None,
    tree_details: dict | None = None,
    source_inputs: PreparedSourceInputs | None = None,
) -> tuple[set[frozenset[int]], float, float]:
    if sensitivity_fit is None:
        sensitivity_fit = fit_projected_sensitivity(
            scenarios, **({"source_inputs": source_inputs} if source_inputs is not None else {})
        )
    r_matrix, x_matrix, r2_score, condition = sensitivity_fit
    geometry = sensitivity_geometry(r_matrix, x_matrix, "RX_75R_25X")
    scale = max(float(np.median(geometry.root_depths)), 1e-12)
    tree = rooted_neighbor_joining(
        geometry.shared_paths,
        geometry.root_depths,
        terminals,
        root,
        group_tolerance=tolerance_factor * scale,
    )
    if tree_details is not None:
        tree_details.update(tree=tree, peers=terminal_sibling_clades(tree.edges, root, terminals))
    return rooted_clades(tree.edges, root, terminals), float(r2_score), float(condition)


def _select_boundary_blocks(
    scenarios: list[dict],
    terminals: list[int],
    root: int,
    *,
    bootstrap_replicates: int,
    block_length: int,
    confidence_threshold: float,
    maximum_candidate_count: int,
    tolerance_factor: float,
    seed: int,
    sensitivity_fit: SensitivityFit | None = None,
    maximum_subclade_frequency: float = 0.1,
    fine_tolerance_ratio: float = 0.5,
    source_inputs: PreparedSourceInputs | None = None,
    diagnostics: dict | None = None,
) -> tuple[set[frozenset[int]], dict[frozenset[int], float], list[frozenset[int]], float, float]:
    """Freeze complete terminal sibling blocks of size >= 3, with a finer veto.

    Bootstrap frequencies describe algorithmic stability, not calibrated
    confidence. A supplied fixed source is removed by a nuisance-response
    projection before fitting R/X; rank-deficient adjusted designs freeze no
    blocks. Source amplitudes and observations use identical bootstrap rows.
    """
    _integer(bootstrap_replicates, "bootstrap_replicates", 1)
    _integer(block_length, "block_length", 1)
    _integer(maximum_candidate_count, "maximum_candidate_count", 0)
    if not 0.0 <= _finite_number(confidence_threshold, "confidence_threshold") <= 1.0:
        raise ValueError("confidence_threshold must be in [0, 1]")
    if not 0.0 <= _finite_number(maximum_subclade_frequency, "maximum_subclade_frequency") <= 1.0:
        raise ValueError("maximum_subclade_frequency must be in [0, 1]")
    if not 0.0 < _finite_number(fine_tolerance_ratio, "fine_tolerance_ratio") <= 1.0:
        raise ValueError("fine_tolerance_ratio must be in (0, 1]")
    _finite_number(tolerance_factor, "tolerance_factor")
    fit_info: dict = {}
    aligned_source = None
    if source_inputs is not None:
        from rnj_wzzt.estimation.laminar_l1_source import _copy_source_amplitudes
        amplitudes = _copy_source_amplitudes(
            source_inputs, expected_lengths=tuple(len(s["P_terminal"]) for s in scenarios),
            time_indices=tuple(s["P_terminal"].index for s in scenarios),
        )
        if amplitudes is not None:
            aligned_source = PreparedSourceInputs(
                p=amplitudes[0], q=amplitudes[1],
                time_indices=tuple(s["P_terminal"].index for s in scenarios),
                provenance=source_inputs.provenance,
            )
            sensitivity_fit = fit_projected_sensitivity(
                scenarios, source_inputs=aligned_source, diagnostics=fit_info,
            )
    if sensitivity_fit is None:
        sensitivity_fit = fit_projected_sensitivity(scenarios)
    details: dict = {}
    full_clades, r2_score, condition = _rx75_rnj_clades(
        scenarios,
        terminals,
        root,
        tolerance_factor=tolerance_factor,
        sensitivity_fit=sensitivity_fit,
        tree_details=details,
    )
    full_cherries = details["peers"]
    fine_clades, _, _ = _rx75_rnj_clades(
        scenarios, terminals, root, tolerance_factor=tolerance_factor * fine_tolerance_ratio,
        sensitivity_fit=sensitivity_fit,
    )
    counter: Counter = Counter()
    sub_counter: Counter = Counter()
    unidentifiable_replicates = 0
    rng = np.random.default_rng(seed)
    for _ in range(bootstrap_replicates):
        if aligned_source is None:
            sampled = _moving_block_bootstrap_copy(scenarios, rng, block_length)
            sampled_source = None
        else:
            sampled, indices = _moving_block_bootstrap_copy(
                scenarios, rng, block_length, return_indices=True,
            )
            sampled_source = PreparedSourceInputs(
                p=tuple(p[index] for p, index in zip(aligned_source.p, indices, strict=True)),
                q=tuple(q[index] for q, index in zip(aligned_source.q, indices, strict=True)),
                time_indices=tuple(s["P_terminal"].index for s in sampled),
                provenance=aligned_source.provenance,
            )
        sampled_info: dict = {}
        sampled_fit = fit_projected_sensitivity(
            sampled, diagnostics=sampled_info,
            **({"source_inputs": sampled_source} if sampled_source is not None else {}),
        )
        if not sampled_info.get("source_adjusted_identifiable", True):
            unidentifiable_replicates += 1
            continue
        sampled_details: dict = {}
        sampled_clades, _, _ = _rx75_rnj_clades(
            sampled,
            terminals,
            root,
            tolerance_factor=tolerance_factor,
            sensitivity_fit=sampled_fit,
            tree_details=sampled_details,
        )
        sampled_fine, _, _ = _rx75_rnj_clades(
            sampled, terminals, root, tolerance_factor=tolerance_factor * fine_tolerance_ratio,
            sensitivity_fit=sampled_fit,
        )
        counter.update(sampled_details["peers"])
        sub_counter.update(
            clade for clade in full_cherries
            if any(1 < len(child) < len(clade) and child < clade for child in sampled_clades | sampled_fine)
        )
    confidence = {
        clade: counter[clade] / bootstrap_replicates
        for clade in set(counter) | full_cherries
    }
    valid_replicates = bootstrap_replicates - unidentifiable_replicates
    # Unknown refinements must not dilute the internal-layer veto. Peer
    # frequency still uses all replicates as a conservative stability penalty.
    sub_frequency = {
        clade: sub_counter[clade] / valid_replicates if valid_replicates else 1.0
        for clade in full_cherries
    }
    full_subclades = {
        clade for clade in full_cherries
        if any(1 < len(child) < len(clade) and child < clade for child in fine_clades)
    }
    source_identifiable = fit_info.get("source_adjusted_identifiable", True)
    stable = {
        clade
        for clade in full_cherries
        if len(clade) >= 3
        and confidence[clade] >= confidence_threshold
        and sub_frequency[clade] <= maximum_subclade_frequency
        and clade not in full_subclades
        and source_identifiable
        and valid_replicates > 0
    }
    selected = _select_disjoint(stable, confidence, maximum_candidate_count)
    if diagnostics is not None:
        diagnostics.update(
            full_peers=full_cherries, subclade_frequency=sub_frequency,
            full_fine_subclades=full_subclades, eligible=stable,
            source_fit=fit_info, source_adjusted_identifiable=source_identifiable,
            unidentifiable_bootstrap_replicates=unidentifiable_replicates,
            valid_bootstrap_replicates=valid_replicates,
            maximum_subclade_frequency=maximum_subclade_frequency,
            fine_tolerance_ratio=fine_tolerance_ratio,
            minimum_block_size=3,
        )
    return full_clades, confidence, selected, r2_score, condition


def _prepare_case(
    case_name: str,
    *,
    samples_per_scenario: int,
    scenario_count: int,
    training_replicate: int,
    validation_replicate: int,
    pq_noise_rel: float,
    voltage_noise_rel: float,
    scenario_options: dict,
    root_observation: str,
) -> tuple[_CaseData, list[dict]]:
    """Simulate, preprocess, and label one independent train/validation pair."""

    net, training_raw = _simulate_pool(
        case_name,
        samples_per_scenario,
        training_replicate,
        scenario_count,
        pq_noise_rel,
        voltage_noise_rel,
        **scenario_options,
    )
    _, validation_raw = _simulate_pool(
        case_name,
        samples_per_scenario,
        validation_replicate,
        scenario_count,
        pq_noise_rel,
        voltage_noise_rel,
        **scenario_options,
    )
    scenario_rows = []
    for split, raw in (("training", training_raw), ("validation", validation_raw)):
        scenario_rows.extend(
            _scenario_manifest_rows(
                case_name=case_name,
                split=split,
                scenarios=raw,
                impedance_scale=net.metadata["impedance_scale"],
                root_observation=root_observation,
            )
        )

    training = align_scenarios(training_raw)
    validation = align_scenarios(validation_raw)
    terminals = _terminal_buses(net)
    truth_clades = _truth_nontrivial_clades(net, terminals)
    return (
        _CaseData(
            name=case_name,
            training=training,
            validation=validation,
            terminals=terminals,
            root=int(net.root_bus),
            truth_clades=truth_clades,
            truth_cherries=_boundary_cherries(truth_clades),
        ),
        scenario_rows,
    )


def _select_case_rnj(
    case: _CaseData,
    *,
    bootstrap_replicates: int,
    block_length: int,
    confidence_threshold: float,
    maximum_candidate_count: int,
    tolerance_factor: float,
    seed: int,
    maximum_subclade_frequency: float = 0.1,
    fine_tolerance_ratio: float = 0.5,
) -> _RnjSelection:
    """Fit R/X once, then bootstrap and select RNJ boundary blocks."""

    started = perf_counter()
    source = getattr(case, "source_inputs", None)
    if source is not None and source.all_zero:
        source = None
    # The source-adjusted selector computes the initial fit and its rank audit
    # together; a no-source call keeps the historical fit invocation unchanged.
    sensitivity_fit = None if source is not None else fit_projected_sensitivity(case.training)
    block_audit: dict = {}
    full_clades, confidence, selected, r2_score, condition = (
        _select_boundary_blocks(
            case.training,
            case.terminals,
            case.root,
            bootstrap_replicates=bootstrap_replicates,
            block_length=block_length,
            confidence_threshold=confidence_threshold,
            maximum_candidate_count=maximum_candidate_count,
            tolerance_factor=tolerance_factor,
            seed=seed,
            sensitivity_fit=sensitivity_fit,
            maximum_subclade_frequency=maximum_subclade_frequency,
            fine_tolerance_ratio=fine_tolerance_ratio,
            diagnostics=block_audit,
            **({"source_inputs": source} if source is not None else {}),
        )
    )
    return _RnjSelection(
        full_clades=full_clades,
        full_cherries=block_audit["full_peers"],
        confidence=confidence,
        selected=selected,
        r2_score=r2_score,
        condition=condition,
        elapsed=perf_counter() - started,
        block_audit=block_audit,
    )


def _leaf_singletons(terminal_count: int) -> list[tuple[int, ...]]:
    """Return the structurally known leaf-edge atoms for a terminal-only tree."""

    if terminal_count < 1:
        raise ValueError("terminal_count must be positive")
    return [(index,) for index in range(terminal_count)]


def _fit_milp_variants(
    case: _CaseData,
    selection: _RnjSelection,
    *,
    run_baseline: bool,
    coefficient_bound: float,
    time_limit: float,
    milp_solver: str = "highs",
    artifact_dir: Path | None = None,
) -> Iterator[dict]:
    """Search for new supports and yield one auditable row per variant."""

    position = {label: index for index, label in enumerate(case.terminals)}
    selected_supports = [
        tuple(position[label] for label in sorted(clade))
        for clade in selection.selected
    ]
    atomic_groups = [support for support in selected_supports if len(support) >= 3]
    leaf_singletons = _leaf_singletons(len(case.terminals))
    # The MILP API treats every initial support as fixed. The selected RNJ
    # boundary blocks are therefore retained while the MILP extends the tree.
    variants = [("rx75_rnj_plus_milp", [*leaf_singletons, *selected_supports])]
    if run_baseline:
        variants.insert(0, ("milp_only", leaf_singletons))

    for initializer, supports in variants:
        started = perf_counter()
        result = fit_laminar_l1_sensitivity(
            case.training,
            validation_scenarios=case.validation,
            initial_supports=supports,
            **({"terminal_groups": atomic_groups} if initializer == "rx75_rnj_plus_milp" else {}),
            r_upper_bound=coefficient_bound,
            x_upper_bound=coefficient_bound,
            time_limit=time_limit,
            solver=milp_solver,
            **({"source_inputs": case.source_inputs,
                "validation_source_inputs": getattr(case, "validation_source_inputs", None)}
               if getattr(case, "source_inputs", None) is not None else {}),
        )
        elapsed = perf_counter() - started
        if artifact_dir is not None:
            _write_fit_artifacts(case, result, initializer, artifact_dir)
        predicted = {
            frozenset(support)
            for support in result.support_labels
            if 1 < len(support) < len(case.terminals)
        }
        yield _milp_result_row(
            case_name=case.name,
            initializer=initializer,
            result=result,
            selected=[] if initializer == "milp_only" else selection.selected,
            supports=supports,
            predicted=predicted,
            truth_clades=case.truth_clades,
            elapsed=elapsed,
        )


def _write_fit_artifacts(case, result, initializer: str, output: Path) -> None:
    """Export fitted matrices and fixed-training-parameter observation predictions."""
    from rnj_wzzt.estimation.laminar_l1_milp import predict_l1_matrices

    prefix = f"{case.name}_{initializer}"
    pd.DataFrame(result.r_matrix, index=result.terminal_labels, columns=result.terminal_labels).to_csv(
        output / f"{prefix}_R.csv")
    pd.DataFrame(result.x_matrix, index=result.terminal_labels, columns=result.terminal_labels).to_csv(
        output / f"{prefix}_X.csv")
    response_r = getattr(result, "source_response_r", None)
    response_x = getattr(result, "source_response_x", None)
    for split, scenarios, source in (
        ("training", case.training, getattr(case, "source_inputs", None)),
        ("validation", case.validation, getattr(case, "validation_source_inputs", None)),
    ):
        if scenarios is None:
            continue
        predictions = predict_l1_matrices(
            scenarios, result.r_matrix, result.x_matrix, source_inputs=source,
            source_response_r=response_r, source_response_x=response_x,
        )
        rows = []
        for scenario_index, (scenario, prediction) in enumerate(zip(scenarios, predictions, strict=True)):
            labels = list(result.terminal_labels)
            target = scenario["drop_target"].loc[:, labels].to_numpy(dtype=float)
            for time_index, time_label in enumerate(scenario["P_terminal"].index):
                for terminal_index, terminal in enumerate(labels):
                    rows.append({"scenario": scenario.get("name", str(scenario_index)),
                                 "time_index": str(time_label), "terminal": terminal,
                                 "drop_observed": float(target[time_index, terminal_index]),
                                 "drop_predicted": float(prediction[time_index, terminal_index]),
                                 "residual": float(target[time_index, terminal_index] - prediction[time_index, terminal_index])})
        pd.DataFrame(rows).to_csv(output / f"{prefix}_{split}_predictions.csv", index=False)


def _execute_case(
    case: _CaseData, *, bootstrap_replicates: int, block_length: int,
    confidence_threshold: float, maximum_candidate_count: int, tolerance_factor: float,
    seed: int, maximum_subclade_frequency: float, fine_tolerance_ratio: float,
    selection_only: bool, run_baseline: bool, coefficient_bound: float,
    time_limit: float, milp_solver: str, artifact_dir: Path | None = None,
) -> Iterator[tuple[str, object]]:
    """Shared observed/simulated case execution; measurement inputs never use truth."""
    selection = _select_case_rnj(
        case, bootstrap_replicates=bootstrap_replicates, block_length=block_length,
        confidence_threshold=confidence_threshold, maximum_candidate_count=maximum_candidate_count,
        tolerance_factor=tolerance_factor, seed=seed,
        maximum_subclade_frequency=maximum_subclade_frequency,
        fine_tolerance_ratio=fine_tolerance_ratio,
    )
    lengths = [len(s["P_terminal"]) for s in case.training]
    summary = _rnj_summary_row(
        case_name=case.name, scenario_count=len(case.training),
        samples_per_scenario=lengths[0] if len(set(lengths)) == 1 else None,
        r2_score=selection.r2_score, condition=selection.condition,
        selection_seconds=selection.elapsed, full_clades=selection.full_clades,
        full_cherries=selection.full_cherries, selected=selection.selected,
        confidence=selection.confidence, truth_clades=case.truth_clades,
        truth_cherries=case.truth_cherries, block_audit=selection.block_audit,
        total_training_rows=sum(lengths),
    )
    yield "rnj", summary
    yield "candidates", _rnj_candidate_rows(
        case_name=case.name, confidence=selection.confidence, full_cherries=selection.full_cherries,
        selected=selection.selected, truth_cherries=case.truth_cherries,
        confidence_threshold=confidence_threshold, block_audit=selection.block_audit,
    )
    if not selection_only:
        for row in _fit_milp_variants(
            case, selection, run_baseline=run_baseline, coefficient_bound=coefficient_bound,
            time_limit=time_limit, milp_solver=milp_solver,
            **({"artifact_dir": artifact_dir} if artifact_dir is not None else {}),
        ):
            yield "milp", row


def _collect_case_records(events, output: Path, summaries: list, candidates: list, milp: list) -> None:
    for kind, value in events:
        if kind == "rnj":
            summaries.append(value)
            pd.DataFrame(summaries).to_csv(output / "rnj_summary.csv", index=False)
        elif kind == "candidates":
            candidates.extend(value)
            pd.DataFrame(candidates).to_csv(output / "rnj_boundary_candidates.csv", index=False)
        else:
            milp.append(value)
            pd.DataFrame(milp).to_csv(output / "milp_results.csv", index=False)


def run(
    output_dir: str | Path = DEFAULT_OUTPUT,
    *,
    cases: tuple[str, ...] = DEFAULT_CASES,
    scenario_count: int = 3,
    samples_per_scenario: int = 96,
    training_replicate: int = 0,
    validation_replicate: int = 1,
    pq_noise_rel: float = 0.005,
    voltage_noise_rel: float = 0.0002,
    tolerance_factor: float = 0.16,
    bootstrap_replicates: int = 100,
    block_length: int = 4,
    confidence_threshold: float = 0.75,
    maximum_candidate_count: int = 2,
    maximum_subclade_frequency: float = 0.1,
    fine_tolerance_ratio: float = 0.5,
    selection_only: bool = False,
    run_baseline: bool = False,
    time_limit: float = DEFAULT_MILP_TIME_LIMIT,
    coefficient_bound: float = 2.0,
    scenario_suite: str = "reference",
    root_observation: str | None = None,
    root_meter_noise_rel: float | None = None,
    root_sigma: float | None = None,
    impedance_scale: float | None = None,
    milp_solver: str = "highs",
) -> dict:
    """Run the Python computation API and define defaults for every entrypoint.

    The default reference workflow fits observed-root voltage drops, selects
    RNJ boundary blocks, and extends their supports with MILP. Explicit
    ``selection_only`` and ``run_baseline`` enable diagnostics and comparison.
    """
    _validate_solver(milp_solver)
    scenario_options = dict(
        scenario_suite=scenario_suite, root_observation=root_observation,
        root_meter_noise_rel=root_meter_noise_rel, root_sigma=root_sigma,
        impedance_scale=impedance_scale,
    )
    scenario_settings = resolve_scenario_settings(**scenario_options)
    _validate_run_options(
        scenario_suite=scenario_suite,
        samples_per_scenario=samples_per_scenario,
        scenario_count=scenario_count,
        bootstrap_replicates=bootstrap_replicates,
        block_length=block_length,
        confidence_threshold=confidence_threshold,
        maximum_candidate_count=maximum_candidate_count,
        tolerance_factor=tolerance_factor,
        time_limit=time_limit,
        coefficient_bound=coefficient_bound,
        root_observation=scenario_settings["root_observation"],
        maximum_subclade_frequency=maximum_subclade_frequency,
        fine_tolerance_ratio=fine_tolerance_ratio,
    )
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    candidate_rows: list[dict] = []
    summary_rows: list[dict] = []
    milp_rows: list[dict] = []
    scenario_rows: list[dict] = []

    for case_name in cases:
        case, manifest = _prepare_case(
            case_name,
            samples_per_scenario=samples_per_scenario,
            scenario_count=scenario_count,
            training_replicate=training_replicate,
            validation_replicate=validation_replicate,
            pq_noise_rel=pq_noise_rel,
            voltage_noise_rel=voltage_noise_rel,
            scenario_options=scenario_options,
            root_observation=scenario_settings["root_observation"],
        )
        scenario_rows.extend(manifest)
        events = _execute_case(
            case,
            bootstrap_replicates=bootstrap_replicates,
            block_length=block_length,
            confidence_threshold=confidence_threshold,
            maximum_candidate_count=maximum_candidate_count,
            tolerance_factor=tolerance_factor,
            seed=20_260_903 + training_replicate,
            maximum_subclade_frequency=maximum_subclade_frequency,
            fine_tolerance_ratio=fine_tolerance_ratio,
            selection_only=selection_only,
            run_baseline=run_baseline,
            coefficient_bound=coefficient_bound,
            time_limit=time_limit,
            milp_solver=milp_solver,
        )
        _collect_case_records(events, output, summary_rows, candidate_rows, milp_rows)

    payload = {
        "config": {
            "cases": list(cases),
            "scenario_count": scenario_count,
            "samples_per_scenario": samples_per_scenario,
            "training_replicate": training_replicate,
            "validation_replicate": validation_replicate,
            "pq_noise_rel": pq_noise_rel,
            "voltage_noise_rel": voltage_noise_rel,
            "preprocessing": "raw",
            "constraint_mode": "ordered",
            "distance_mode": "RX_75R_25X",
            "tolerance_factor": tolerance_factor,
            "bootstrap_replicates": bootstrap_replicates,
            "bootstrap_kind": "circular_moving_block",
            "block_length": block_length,
            "confidence_threshold": confidence_threshold,
            "maximum_candidate_count": maximum_candidate_count,
            "maximum_subclade_frequency": maximum_subclade_frequency,
            "fine_tolerance_ratio": fine_tolerance_ratio,
            "rnj_atomic_block_rule": "complete_direct_terminal_children",
            "minimum_atomic_block_size": 3,
            "bootstrap_frequency_is_calibrated_probability": False,
            "selection_only": selection_only,
            "run_baseline": run_baseline,
            "support_search_mode": "block_atomic",
            "time_limit_seconds_per_extension": time_limit,
            "milp_solver": milp_solver,
            "coefficient_bound": coefficient_bound,
            "truth_used_for_candidate_generation": False,
            "scenario_settings": scenario_settings,
        },
        "scenarios": scenario_rows,
        "rnj": summary_rows,
        "milp": milp_rows,
    }
    (output / "metrics.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False, allow_nan=False),
        encoding="utf-8",
    )
    return payload


def _observed_scenarios(scenarios, *, reference_labels=None) -> list[dict]:
    if not isinstance(scenarios, Sequence) or isinstance(scenarios, (str, bytes)) or not scenarios:
        raise ValueError("observed scenarios must be a nonempty sequence of measurement mappings")
    cleaned = []
    for index, scenario in enumerate(scenarios):
        if not isinstance(scenario, Mapping) or "truth" in scenario:
            raise ValueError("pass observed measurement mappings, never a ScenarioBundle or truth")
        if any(key not in scenario for key in ("P_terminal", "Q_terminal", "drop_target")):
            raise ValueError("each observed scenario requires P_terminal, Q_terminal, drop_target")
        if any(not isinstance(scenario[key], pd.DataFrame) for key in ("P_terminal", "Q_terminal", "drop_target")):
            raise ValueError("observed P_terminal, Q_terminal, drop_target must be DataFrames")
        cleaned.append({"name": str(scenario.get("name", f"scenario_{index}")), **{
            key: scenario[key] for key in ("P_terminal", "Q_terminal", "drop_target")}})
    aligned = align_scenarios(cleaned)
    labels = aligned[0]["P_terminal"].columns if reference_labels is None else pd.Index(reference_labels)
    if not labels.is_unique or len(labels) < 1 or any(
        isinstance(label, (bool, np.bool_)) or not isinstance(label, (int, np.integer)) for label in labels
    ):
        raise ValueError("RNJ observed terminal labels must be unique integer bus IDs")
    for scenario in aligned:
        for key in ("P_terminal", "Q_terminal", "drop_target"):
            frame = scenario[key]
            if not isinstance(frame, pd.DataFrame) or not frame.columns.is_unique or set(frame.columns) != set(labels):
                raise ValueError(f"{key} must have the same unique terminal columns")
            frame = frame.loc[:, labels].copy()
            if not np.isfinite(frame.to_numpy(dtype=float)).all():
                raise ValueError(f"{key} must contain only finite numeric values")
            scenario[key] = frame
    return aligned


def run_observed(
    training_scenarios: Sequence[Mapping], *, root: int,
    validation_scenarios: Sequence[Mapping] | None = None,
    source_inputs: PreparedSourceInputs | Sequence[SourceInputs] | None = None,
    validation_source_inputs: PreparedSourceInputs | Sequence[SourceInputs] | None = None,
    output_dir: str | Path = Path("outputs/observed"), case_name: str = "observed",
    tolerance_factor: float = 0.16, bootstrap_replicates: int = 100, block_length: int = 4,
    confidence_threshold: float = 0.75, maximum_candidate_count: int = 2,
    maximum_subclade_frequency: float = 0.1, fine_tolerance_ratio: float = 0.5,
    selection_only: bool = False, run_baseline: bool = False,
    time_limit: float = DEFAULT_MILP_TIME_LIMIT, coefficient_bound: float = 2.0,
    milp_solver: str = "highs", seed: int = 20_260_903,
) -> dict:
    """Fit observed terminal P/Q and observed-root squared-voltage drops.

    Source amplitudes are fixed external pu inputs, without physical source
    location. A nonzero training source requires explicit validation amplitudes
    when validation data are supplied. Validation uses the fitted training path
    and responses without re-estimation. The observed workflow has no truth
    input; topology precision/recall and physical source bus IDs remain unknown.
    """
    from rnj_wzzt.estimation.laminar_l1_source import prepare_model_source_inputs

    _validate_solver(milp_solver)
    training = _observed_scenarios(training_scenarios)
    labels = list(training[0]["P_terminal"].columns)
    validation = None if validation_scenarios is None else _observed_scenarios(
        validation_scenarios, reference_labels=labels)
    if isinstance(root, (bool, np.bool_)) or not isinstance(root, (int, np.integer)) or int(root) in labels:
        raise ValueError("root must be an integer observed root bus ID outside the terminal labels")
    if not isinstance(case_name, str) or not case_name.strip() or case_name in {".", ".."} or any(
        char in case_name for char in '<>:"/\\|?*'
    ) or case_name.endswith((".", " ")):
        raise ValueError("case_name must be a nonempty file-safe name")
    if validation is None and validation_source_inputs is not None:
        raise ValueError("validation_source_inputs require validation_scenarios")
    def prepare_split_source(scenarios, inputs):
        raw = inputs if isinstance(inputs, PreparedSourceInputs) else prepare_source_inputs(scenarios, inputs)
        aligned = prepare_model_source_inputs(scenarios, raw)
        if raw is not None and aligned is None:
            # Preserve an explicit validated zero validation profile: the fit
            # API distinguishes this supplied profile from missing amplitudes.
            aligned = PreparedSourceInputs(
                p=tuple(np.zeros(len(s["P_terminal"])) for s in scenarios),
                q=tuple(np.zeros(len(s["P_terminal"])) for s in scenarios),
                time_indices=tuple(s["P_terminal"].index.copy() for s in scenarios),
                provenance=tuple(raw.provenance),
            )
        return aligned

    source = prepare_split_source(training, source_inputs)
    validation_source = None if validation is None else prepare_split_source(validation, validation_source_inputs)
    active_source = source is not None and not source.all_zero
    if active_source and validation is not None and validation_source is None:
        raise ValueError("nonzero training source requires validation_source_inputs")
    if not active_source and validation_source is not None and not validation_source.all_zero:
        raise ValueError("nonzero validation source requires a nonzero training source")
    for scenario in training:
        _integer(len(scenario["P_terminal"]), "training scenario row count", 2)
    _validate_estimation_options(
        bootstrap_replicates=bootstrap_replicates, block_length=block_length,
        confidence_threshold=confidence_threshold, maximum_candidate_count=maximum_candidate_count,
        tolerance_factor=tolerance_factor, time_limit=time_limit, coefficient_bound=coefficient_bound,
        maximum_subclade_frequency=maximum_subclade_frequency,
        fine_tolerance_ratio=fine_tolerance_ratio,
    )
    _integer(seed, "seed", 0)
    case = _CaseData(name=case_name, training=training, validation=validation,
                     terminals=[int(label) for label in labels], root=int(root),
                     truth_clades=None, truth_cherries=None, source_inputs=source,
                     validation_source_inputs=validation_source)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    summaries, candidates, milp = [], [], []
    _collect_case_records(_execute_case(
        case, bootstrap_replicates=bootstrap_replicates, block_length=block_length,
        confidence_threshold=confidence_threshold, maximum_candidate_count=maximum_candidate_count,
        tolerance_factor=tolerance_factor, seed=seed, maximum_subclade_frequency=maximum_subclade_frequency,
        fine_tolerance_ratio=fine_tolerance_ratio, selection_only=selection_only,
        run_baseline=run_baseline, coefficient_bound=coefficient_bound, time_limit=time_limit,
        milp_solver=milp_solver, artifact_dir=output,
    ), output, summaries, candidates, milp)
    manifest = [{"case": case_name, "split": split, "name": scenario["name"],
                 "samples": len(scenario["P_terminal"]), "terminal_count": len(labels)}
                for split, scenarios in (("training", training), ("validation", validation or []))
                for scenario in scenarios]
    payload = {"config": {
        "input_mode": "observed", "case_name": case_name, "root": int(root),
        "terminal_labels": [int(label) for label in labels], "preprocessing": "raw",
        "source_mode": "fixed_amplitude" if active_source else "none",
        "source_provenance": list(source.provenance) if source is not None else [],
        "validation_source_provenance": list(validation_source.provenance) if validation_source is not None else [],
        "validation_source_path_refitted": False, "truth_available": False,
        "truth_used_for_candidate_generation": False, "bootstrap_frequency_is_calibrated_probability": False,
        "bootstrap_replicates": bootstrap_replicates, "block_length": block_length,
        "tolerance_factor": tolerance_factor, "confidence_threshold": confidence_threshold,
        "maximum_candidate_count": maximum_candidate_count,
        "maximum_subclade_frequency": maximum_subclade_frequency, "fine_tolerance_ratio": fine_tolerance_ratio,
        "selection_only": selection_only, "run_baseline": run_baseline, "milp_solver": milp_solver,
        "time_limit_seconds_per_extension": time_limit, "coefficient_bound": coefficient_bound, "seed": seed,
        "rnj_atomic_block_rule": "complete_direct_terminal_children", "minimum_atomic_block_size": 3,
        "support_search_mode": "block_atomic",
    }, "scenarios": manifest, "rnj": summaries, "rnj_boundary_candidates": candidates, "milp": milp}
    (output / "metrics.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    return payload


def main() -> None:
    """Delegate the historical module entrypoint to the shared CLI parser."""
    from rnj_wzzt.cli import main as cli_main

    cli_main(runner=run, observed_runner=run_observed)


if __name__ == "__main__":
    main()
