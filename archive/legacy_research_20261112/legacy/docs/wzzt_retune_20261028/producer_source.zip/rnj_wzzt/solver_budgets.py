"""Shared solver budgets; explicit caller limits always take precedence.

MILP time is per LP/MILP call, not the entire greedy search. Production RNJ
SLSQP has an iteration budget and no wall-clock cutoff. The QP seconds and
gradient iterations apply to research backends. Only the subprocess runner
enforces the outer benchmark wall limit. Low-level time_limit=None remains
unlimited; solver optimality and feasibility tolerances are unchanged.
"""

DEFAULT_MILP_TIME_LIMIT = 3600.0
DEFAULT_QP_TIME_LIMIT = 300.0
DEFAULT_QP_MAX_ITERATIONS = 5000
DEFAULT_GRADIENT_MAX_ITERATIONS = 20000
DEFAULT_BENCHMARK_WALL_LIMIT = 14400.0
