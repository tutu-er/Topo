"""Parse command-line options and delegate computation to :mod:`pipeline`.

Omitted options are not forwarded: ``pipeline.run`` owns every computation
default. The historical Python and advanced CLI entrypoints remain delegates.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Sequence

from rnj_wzzt.pipeline import DEFAULT_CASES, DEFAULT_OUTPUT, run as run_pipeline, run_observed as run_observed_pipeline
from rnj_wzzt.scenario.settings import ROOT_OBSERVATIONS, SCENARIO_SUITES
from rnj_wzzt.solver_budgets import DEFAULT_MILP_TIME_LIMIT


def _argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run the standalone RX75-RNJ plus L1-wzzT pipeline.",
        argument_default=argparse.SUPPRESS,
        epilog="Omitted options use pipeline.run defaults: reference scenarios and RNJ plus MILP.",
    )
    parser.add_argument("--output", dest="output_dir", type=Path)
    parser.add_argument("--cases", nargs="+", choices=DEFAULT_CASES)
    parser.add_argument("--observed-input", type=Path,
                        help="JSON measured P/Q/drop scenarios and optional fixed source amplitudes (pu)")

    scenarios = parser.add_argument_group("scenario generation")
    scenarios.add_argument("--scenario-suite", choices=tuple(SCENARIO_SUITES))
    scenarios.add_argument("--scenario-count", type=int)
    scenarios.add_argument("--samples-per-scenario", type=int)
    scenarios.add_argument("--training-replicate", type=int)
    scenarios.add_argument("--validation-replicate", type=int)
    scenarios.add_argument("--pq-noise-rel", type=float)
    scenarios.add_argument("--voltage-noise-rel", type=float)
    scenarios.add_argument("--root-observation", choices=ROOT_OBSERVATIONS)
    scenarios.add_argument("--root-sigma", type=float,
                           help="Physical root background standard-deviation scale, p.u.")
    scenarios.add_argument("--root-meter-noise-rel", type=float,
                           help="Root meter random error standard deviation, relative")
    scenarios.add_argument("--impedance-scale", type=float,
                           help="Absolute multiplier of the synthetic line library")

    selection = parser.add_argument_group("RNJ boundary selection")
    selection.add_argument("--tolerance-factor", type=float)
    selection.add_argument("--bootstrap-replicates", type=int)
    selection.add_argument("--block-length", type=int)
    selection.add_argument("--confidence-threshold", type=float)
    selection.add_argument("--maximum-candidate-count", type=int)
    selection.add_argument("--maximum-subclade-frequency", type=float,
                           help="Maximum bootstrap internal-subclade frequency for an atomic block")
    selection.add_argument("--fine-tolerance-ratio", type=float,
                           help="RNJ tolerance multiplier used to veto hidden internal sublayers")

    solver = parser.add_argument_group("MILP")
    solver.add_argument("--time-limit", type=float,
                        help=f"Wall-time seconds per LP/MILP solve (default {DEFAULT_MILP_TIME_LIMIT:g}; not total search time)")
    solver.add_argument("--milp-solver", choices=("highs", "gurobi"))
    solver.add_argument("--coefficient-bound", type=float)

    diagnostics = parser.add_argument_group("optional diagnostics and comparison")
    selection_mode = diagnostics.add_mutually_exclusive_group()
    selection_mode.add_argument("--selection-only", action="store_true",
                                help="Stop after RNJ boundary selection; skip MILP")
    selection_mode.add_argument("--run-milp", dest="selection_only", action="store_false",
                                help=argparse.SUPPRESS)
    baseline_mode = diagnostics.add_mutually_exclusive_group()
    baseline_mode.add_argument("--run-baseline", action="store_true",
                               help="Also solve the MILP-only comparison")
    baseline_mode.add_argument("--hybrid-only", dest="run_baseline", action="store_false",
                               help=argparse.SUPPRESS)
    return parser


def run(*args, **kwargs) -> dict:
    """Compatibility delegate; use ``pipeline.run`` for the Python API."""
    return run_pipeline(*args, **kwargs)


def main(argv: Sequence[str] | None = None, *, runner=None, observed_runner=None) -> None:
    """Dispatch parsed simulation or observed inputs to their computation API.

    An explicit observed_runner separates the two APIs for compatibility
    entrypoints. A runner alone keeps the historical test/injection behavior
    and receives whichever input mode the caller selects.
    """
    parser = _argument_parser()
    options = vars(parser.parse_args(argv))
    if "observed_input" in options:
        generation = {"cases", "scenario_suite", "scenario_count", "samples_per_scenario",
                      "training_replicate", "validation_replicate", "pq_noise_rel", "voltage_noise_rel",
                      "root_observation", "root_sigma", "root_meter_noise_rel", "impedance_scale"}
        conflicts = generation & options.keys()
        if conflicts:
            parser.error("--observed-input cannot use simulation options: " + ", ".join(sorted(conflicts)))
        from rnj_wzzt.observed_input import load_observed_input
        try:
            observed = load_observed_input(options.pop("observed_input"))
        except ValueError as exc:
            parser.error(str(exc))
        observed_computation = observed_runner if observed_runner is not None else (
            run_observed_pipeline if runner is None else runner
        )
        observed_computation(**observed, **options)
        return
    if "cases" in options:
        options["cases"] = tuple(options["cases"])
    (run if runner is None else runner)(**options)


def advanced_main(*, runner=None, observed_runner=None) -> None:
    """Compatibility alias for the unified CLI and its current defaults."""
    main(runner=runner, observed_runner=observed_runner)
