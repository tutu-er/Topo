"""Frozen research package for the isolated MIQP benchmark."""
