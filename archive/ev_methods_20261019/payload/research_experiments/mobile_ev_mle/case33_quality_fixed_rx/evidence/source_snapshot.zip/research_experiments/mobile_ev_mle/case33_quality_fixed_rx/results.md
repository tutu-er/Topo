# Known-line case33 quality-score experiment

2026-10-18. The six-method experiment completed on original case33 lines.
The principal finding is that DF-I2 is close to full AC in the two declared
PV snapshots, but its score is substantially biased at the original full-load
snapshot. Allowing P/Q correction can hide part of physical approximation
error; a similar self score need not mean a similar fitted state.

## Model and reference

Original topology and R/X are fixed for every method: 33 buses, 32 physical
closed lines, 32 measured nonroot load buses, 12.66 kV and 10 MVA. Internal
loads remain in place through exact zero virtual observation leaves.

Let z=(p,q), y=(32 voltage magnitudes, root P, root Q). For model M:

\[
F_M(z)=\tfrac12\|(z-z^{obs})/\sigma_z\|^2+
       \tfrac12\|(h_M(z)-y^{obs})/\sigma_y\|^2.
\]

FIX uses z=z_obs; no variables remain to fit. EIV estimates the 64 powers.
AC-FIX is the within-FIX reference and high-accuracy local AC-EIV is the
within-EIV reference. Neither is the noise residual at the true state.
FIX/EIV have different state freedom, so their raw score decrease alone is
not a test of topology quality. This experiment contains one known topology.

The generator uses an independent physical-tree AC solver and adds noise.
Fitters receive the known lines and noisy data, never the true P/Q states.
Root voltage is known, fixed meter biases and the unmetered source are zero.
PV is included in the corresponding measured net P, with Q_PV=0.

## Cases and sample counts

Installed PV is a declared 2229 kW (60% of nominal total load), split between
buses 18/25/33 with weights .35/.30/.35. The common static snapshots are:

|snapshot|net load P kW|net Q kvar|root P kW|min/max voltage pu|
|---|---:|---:|---:|---|
|original full load, PV off|3715.00|2300.00|3917.68|0.91309 / 0.99703|
|day PV|631.55|1610.00|673.25|0.98053 / 0.99913|
|reverse-flow PV|-743.00|1150.00|-690.27|0.99772 / 1.02976|

These are declared numerical operating points, not imported measured time
series. Three states x two noise levels x eight seeds = 48 noisy single-slot
samples, plus three clean diagnostics. All 306 method slots returned; all
51 AC-EIV references met the predeclared convergence/agreement tests.
Two power-noise levels share standardized noise, leaving 24 distinct
standardized noisy draws; do not count these as independent histories.

P/Q noise sigma is .2% or 1% of nominal channel scale, not instantaneous net
power. Q scale=max(abs(Q_nom),.2 P_nom,1 kvar); P scale=max(P_nom,1 kW).
Voltage sigma is .0005 pu (0.05% nominal), root P/Q sigma .1% of nominal
total channel scale. These are assumed Gaussian standard deviations, not
meter-class maximum errors. All methods share the exact same observations.

## Scores at .2% power-meter sigma

Each entry is the mean half-SSE over eight noisy samples; smaller values
only have the stated within-task comparison meaning.

|method|full load|day PV|reverse PV|
|---|---:|---:|---:|
|LD-FIX|3536.37|212.56|365.42|
|DF-I2-FIX|73.87|19.24|16.24|
|AC-FIX reference|13.09|18.71|15.84|
|LD-EIV|2636.47|162.36|276.35|
|DF-I2-EIV|55.62|18.48|15.54|
|AC-EIV reference|12.89|18.09|15.20|

DF-I2-EIV mean per-sample absolute relative score error is 340.59%, 3.92%,
and 3.65%, respectively. This metric averages each sample's relative error;
it is not the ratio of the displayed mean scores. LD has much larger errors
in every declared state. All inconvenient full-load results are retained.

## Separate score bias from state error

For each returned state z_M, compute J_self=F_M(z_M) and J_back=F_AC(z_M).
With the corresponding FIX/EIV AC reference J_ref:

\[
J_{self}-J_{ref}=(J_{self}-J_{back})+(J_{back}-J_{ref}).
\]

The first term is model scoring bias; the second is state-fitting loss.
FIX has zero state-fitting loss by definition. EIV results show:

|power sigma|snapshot|DF-I2 self|same state under AC|AC-EIV reference|
|---|---|---:|---:|---:|
|.2%|full load|55.62|31.18|12.89|
|.2%|day PV|18.48|18.16|18.09|
|.2%|reverse PV|15.54|15.29|15.20|
|1%|full load|19.67|71.01|13.38|
|1%|day PV|18.31|18.37|18.13|
|1%|reverse PV|14.86|15.13|14.83|

The full-load 1% row is particularly informative: allowing noisy P/Q to move
reduces DF-I2's self score, while its AC back-score increases substantially.
State correction is compensating for model error. Thus score agreement alone
is insufficient; the common physical back-score is required.

At full load DF-I2 underestimates root active power by about 26.5--26.8 kW
at its EIV states, versus a root-P sigma of 3.715 kW. Its maximum voltage
discrepancy is only about .00042 pu (0.042%), demonstrating why voltage error
alone misses the score problem. The root P/Q channels and their precision
are material parts of this experiment's definition of J.

## P/Q noise and computation

The known-line AC references isolate the noise issue:

|power sigma|AC-FIX full/day/reverse|AC-EIV full/day/reverse|
|---|---|---|
|.2%|13.09 / 18.71 / 15.84|12.89 / 18.09 / 15.20|
|1%|23.01 / 32.38 / 26.04|13.38 / 18.13 / 14.83|

The .2% case has relatively small score changes; the 1% case makes ignoring
P/Q input error much more consequential. These few noise draws do not give
calibrated false-rejection probabilities or unknown-line parameter accuracy.

Single-slot EIV primary solve medians span roughly 3--18 ms for LD,
4--18 ms for DF-I2 and 9--45 ms for AC in this shared-machine run. Numerical
audits, model construction and independent replay are charged separately.
FIX is a forward evaluation; dividing FIX and EIV times is not a solver
speedup. Shared response caches can reuse AC-FIX values at the EIV initial
point. AC Jacobians also compute unused R/X columns through the existing
interface. These times describe this implementation, not optimized or
dedicated-machine performance, nor 96/288-point unknown-R/X fitting.

Primary timings remain attached to the primary solve even when an audit
start supplies the best last-bit score. Best-state accuracy and primary
timing are therefore deliberately separate records.

## Numerical verification and remaining scope

Five meaningful tests cover independent physical-tree agreement, signed PV
accounting, all three directional derivatives, scalar closed-form EIV
minimization, clean AC and paired noisy score identities. The first pytest
collection from the unrelated D-mainline cwd resolved the wrong same-name
package; explicit study cwd/import source corrected collection, then 5/5
passed. This is a test invocation issue, not a dropped numerical fit.

Every fitted state is replayed with the independent physical-tree AC solver.
The saved audit also rebuilds LD/DF-I2 from physical branches rather than
the candidate response class, and checks score/channel arithmetic and gradients.
Clean states are only numerical checks, not optimizer initializations for
the noisy samples. Exact score decomposition and failures remain in raw JSON.

All references are local solutions with strict gradient and multistart
agreement; there is no global-optimality certificate. Known R/X and no
unknown source make this a deliberately easier diagnostic than line and
topology identification. It supports no conclusion yet about EV planning,
multi-topology ordering, or 96/288-point R/X estimation.

Next use the same six-way comparison with unknown shared R/X over 96/288
points, only after retaining this full-load failure and checking whether
further loss correction or AC refinement controls score and state errors.
This next experiment is not part of the present completed batch.
