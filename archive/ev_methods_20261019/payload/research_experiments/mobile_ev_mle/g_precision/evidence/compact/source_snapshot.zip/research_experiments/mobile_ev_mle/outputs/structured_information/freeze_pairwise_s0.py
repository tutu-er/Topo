from pathlib import Path
import sys,json,gzip,base64,hashlib
sys.path.insert(0,str(Path.cwd()))
from research_experiments.mobile_ev_mle.gradient_price_source_restore import audit_source_bytes
p=Path('research_experiments/mobile_ev_mle');e=p/'evidence/structured_information';f=e/'v3_frozen'
a=audit_source_bytes(f/'science_source_snapshot.json.gz',source_root=p,freeze=f/'freeze.json');assert a['success'] and a['checked_count']==19
r=json.loads((e/'pairwise_cone_root_validation.json').read_text());r['frozen_science_audit']=a;(e/'pairwise_cone_root_validation.json').write_text(json.dumps(r,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
names=['pairwise_cone_checks.py','test_pairwise_cone_checks.py'];hashes={n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in names}
snapshot=dict(schema='gradient_price_source_bytes_v1',source_sha256=hashes,files={n:base64.b64encode((p/n).read_bytes()).decode('ascii') for n in names})
with gzip.open(e/'pairwise_cone_analytic_source_snapshot.json.gz','wt',encoding='utf-8') as h:json.dump(snapshot,h,sort_keys=True)
(e/'pairwise_cone_analytic_freeze.json').write_text(json.dumps(dict(source_sha256=hashes,scope='gate1 exact fixed-matrix audit only; no actualAC orEV optimizer',audit_evidence='pairwise_cone_analytic.json',root_tests=49),sort_keys=True,indent=2)+'\n',encoding='utf-8')
print('S0 exact source2 and original frozen19 verified')