from pathlib import Path
p=Path('research_experiments/mobile_ev_mle'); f=p/'pairwise_tolerance_report_fragment.tex'
s=r'''% Inline supplement only; original report and original PDF remain the delivery.
\subsection{正边竞争的解析检查与两条历史的 AC 尺度验证}
\label{si:pairwise-check}
当前投影检查疑似边相对零边收缩结构的可见性。另一 cherry 的正内部边也可能解释信号。固定历史中心和动作，令 $A_s,A_r$ 分别是两个支撑的 R/X 白化导数，$\zeta$ 是声明的源侧工程方向，$\eta$ 是竞争侧非负 R/X，则应核查
\begin{equation}
 D_{s\to r}(u;\zeta)=\min_{\eta\ge0,\delta\nu}
 \norm{A_s\zeta-A_r\eta+B\delta\nu}^2
 \le \norm{(I_{N_y}-P_B)A_s\zeta}^2.
 \label{si:pairwise-cone}
\end{equation}
$\eta=0$ 给出右侧解释，所以距离不增；自由 $\delta\nu$ 先由正交投影消去，再求到两个正边列张成锥的距离。其含义是：另一结构通过合法正边和其他参数共同调整后，还剩多少信号。小矩阵例 $A_s=A_r=I_2,B=0$、$\zeta=(.003,.002)^T$ 中，旧值为 $.003^2+.002^2$；取 $\eta=\zeta$ 得距离零，而且两分量都超过 $10^{-6}$ 下界。这是解析反例，实际拓扑导数是否有这种关系另由 AC 检查。

若采用本式的 source-minus-competitor 残差，$\delta\nu$ 是其他参数的源减竞争差；固定源侧时它等于竞争增量的负数。竞争 X 位于下界时，其增量必须非负，故对应 $\delta\nu_X\le0$。在稳定活动面和秩、光滑最优补偿条件下，记最优残差为 $e$，固定工程方向后的功率价格为
\begin{equation}
 \frac{\partial D_{s\to r}}{\partial u_t}
 =2e^T\left(\frac{\partial A_s}{\partial u_t}\zeta
 -\frac{\partial A_r}{\partial u_t}\eta
 +\frac{\partial B}{\partial u_t}\delta\nu\right).
 \label{si:pairwise-price}
\end{equation}
正规式和非负锥的互补条件消去最优参数的微分项。该式包含竞争边与补偿空间变化；28项解析测试及有限差分检查通过。小矩阵输入按其精确二进制有理值验证 primal/dual，返回浮点可行解另精确回算并对界向外舍入。此计算只审计固定矩阵；实际功率曲线继续由优化问题配置。

第二门固定选已有 pilot 中前两个不同历史标识 930001、930002，各取首个文件和 H-only 星形中心。工程方向为 $\varepsilon(.003,.00003)^T$ 与 $\varepsilon(.00003,.003)^T$，$\varepsilon\in\{1,.5,.25\}$；动作固定为节点0恒充和可行交替初值。每 H 保留9个有向对、2方向、3尺度、2动作，共108任务；源侧由历史中心生成物理均值，竞争侧完整重拟合共享线路、逐时 P/Q 和同接口源。该验证使用确定的工程情景，没有读取真实未来或选择新 EV 动作。

两 H 共216任务、432次固定预算拟合，全部完成；3130次函数评价、3639次 AC 调用、约205.30秒。1728个保存状态独立重放通过。$\varepsilon=.25$ 时，已取得 AC 成本除以原有限盒局部值的范围分别为 $[.9984988,1.0041325]$ 和 $[.9983126,1.0056851]$。所有步骤/尺度和逐行 Taylor 余量均保留；这是有限尺度吻合，统一余项和全局近优序列未由这些点确定。

第一 H 有共同线路 X 下界活动，自由投影、原单侧切锥和有限正盒分别报告；第二 H 的中心位于盒内。另一 cherry 的补偿在第一 H 最多降低约 $.0108\%$，第二 H 某方向降低约 $10.5\%$。例如第二 H 固定恒充的 $12\to01$、R方向在尺度1时，star与cherry已取得局部 AC 成本分别为1.3382405和1.1986227。这些可行成本各给出相应 AC 最小距离的上界。按固定历史任务权重汇总的 H+N 半距离修正，第一 H 两动作为 $.00735\%,.00614\%$，第二 H 为 $.16475\%,.04743\%$；排序均保持。此汇总是固定任务水平，并未计算新 EV 增量或新策略收益。因此保留竞争修正与诊断器，当前证据不足以增加选择器复杂度；新正式批次和扩网仍待下一项可检验改进。

\subsection{校准门槛的容忍界：风险与未决的取舍}
\label{si:tolerance-check}
原第36秩控制随机校准样本和新历史共同平均的风险。若还要求抽到一个风险超过 $\alpha$ 的固定门槛的概率至多 $\delta$，可用另一条有限样本结论。沿用全方法最大分数 $S$，真候选须在候选集；必要拟合失败先置 $S=+\infty$。对固定门槛定义超越风险 $\mathcal R(\kappa)=\Pr_{\rm new}(S>\kappa)$，它包含可能的实际误拒。若 $n_C$ 个校准分数独立同分布于同一冻结总体，则
\begin{equation}
 \boxed{\Pr_{\rm cal}\{\mathcal R(S_{(k)})>\alpha\}
 \le\sum_{j=k}^{n_C}\binom{n_C}{j}(1-\alpha)^j\alpha^{n_C-j}.}
 \label{si:tolerance-bound}
\end{equation}
证明：记 $F_S$ 为分数分布函数。使 $F_S(s)<1-\alpha$ 的分数形成一个下段，其概率至多 $1-\alpha$；第 $k$ 个分数位于该段，当且仅当至少 $k$ 个校准分数落入该段。该计数是二项分布，其上尾随成功率递增，即得此界。保留规则采用 $S\le\kappa$，故相等值保留；$F_S(+\infty)=1$，无穷门槛保留全部已有候选。

先固定 $n_C=39,\alpha=.1,\delta=.05$，再只读校准记录选择满足式\eqref{si:tolerance-bound}的最小秩。第38秩尾界为 $.0875904$，第39秩为 $.9^{39}=.0164232$，因此取39，诊断门槛为4.9258142507602045。界的概率来自随机校准集；其范围是声明总体混合，star、weak或固定物理参数的条件风险另需校准。实际当前门槛的风险值仍未知。

随后只对原80条保存损失重新计算保留集合，旧门槛及记录不改。任一方法误拒由11/80变6/80；信息设计四类结果由 $57/16/7/0$ 变为 $55/23/2/0$，恒充由 $49/27/3/1$ 变为 $48/31/0/1$，全局质量规则由 $53/22/5/0$ 变为 $48/31/1/0$。更大门槛使所有保留集合只增不减，减少误拒，同时可能把正确唯一变成未决。信息设计 weak 的正确唯一由2/12变0/12；弱边问题继续保留。原880个方法--历史集合全部重算匹配，新集合均为其超集。这个结果是正式评价后的只读诊断，未新增前瞻样本、未改变部署策略；后续收益比较需要另存冻结并使用新历史。
'''
f.write_text(s,encoding='utf-8');doc=Path('docs/mobile_ev_probing_report_v2.tex'); t=doc.read_text(encoding='utf-8'); assert '\\label{si:pairwise-check}' not in t;t=t.replace('\\appendix',s+'\n\\appendix',1);doc.write_text(t,encoding='utf-8')
print('two-H and tolerance supplement appended to original source')