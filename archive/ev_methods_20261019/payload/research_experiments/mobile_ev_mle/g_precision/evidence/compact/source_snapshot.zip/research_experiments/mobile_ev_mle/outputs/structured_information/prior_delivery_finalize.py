from pathlib import Path
import hashlib,json,re,datetime
from pypdf import PdfReader
root=Path.cwd();here=root/'research_experiments/mobile_ev_mle';evidence=here/'evidence/structured_information';out=here/'outputs/structured_information'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
src=root/'docs/mobile_ev_probing_report_v2.tex';pdf=src.with_suffix('.pdf');log=src.with_suffix('.log')
assert len(PdfReader(pdf).pages)==67
latest=(out/'latex_gate2_pass_3.txt').read_text(encoding='utf-8',errors='replace')
assert 'Output written on mobile_ev_probing_report_v2.pdf (67 pages).' in latest
bad={'duplicate_label':bool(re.search(r'multiply defined|duplicate.*label',latest,re.I)),'label_rerun':bool(re.search(r'Rerun to get cross-references right|Label\(s\) may have changed',latest,re.I)),'missing_glyph':'Missing character:' in latest,'overfull':'Overfull \\hbox' in latest or 'Overfull \\vbox' in latest,'undefined_reference':bool(re.search(r'(Reference|Citation).*undefined|There were undefined references',latest))}
assert not any(bad.values()),bad
old=json.loads((evidence/'delivery_verification.json').read_text())
old.update(pages=67,source_sha256=sha(src),pdf_sha256=sha(pdf),log_sha256=sha(log),local_pass_log_sha256={str(i):sha(out/f'latex_gate2_pass_{i}.txt') for i in (1,2,3)},log_checks=bad,full_science_tests=890,full_science_tests_scope='gate2_full_tests_stdout.txt before later explicit compact-loader and CSV-audit IO edits; current changed modules covered by 42 targeted tests',targeted_current_tests=42,visual_checked_ranges_1based=[[1,4],[54,67]],visual_findings='current67-page original PDF: readable Chinese/equations/tables; current contact sheets1-4 cover1-4 and54-67, individual64-66 checked; no clipping, overlap, missing glyphs or abnormal empty pages',verification_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
old['visual_rounds'].append({'proof':'67-page pairwise-cone and calibration-tolerance original report','contact_ranges':[[1,4],[54,67]],'contact_sheet_prefix':'prior_delivery_contact','individual_pages':[64,65,66]})
images={}
for p in (out/'pdf_review_gate2').glob('*.png'):
    if p.name.startswith(('front-','body-','prior_delivery_contact_')):images[p.name]=sha(p)
old['latest_render_sha256']=images
(evidence/'delivery_verification.json').write_text(json.dumps(old,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
cp=json.loads((here/'structured_information_checkpoint.json').read_text())
cp.update(stage='pairwise_cone_AC_scale_and_tolerance_diagnostic_complete',status='formal39cal80eval_preserved_two_H_scale_gate_complete_new_EV_flexibility_protocol_next',next_step='declare EV flexibility versus ESS and staff availability protocol, then operational and AC-information tests before independent pilot; no expansion gate yet',full_tests_passed=890,full_tests_scope=old['full_science_tests_scope'],targeted_current_tests_passed=42,pairwise_AC_scale_histories=2,pairwise_AC_scale_tasks=216,pairwise_AC_scale_fits=432,pairwise_AC_scale_nfev=3130,pairwise_AC_scale_AC_calls=3639,pairwise_AC_scale_state_replays=1728,pairwise_AC_scale_failures=0,pairwise_AC_scale_scope='two fixed H-only means, two fixed feasible node0 actions,9 directed pairs,2 positive engineering directions,3 scales; not a new selector or independent formal evaluation',pairwise_weighted_score_correction_percent_max=0.1647547891170342,new_pairwise_selector_implemented=False,tolerance_diagnostic_rank=39,tolerance_diagnostic_threshold=4.9258142507602045,tolerance_diagnostic_old_any_false=11,tolerance_diagnostic_new_any_false=6,tolerance_diagnostic_scope='post-formal same80 saved-loss reclassification only; original rank36 strategy andrecords unchanged; no forward evaluation or star/weak conditional guarantee',report_pages=67,report_delivery_verified=True,full_research_complete=False)
cp['uncompleted_research']=[x for x in cp['uncompleted_research'] if x!='pairwise positive-edge competition rather than collapse-only target']
cp['uncompleted_research'].extend(['EV flexibility comparison with fixed ESS and staff availability','pairwise positive-edge selector: local-object gate passed but weighted correction below0.2%; not deployed'])
(here/'structured_information_checkpoint.json').write_text(json.dumps(cp,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
readme=here/'README.md';text=readme.read_text(encoding='utf-8')
needle='## 单节点完整梯度价格（2026-10-13，本轮实施）'
extra='''正边竞争的两H固定尺度验收已完成：216任务、432次局部AC拟合、3639次AC调用和1728状态独立重放，全部任务保留。一个正边竞争可将部分模型距离减少约10.5%，但历史任务权重下总分修正不足0.2%，两条固定曲线的排序未变；据此保留推导与模块，尚未部署新选择器。见 `pairwise_cone_checks.py`、`pairwise_cone_ac_scale.py` 与 `evidence/structured_information/pairwise_cone_ac_scale/two_H_analysis.md`。新模块显式读取紧凑 `inputs.json.gz`，针对性测试无需旧未跟踪pilot原始记录。

固定门槛的随机校准集容差界与独立CSV核验已补全。预声明n39、alpha=.1、delta=.05给出rank39；对原80保存损失的事后诊断，任一方法误拒11/80降为6/80，信息设计唯一正确57/80变55/80。原rank36正式策略及全部记录保留；本诊断未提供新前瞻评价，star/weak条件风险仍待解决。见 `calibration_tolerance_math.md`、`calibration_tolerance_audit.py`。

上一阶段全套890项通过记录属于当时源码；随后紧凑输入与CSV核验修改的当前42项针对性测试通过。原报告已原位编译并检查为67页；整个研究仍有proper预测EIG、弱支路风险、滚动与扩网等未完成项。

'''
assert needle in text
if '正边竞争的两H固定尺度验收已完成' not in text:text=text.replace(needle,extra+needle,1)
text=text.replace('连续功率由 MILP 价格步优化','连续功率由 LP/MILP 价格步优化',1).replace('MILP 界属于仿射子问题','LP/MILP 界属于仿射子问题',1)
readme.write_text(text,encoding='utf-8')
validation={'success':True,'targeted_tests':{'count':42,'seconds':2.87,'command':'python -m pytest research_experiments/mobile_ev_mle/test_pairwise_cone_ac_scale.py research_experiments/mobile_ev_mle/test_calibration_tolerance_audit.py -q -p no:cacheprovider','source_sha256':{n:sha(here/n) for n in ['pairwise_cone_ac_scale.py','test_pairwise_cone_ac_scale.py','calibration_tolerance_audit.py','test_calibration_tolerance_audit.py']}},'CSV_replay_path':'evidence/structured_information/prior_delivery_CSV_replay.json','CSV_replay_sha256':sha(evidence/'prior_delivery_CSV_replay.json'),'report_pages':67,'report_source_sha256':sha(src),'report_PDF_sha256':sha(pdf),'frozen19_source_unchanged':cp['source_sha256']==json.loads(__import__('gzip').decompress((evidence/'v3_frozen/science_source_snapshot.json.gz').read_bytes()))['source_sha256'],'no_new_scientific_experiments':True,'full_tests890_prior_source_scope':old['full_science_tests_scope']}
assert validation['frozen19_source_unchanged']
(evidence/'prior_delivery_targeted_validation.json').write_text(json.dumps(validation,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'pages':67,'current42_tests':True,'log_checks':bad,'source_sha256':sha(src),'PDF_sha256':sha(pdf)},ensure_ascii=False))
