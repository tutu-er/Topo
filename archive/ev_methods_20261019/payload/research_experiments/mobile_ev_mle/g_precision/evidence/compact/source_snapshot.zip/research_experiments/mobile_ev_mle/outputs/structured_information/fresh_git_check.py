from pathlib import Path
import json,subprocess,zipfile,hashlib,sys
sys.path.insert(0,str(Path.cwd()))
from research_experiments.mobile_ev_mle.gradient_price_source_restore import audit_source_bytes
root=Path.cwd(); p=Path('research_experiments/mobile_ev_mle'); e=p/'evidence/structured_information'; frozen=e/'v3_frozen'; freeze=json.loads((frozen/'freeze.json').read_text()); git=r'C:/Users/23761/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/git/cmd/git.exe'
commit=subprocess.check_output([git,'rev-parse','HEAD'],text=True).strip(); dest=root/p/'outputs/structured_information'/('fresh_git_'+commit[:8]+'_package'); dest.mkdir(exist_ok=False)
paths=[str((p/name).resolve().relative_to(root)).replace('\\','/') for name in freeze['source_sha256']]
paths += [str(p/name).replace('\\','/') for name in ['__init__.py','gradient_price_source_restore.py','information_power_link_checks.py','test_information_power_link_checks.py']]
paths += [str(frozen/name).replace('\\','/') for name in ['freeze.json','science_source_snapshot.json.gz']]
archive=dest/'science.zip'; subprocess.run([git,'archive','--format=zip','--output='+str(archive),'HEAD',*paths],check=True)
checkout=dest/'checkout'; checkout.mkdir()
with zipfile.ZipFile(archive) as z:
 for n in z.namelist():
  target=(checkout/n).resolve(); assert target.is_relative_to(checkout.resolve())
 z.extractall(checkout)
fresh=checkout/p; snapshot=fresh/'evidence/structured_information/v3_frozen/science_source_snapshot.json.gz'; fr=fresh/'evidence/structured_information/v3_frozen/freeze.json'
before=audit_source_bytes(snapshot,source_root=fresh,freeze=fr,restore_line_endings=False)
after=audit_source_bytes(snapshot,source_root=fresh,freeze=fr,restore_line_endings=True)
assert after['success'] and after['checked_count']==19
run=subprocess.run([sys.executable,'-m','pytest','research_experiments/mobile_ev_mle/test_information_power_link_checks.py','-q','-p','no:cacheprovider'],cwd=checkout,capture_output=True,text=True)
(dest/'checks_stdout.txt').write_text(run.stdout+run.stderr,encoding='utf-8'); assert run.returncode==0,run.stdout+run.stderr
report=dict(success=True,git_commit=commit,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_member_count=len(paths),archive_path=str(archive),raw_evaluation_archives_in_git=False,source_before=before,source_after=after,independent_power_tests_stdout=run.stdout.strip(),test_command='python -m pytest research_experiments/mobile_ev_mle/test_information_power_link_checks.py -q -p no:cacheprovider',scope='fresh Git archive, actual frozen scientific byte restoration and21 independent power checks; full119 raw AC replay already recorded from original histories; no claim of fresh rerun of119 optimization samples')
(e/'fresh_git_source_validation.json').write_text(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(success=True,commit=commit,exact_before=before['exact_before_count'],line_endings_only=before['line_ending_only_count'],exact_after=after['exact_after_count'],power_checks=run.stdout.strip())))