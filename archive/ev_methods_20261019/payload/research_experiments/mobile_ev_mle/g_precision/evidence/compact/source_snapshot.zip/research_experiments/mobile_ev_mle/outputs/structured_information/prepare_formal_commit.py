from pathlib import Path
import json,hashlib,subprocess,gzip,sys
sys.path.insert(0,str(Path.cwd()))
from research_experiments.mobile_ev_mle.gradient_price_source_restore import audit_source_bytes
p=Path('research_experiments/mobile_ev_mle'); e=p/'evidence/structured_information'; f=e/'v3_frozen'
a=audit_source_bytes(f/'science_source_snapshot.json.gz',source_root=p,freeze=f/'freeze.json',restore_line_endings=False)
assert a['success'] and a['checked_count']==19
checks=dict(success=True,observed='842 passed in 132.32s',test_command='python -m pytest research_experiments/mobile_ev_mle -q -p no:cacheprovider',stdout_sha256=hashlib.sha256((p/'outputs/structured_information/final_tests_stdout.txt').read_bytes()).hexdigest(),tests=842,science_source_audit=a,scope='final research suite; diagnostic helpers added outside frozen19; original outputs unchanged')
(e/'final_test_validation.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
paths=[p/'README.md',p/'information_results.py',p/'structured_information_checkpoint.json',p/'structured_information_results_review.md',p/'structured_information_results_review.json',p/'information_power_link_math.md',p/'information_power_link_checks.py',p/'test_information_power_link_checks.py',p/'averaging_stress_protocol.md',p/'averaging_stress.py',p/'averaging_stress_checks.py',p/'test_averaging_stress.py',p/'information_fit_recovery.py',e/'linear_power_link.json',e/'final_test_validation.json']
for x in f.rglob('*'):
 if not x.is_file():continue
 rel=x.relative_to(f).as_posix()
 if rel.startswith('stress_v_correlation/trials/') or rel.startswith('stress_v_correlation/replay/') or rel.startswith('stress_v_correlation/replay_extra/'):continue
 if x.name.startswith('trial_'):continue
 paths.append(x)
assert all(x.is_file() for x in paths)
paths=sorted({x.as_posix() for x in paths})
Path(p/'outputs/structured_information/stage_formal_paths.txt').write_text('\n'.join(paths)+'\n',encoding='utf-8')
print(len(paths),sum(Path(x).stat().st_size for x in paths),'bytes; frozen19 exact')