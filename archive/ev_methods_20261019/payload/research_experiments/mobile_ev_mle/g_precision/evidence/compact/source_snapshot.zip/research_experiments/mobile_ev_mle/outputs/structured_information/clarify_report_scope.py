from pathlib import Path
p=Path('research_experiments/mobile_ev_mle');r=Path('docs/mobile_ev_probing_report_v2.tex');text=r.read_text(encoding='utf-8')
old='前期采用固定参考的历史兼容损失与条件 Gaussian 响应距离；新增主选择器采用对称软历史惩罚，用完整 AC 白化导数构建冻结局部代理，由 MILP 联合配置地点、移动与连续功率，内层 QP 允许两边线路和同接口源调整。实际计量仍逐候选完整 AC 联合拟合。多初值局部求解只能报告最佳已发现局部似然，不能称为全局 MLE；代理优化界另行报告。'
new='第11节记录对称历史惩罚与局部 QP/MILP 的移动配置；第12、13节按单节点短时接入推进，连续功率由 MILP 价格步配置，再以完整 AC 检查目标。最新方法投影其他线路与逐时功率、源的补偿，增强疑似内部边的局部信号，最终仍逐候选完整 AC 联合拟合。局部多初值求解报告最佳已取得似然；MILP 界属于相应仿射子问题，完整非线性目标的全局保证另需证明。'
assert old in text;text=text.replace(old,new)
theory=p/'structured_information_report_theory.tex';t=theory.read_text(encoding='utf-8');marker='式\\eqref{si:projection}度量的是\\emph{其他线路、真实功率和源补偿后仍留下的信号}。只投影逐时状态会漏掉线路补偿。'
extra='当前公式比较疑似内部边与其零边收缩结构；另一 cherry 的新增内部边列尚未加入 $B$。三个支撑分别计算再平均，也不等于让另一 cherry 的正边参与竞争。下一阶段先检查这项补偿对距离的影响，再接回功率优化。'
assert marker in t;t=t.replace(marker,marker+extra);theory.write_text(t,encoding='utf-8');assert marker in text;text=text.replace(marker,marker+extra);r.write_text(text,encoding='utf-8')
print('clarified latest abstract and collapse-only geometry scope')