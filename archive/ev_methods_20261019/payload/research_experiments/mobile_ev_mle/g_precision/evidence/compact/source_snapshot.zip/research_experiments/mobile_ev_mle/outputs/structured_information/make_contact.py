from pathlib import Path
from PIL import Image,ImageDraw
p=Path('research_experiments/mobile_ev_mle/outputs/structured_information/pdf_review_20261014')
files=sorted(p.glob('page-*.png'))
for group in range(0,len(files),8):
 chunk=files[group:group+8]; out=Image.new('RGB',(1400,1020),'#dddddd');d=ImageDraw.Draw(out)
 for k,f in enumerate(chunk):
  im=Image.open(f);im.thumbnail((330,475));x=(k%4)*350+10;y=(k//4)*510+24;out.paste(im,(x,y));d.text((x,y-20),f.stem,fill='black')
 out.save(p/('contact_'+str(group//8+1)+'.png'))
print('contact sheets',9)