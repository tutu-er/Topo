from pathlib import Path
import json,time,datetime,traceback,hashlib
from research_experiments.mobile_ev_mle.adaptive_result_audit import run_audit
from research_experiments.mobile_ev_mle.empirical_design_analysis import run_analysis
from research_experiments.mobile_ev_mle.impedance_component_audit import run_audit as components
root=Path('research_experiments/mobile_ev_mle/outputs')
state=root/'postprocess_queue_status.json'
def save(**x):
 x['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();state.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def complete(p):
 try:
  x=json.loads((p/'summary.json').read_text(encoding='utf-8'))
  config=json.loads((p/'config.json').read_text(encoding='utf-8'))
  return len(list(p.glob('trial_*.json')))==config['count']
 except (OSError,KeyError,json.JSONDecodeError): return False
batches=[('C',root/'adaptive_milp/calibration_v3',root/'adaptive_milp/evaluation_v3',False),('D',root/'adaptive_rolling/calibration_v1',root/'adaptive_rolling/evaluation_v1',False)]
batches += [(label,root/'adaptive_milp/calibration_v3',root/('adaptive_milp/'+folder),True) for label,folder in [('bias','stress_bias_v1'),('source_drift','stress_source_drift_v1'),('load_trend','stress_load_trend_v1'),('missing_truth','stress_missing_truth_v1')]]
completed=[];failed=[]
for label,cal,ev,stress in batches:
 while not (complete(cal) and complete(ev)):
  save(state='waiting_for_complete_batch',waiting=label,completed=completed,failed=failed)
  if datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime(2026,10,13,0,20,tzinfo=datetime.timezone.utc):
   save(state='budget_checkpoint',waiting=label,completed=completed,failed=failed);raise SystemExit(0)
  time.sleep(20)
 out=ev.parent/(ev.name+'_audit')
 try:
  save(state='independent_AC_replay',batch=label,completed=completed,failed=failed)
  result=run_audit(cal,ev,out,.1,allow_stress=stress,replay=True)
  save(state='empirical_and_component_analysis',batch=label,completed=completed,failed=failed)
  run_analysis(ev,ev.parent/(ev.name+'_empirical'),collector=out,draws=1000,seed=881001)
  components(ev,ev.parent/(ev.name+'_impedance'))
  completed.append(label)
  print(json.dumps({'completed_postprocessing':label,'histories':result['evaluation_history_count']},ensure_ascii=False),flush=True)
 except Exception as e:
  err=dict(batch=label,error=repr(e),traceback=traceback.format_exc());failed.append(err)
  (root/('postprocess_failure_'+label+'.json')).write_text(json.dumps(err,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  print(json.dumps({'failed_postprocessing':label,'error':repr(e)},ensure_ascii=False),flush=True)
save(state='complete',completed=completed,failed=failed)
