# 连续密度 TeX 补充片段的只读核查

本次读取 `report_continuous_inverse_fragment.tex`，对照 `continuous_ac_inverse_math.md` 与 `continuous_inverse_peer_review.md`。未改片段，未运行程序、测试或积分；不重推全部常数。

两处应修订：

1. **单射证明中的变量维数。** 片段先把 x 定义为八维端点/主表 latent，而 F_theta(x) 是二维源。因此“令 F(x)=x+g(x)”字面上不成立。建议明确：固定端点 p,q，令 a=(P0,Q0)∈R=[0,1]×[0,.5]，写 F_theta(p,q,a)=a+g_theta(p,q,a)。对任意 a,b∈R 积分二维 Jacobian 的界，再得源映射的单射性。这是记号修订，原二维单射推导方向正确。
2. **变换密度的域。** 公式 `f_theta(x|u)=f_b(p-u/20,q) f_s(F_theta(x)) |det J_theta(x)|` 应乘 `1_R(P0,Q0)`，并在有效端点/参数支持外定义为零；或者明确积分范围是有效端点支持乘主表矩形。当前证明仅保证该矩形内逆映射合法，不能让不加域限制的 dx 积分读作任意 R8 上的同式。生成 prior 全映入 R，故此限制不损失 prior 质量。

已支持的公式与语义：

- leaf 高压根、shared G、源重建 F 与 source/master 的二维 Jacobian 与依据文件一致。密度因子为绝对值 |det J|，不是倒数；完整不变端点坐标给块三角 Jacobian。
- 公共背景 c 的交集长度密度是 Lc/(.024*.008^6)。Q 的 c 区间乘 4，不引入额外 .25 密度乘数。
- 端点背景扣 u/20 一次；物理状态与计量使用总 P/Q。H likelihood 乘一次，共享线路 posterior 用于未来预测，未重复 H。
- 前向生成支持的 |V|>.95 与逆变换整个矩形的 |V|>.949 是不同域的界。当前片段未直接将后者误写成前者，但应补一句明确两者，避免读者把整矩形误当成前向生成支持。
- proper 密度的数学归一性与数值积分稳定性分开。前三版 H-only 积分失败、第三版 ESS 33.82/36.09/12.31，不支持数值 posterior/EIG 排序；片段对此没有过度声明。

“20 项测试通过”的表述必须关联真实 pytest 输出。对照 peer review 指出旧 validation JSON 的 passed=20 曾为硬编码 metadata，本次只读该材料不能独立确认测试实际执行；若根代理已核对真实日志，则该句可保留，并在证据记录中保存日志来源。有限前向/逆向对照不替代全域归一性证明。
