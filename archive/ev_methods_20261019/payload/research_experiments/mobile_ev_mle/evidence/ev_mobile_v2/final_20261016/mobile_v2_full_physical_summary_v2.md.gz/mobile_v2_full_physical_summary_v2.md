# 352槽AC物理回放汇总 v2

改用stable4 pilot报告；其reviewer字节已从Git精确恢复。旧v1汇总与final4报告均保留，没有重跑AC。全部核心检查数量和最大误差与v1相同，失败QP计数覆盖从348增至352槽，计数仍为0。

|组别|槽数|唯一seed|保存状态|AC块|规划失败事件/槽|
|---|---:|---:|---:|---:|---:|
|formal_calibration|192|192|33712|79232|18/9|
|formal_evaluation|96|96|14380|34412|15/8|
|guard30_development|28|16|3740|9176|16/8|
|guard60_cost_validation|4|4|728|1724|0/0|
|original_development|28|16|5660|13136|0/0|
|original_pilot|4|4|772|1788|0/0|

352个唯一来源槽、308个唯一seed，全部物理回放passed。正式192校准＋96评价有288条独立seed；非正式64槽中的重复背景和不同版本单独保留。三种115源码快照及两种实际reviewer字节来源在JSON分列。

|核查项目|次数|
|---|---:|
|saved_states_replayed|58992|
|AC_block_replays|139468|
|method_mode_checks|11616|
|source_profile_pair_checks|41028|
|joint_predictive_fit_checks|13826|
|proxy_endpoint_checks|6361920|
|proxy_action_QP_checks|32964|
|gradient_MILP_checks|858|
|operation_replay_checks|3520|
|reference_guard_checks|956|
|reference_guard_MILP_checks|344|

旧32槽没有移动guard，相关可选字段保持原schema覆盖分母。包络价格检查是保存拟合点上的公式回算，未当成每次完整重拟合的有限差分检验。

|最大误差|值|
|---|---:|
|max_AC_equation|5.00905e-16|
|max_block_SSE_error|4.80213e-10|
|max_envelope_price_scaled_error|6.80493e-09|
|max_power_balance|7.35795e-16|
|max_whitened_residual_error|1.03439e-11|

|原记录中的失败或拒绝|事件数|涉及槽|覆盖槽|
|---|---:|---:|---:|
|recorded_failed_predictive_pairs|751|120|352/352|
|recorded_failed_proxy_QPs|0|0|352/352|
|recorded_incomplete_proxy_tables|3|3|352/352|
|recorded_inference_failures|2|1|352/352|
|recorded_invalid_proxy_actions|48|46|352/352|
|recorded_operation_failures|0|0|352/352|
|recorded_planning_failures|49|25|352/352|

规划/预测尝试失败及回退，与保存结果的物理回放失败分开报告。正式校准n4 index64仍保留2次推断失败；正式评价96槽推断失败0。物理回放失败总数0。

JSON SHA256：`ae22a57da17e3262fa08f8f80890134871d98ecbc75cfccd5b7e0d2f0da0d84c`。
