# 移动EV模型审查：时间、地点、功率与梯度

本轮只读冻结v2源码，未求解、未调用AC、未修改115个科学源文件或C盘源码。审查后获准在D-stage新增可达性收紧模块与测试，尚未接入策略。C盘核查分支为`codex/ev-train-validation-design`，HEAD为`54f6b6849fd4c109cc6e3a3c366d08e05e9c6a30`。执行代码位于D-stage；9个核查源文件与C盘同名文件SHA256一致，证据行另存同名JSON。

**结论：当前模型已经能联合选择“何时离开site0、到哪个地点、各时段充或放多少功率”。主要缺口是单次移动、人员与终点任务的简化，以及有限预算下父计划保留和动作表示的条件性问题。跨时段电气价值可以进入目标，但时变系数本身不足以保证移动有价值。**

## 1. 实际入口与三套模型的区别

冻结实验经`domains_for`进入`MobileServiceDomain`；旧场景调用`fixed._service`，新场景调用`ev_mobile_cases_v2.service_domain`。依据：[study:86](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_v2_study.py:86)、[fixed:485](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_fixed_train_design.py:485)、[cases:177](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_cases_v2.py:177)。

|文件|当前作用|单位与任务口径|
|---|---|---|
|`ev_mobile_service_domain.py`|正式v2的可执行动作域|kW、kWh；固定终端电池能量|
|`ev_operations_milp.py`|正式动作域仅复用其中`LinearMILP`；其`operation_model(EVConfig)`为另一套入口|kW、kWh；另固定电网侧净能量，可选终端电池能量|
|`ev_service_milp.py`|旧单地点服务优化，未进入正式v2选择器|标幺功率、标幺小时；先选一个地点，再优化曲线，含可选返程需求|

依据：[domain:15](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_service_domain.py:15)、[operations:308](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_operations_milp.py:308)、[service:1](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_service_milp.py:1)、[service:405](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_service_milp.py:405)。旧模块遍历少量地点的行为，不能用于描述正式v2的路线MILP。

## 2. 当前动作域确实表达了什么

令t为时段、j为地点、Δ为每时段小时数；c_tj、d_tj为非负充/放电功率，u_tj=c_tj−d_tj为净充电功率，E_t为电池kWh。每条弧e有二进制变量y_e，连接`(时刻, 地点, 是否已接线)`两个状态。弧分为等待、已接线停留、接线、驾驶四种。

### 单车路线与连续功率

流守恒从唯一初始状态发出一单位流，并在末时刻结束。驾驶和普通停留增加时间；零时长接线只从“未接线”走向“已接线”。因此状态图无环，整数单位流形成一条路径：不存在另一条不相连的充电路径。功率仅能出现在该路径的已接线停留弧上，且充/放电模式互斥：

\[
0\le c_{tj}\le \bar P^+_{tj}z_{tj},\quad
0\le d_{tj}\le \bar P^-_{tj}z_{tj},\quad u_{tj}=c_{tj}-d_{tj}.
\]

z_tj是该已接线弧。于是每时段最多一个地点功率非零，驾驶和接线时段均不能充放电。这里的连续功率不受预设曲线库限制。依据：[domain:241](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_service_domain.py:241)、[domain:274](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_service_domain.py:274)、[domain:292](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_service_domain.py:292)。

### 电池与任务

代码采用

\[
E_{t+1}=E_t+\Delta\sum_j(\eta_c c_{tj}-d_{tj}/\eta_d)
-\sum_{e:\,\mathrm{departure}(e)=t}g_e y_e.
\]

g_e是该趟驾驶消耗，出发时一次扣除；每个电池时段边界检查SOC上下限。当前Δ=0.25小时、功率上限6/1.05 kW、初始24 kWh、终端26.85 kWh、容量60 kWh、效率均0.95；总吞吐C+D≤7.5 kWh，C=ΔΣc、D=ΔΣd。依据：[domain:303](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_service_domain.py:303)、[fixed:43](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_fixed_train_design.py:43)。

这是**同终端电池服务**，不是各方案电网侧电量相同。由能量守恒可得

\[
C-D=(E_T-E_0)+G+(1-\eta_c)C+(1/\eta_d-1)D,
\quad G=\sum_e g_e y_e.
\]

驾驶与循环损耗会改变电网净注入。恒充和充放电方案在同一资源上限下比较；差异应分成位置、曲线及额外能量，不能只归为位置。

### 冻结实例的移动与人员条件

初始为site0且已接线。每次驾驶1槽、接线1槽，各15分钟；驾驶耗电0.2 kWh，最多一次移动，人员预算30分钟。每次到达后，目的地点累计绝对充放电量至少0.25 kWh。末地点未固定，也未要求末时刻已接线，故任务允许结束在远端。依据：[cases:185](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_cases_v2.py:185)、[domain:57](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_service_domain.py:57)、[domain:319](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_service_domain.py:319)。

通用API支持接入和工作人员窗口，但`worker_available`只检查接线，不检查驾驶时段。新正式场景access全True、worker沿用全True默认值；旧`access96`有晚接入窗口，未列入本轮正式N3_CASES。因此本批没有检验真实的人员窗口协调。依据：[domain:61](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_service_domain.py:61)、[domain:249](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_service_domain.py:249)、[cases:192](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_cases_v2.py:192)、[oldcases:140](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_systematic_cases.py:140)、[study:27](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_v2_study.py:27)。

## 3. 时间与采样单位

操作槽为15分钟。旧常规T=6对应1.5小时，remote8为2小时，twinblock12为3小时。新场景每通道总有效精度权重30，每单位100秒，即总积分3000秒；T=8/12分别每槽375/250秒，均小于900秒操作槽。这是相同测量积分预算，并非全时段连续采样，也不是小数个独立历史。跨场景时操作总时长不同，较长时窗本身也增加移动余量。依据：[oldcases:44](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_systematic_cases.py:44)、[cases:41](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_cases_v2.py:41)、[cases:77](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_cases_v2.py:77)、[cases:145](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_cases_v2.py:145)。

预算是**每通道**保持一致，n4比n3有更多并行通道。模型将每槽背景和EV功率视为代表该槽的稳态值，以对应测量精度产生观测；没有模拟槽内负荷变化和充电跟踪过程。

## 4. 目标是否带入不同地点、时段的价值

|策略|进入MILP的收益|时间/地点差异来自哪里|
|---|---|---|
|平方|Σw_tj u_tj²|电压计量精度；未使用负荷、线路或拓扑。正式均匀精度时空间权重相同|
|标量|各参考的最近竞争者源profile距离的平均值|每个t、j分别建功率响应表，矩阵含预测负荷、源和训练线路|
|封顶|全部有向任务的截断距离平均值|与标量相同，但容易任务可饱和|
|B|平均最近竞争者的共享线路联合拟合半SSE差|完整AC拟合后得到T×J价格，局部MILP优化平均方向增量，再完整AC接受|

依据：[precision:24](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_rx_precision.py:24)、[context:238](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_fixed_train_design.py:238)、[tables:79](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_systematic_design.py:79)、[scalar:215](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_systematic_design.py:215)、[B:213](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_v2_design.py:213)。

“源profile”在这里指：线路保持该拓扑的一组训练参数，只重新估计允许的共同源，取最小标准化残差。B是实验中共享线路梯度方法的名称：未来均值仍由各拓扑的一组训练参数产生，竞争解释则让线路和源共同重新拟合历史与预测未来。两者的内层调整范围不同，不能把标量代理的分段界当作B的全局界。

标量源变量逐时独立，固定线路的电气残差按时段分块。单车每槽仅一处注入，因此每个任务可写成Σ_t φ_tj(t)(p_t)，再由SOC和路线把各槽连接起来。3/9节点表是单地点、单时段的功率分段，不是完整路线或完整充电曲线枚举。矩阵在一个参考动作处冻结，完整AC接受可纠正错误提议，但不会主动找回代理漏掉的好计划。依据：[scalar:59](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_systematic_design.py:59)、[scalar:185](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_systematic_design.py:185)、[context:268](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_fixed_train_design.py:268)。

主目标没有把信息分数与工作人员分钟相减。时间和驾驶通过可行域、SOC和预算发生作用；`solve_prices`虽支持带单位的成本权重，当前主策略不使用该权重。当前标量也未传可选历史损失偏置，历史主要通过训练参数进入；B则直接要求解释历史。依据：[domain:198](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_service_domain.py:198)、[scalar:221](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_systematic_design.py:221)、[select:608](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_v2_design.py:608)。

## 5. “追逐不同时段的梯度”何时成立

在一个固定局部模型内，令λ_tj为每增加1 kW净功率带来的预计分数增量，I(u)=Σλ_tj u_tj。对任意移动净曲线p_t，将它同值放到site0，则纯位置的一阶增益恰为

\[
I(u_M)-I(u_0)=\sum_t(\lambda_{t,j(t)}-\lambda_{t,0})p_t.
\]

这证明现有T×J控制能表达时间变化的空间价格。整体相对固定最优曲线的收益，还要加I(u_0)−I(u_F)：后项含旅行/接线的机会损失、SOC任务和功率变化。空间项为正并不充分。

必要检查包括：目的地点在高价值时段可达且已接线；所剩功率时段能满足终端能量；信息增益足以抵消失去的激励窗口和新增能耗；预测出的排序能经完整AC及独立数据复现。若路线R的连接时段集合为A(R)，则

\[
E_0-G(R)+\eta_c\Delta\sum_{t\in A(R)}\bar P_t^+<E_T
\]

足以判定该路线无法完成任务，任何梯度都不能补救。SOC中途下限与吞吐上限还可进一步缩小可行域。

以下均为解析反例，未执行求解或算例：

1. **晚梯度很高但任务不可达。** T=3、每槽最多充1 kWh、终端需增加2 kWh，驾驶和接线各占1槽。移点后最多余1槽，无法完成任务，即使远端最后一槽价格为100也无效。
2. **两处晚窗口超出单次移动。** 六槽中，远端A只在槽2、B只在槽5有高价值。若人员预算允许两次服务，0→A（槽0驾驶、1接线、2激励）→B（3驾驶、4接线、5激励）可覆盖两窗；max1move最多覆盖一处。当前限制研究的是“一次重定位”，尚非持续追逐多个支路。
3. **时变幅值不等于时变最佳地点。** 在同净曲线、纯充电、各地点始终可接入的电气比较中，若λ_tj=a_j w_t且w_t≥0，同一个最大a_j地点逐槽占优。改变w_t只产生择时价值；相对仅固定site0的改善也可能只是静态选址价值。V2G、不同接入窗口或SOC约束需另行分析。
4. **没有空间价格也可出现“移动收益”。** 取T=4、Δ=0.25、P_max=4、效率0.95，电池24→25 kWh，单次驾驶0.2 kWh、接线1槽。统一λ_tj=1且仅充电时，固定计划的Σu=80/19，移动计划为96/19，移动评分高16/19；两槽远端充电足以完成任务。原因全是驾驶后需额外充电，位置没有任何电气差异。故必须保留同净曲线空间归因。
5. **零一阶价格掩盖曲率。** q_j(p)=a_jp²在p=0的所有梯度均为0，有限功率却能区分地点。B保留的标量/平方跳跃可以跨过该起点；单纯再解同一零价格MILP无帮助。

对V2G，还应看能量的机会成本。若终端能量约束乘子为μ，充电的局部有效系数为λ_tj−μη_cΔ，放电为−λ_tj+μΔ/η_d；中途SOC和吞吐约束会再改变这些系数。因此不能只按裸λ的大小选地点或逐槽独立贪心。

一个正向解析例子是六槽、Δ=1小时、P=1 kW、效率1、无驾驶能耗、终端增加2 kWh：仅site0槽0价格为3、远端槽5价格为5，其余为0。固定site0最多得3；槽0充1 kWh，槽1驾驶、槽2接线，最后远端再充1 kWh，可得8。若强制初始立即移点，只得5。这个例子说明现有一次重定位网络已经能表达“先利用本地早窗口，再利用远端晚窗口”，无需增加路线枚举。它是局部线性目标的构造证明，不是AC辨识收益实验。

### 失去两个操作槽会大幅压缩充放电空间

令B=E_T−E_0+G为电池必须补足的能量，H为电网侧充放电总吞吐上限。能量平衡给出B=η_c C−D/η_d。若最多有N个已接线时段、每槽充放电上限均为P，则

\[
C+D\le H_{\rm eff}:=\min(H,\Delta PN),\qquad
D\le\frac{\eta_d(\eta_c H_{\rm eff}-B)}{1+\eta_c\eta_d}.
\]

第二个不等式由C≤H_eff−D代入能量平衡得到。若η_c H_eff<B，连纯充电也无法完成服务。上述约束还没考虑每槽只能充或放；若其中k槽用于充电，则进一步有

\[
D\le \min\!\left\{D_H,\ \max_{k=0,\ldots,N}
\min\big((N-k)\Delta P,\ \eta_d(\eta_c k\Delta P-B)\big)\right\},
\]

其中D_H表示前式右端；只保留右端非负的k。这里有限个k用于解析容量核查，未进入路线选择器。SOC边界、接入窗口和到达服务仍可使实际容量更小。

代入冻结数值η_c=η_d=0.95、P=6/1.05 kW、Δ=0.25小时、E_T−E_0=2.85 kWh、H=7.5 kWh：

|操作情形|至多已接线槽N|驾驶耗电G/kWh|放电量必要上界D/kWh|
|---|---:|---:|---:|
|旧T=6固定点|6|0|2.13469|
|旧T=6一次移点，驾驶/接线各1槽|4|0.2|0.97036|
|T=8一次移点|6|0.2|2.03482|
|T=12一次移点|10|0.2|2.03482|

这些是能量与槽数推导的上界，未运行MILP，不是原问题最优解。T=6下，两槽损失叠加终端充电任务，使可用于放电的空间下降明显；T=8/12主要受吞吐预算限制，较长窗口增加了择时余量。这给出一个物理解释，不能仅用“梯度差异不够大”解释移动收益不稳定。

## 6. 已定位的条件性实现问题与模型边界

|编号|判断|影响与最小处理|
|---|---|---|
|I1|固定父计划保护并非无条件|scalar_mobile把固定父放在最后；若此前耗尽deadline，父计划会被跳过。`inheritance_protected`只相对已评分初值，失败回退通常是square_mobile。先保留/验证同family固定父，再处理其他初值，超时也返回该父曲线并记录未完成。该分支存在不等于已证明它造成了本批损失|
|I2|不可达控制仍进入表格预计算|新固定域access全True、mobile=False，流量使远端功率为0，但控制变量箱仍给±P；标量按箱为这些坐标建表，移动域早期不可达地点亦同。先用同一状态图的前向/后向可达性将这些控制上界收紧为0，可安全减少QP和分段变量。节省量尚未运行测量|
|I3|执行表述只锁定净功率|选择器返回u，driver重新用零目标MILP找可行操作x。相同u可能对应不同零功率期间的驾驶时刻。AC注入一致，完整人员/路线时间表却未强制沿用规划x。扩展人员协同时应返回并执行完整x，保存计划与执行操作哈希|
|M1|驾驶人员窗口尚未表达|工作人员窗口只约束setup，formal又全部可用；增加显式driver_available并删除覆盖不可用驾驶时段的弧，无需枚举路线|
|M2|终点及多次服务简化|终点任意、max1move、人员30分钟；返程要求应明确设置terminal_site/connected并核算资源。只把max_moves改为2，仍受30分钟预算限制；两次远端服务通常需60分钟|
|M3|到达后0.25 kWh是声明的服务下限|它排除了只驾驶而无目的地激励的计划，也可能排除低能量高敏感度探测；应按真实服务需求解释，不能当作辨识定理|
|M4|接入窗口语义有限|connected弧可跨越access=False时段，功率被强制为0，恢复access后无需再次接线。当前表示“允许送电”，若窗口关闭代表必须拔线/驶离，需要另设状态约束|

I1依据：[select:582](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_v2_design.py:582)、[scalar:298](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_systematic_design.py:298)、[scalar:355](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_systematic_design.py:355)、[select:633](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_v2_design.py:633)。B保护版已将固定父排在首位：[B:425](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_v2_design.py:425)。

已完成[52条实际移动记录的独立父曲线核查](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/outputs/mobile_v3_parent_initial_audit.json)：N3为18/18完整评分（15条直接fixed_parent、3条其他初值同曲线），N4为34/34（22条直接、12条其他初值同曲线）。按冻结选择器的10位小数重复规则匹配后再检查原始功率，全部匹配差值恰为0.0 kW。deadline未评分、仅失败及未知均为0。**因此I1是代码中的条件性预算防护问题，本批移动退步的解释应转向指标/预测与最终联合拟合排序的差异。**

I2依据：cases:192、domain:262、tables:83与tables:119；I3依据：[study:149](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_v2_study.py:149)、[realize:500](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_fixed_train_design.py:500)。M1–M4分别对应第2节已链接的窗口、终点、到达吞吐和connected弧。

## 7. 建议顺序与验收

软件整理可处理I1、I2、I3，不改变物理服务或辨识目标：父计划在任意提前停止点仍保留；不可达表格删除前后可执行控制集合相同；选中完整操作与执行操作一致。I1、I3尚未实施；I2已新增独立模块，但未接入冻结策略。本批52条移动都已评分固定父计划，修I1不会解释现有预测排序反转；I2解决无效计算，是否改善限时求解需后续计时验收。

新增[ev_mobile_v3_domain.py:16](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_v3_domain.py:16)在同一状态图上计算前后向最小人员成本，额外按移动次数分层。连接弧只有在某条符合初终状态、移动上限和人员预算的完整路径上，才标为可达；数值成本容忍明确保存。随后[tighten_operation_bounds:109](D:/0-github_workspace/Topo/outputs/ev_rx_stage_20261015/research_experiments/mobile_ev_mle/ev_mobile_v3_domain.py:109)只把不可达坐标的u、充电、放电上下界置0。证明直接来自路径与功率链接：不可达连接弧在每个原可行整数解中均为0，其功率也必为0，故新增界不改变可行集合。SOC、终端能量、吞吐及到达服务约束原样保留；图上可达并不等于物理服务可行。

验收为24项通过，包含30个随机小图与独立完整路径遍历的比较、零时接线、终点回程、工作人员成本边界、原check/decode兼容、原模型数组与约束不变。测试没有运行MIP或AC；完整路径遍历仅用于很小的独立审计。尚未测量预计算或MILP耗时收益。

同一默认服务配置的纯图核查中，固定点T=6/8/12分别有12/18、16/24、36/48个控制坐标可直接置0；移动域分别为4/18、4/24、6/48个，主要是远端前两槽尚未完成驾驶与接线。该比例表示可删除的功率坐标，不能直接换成总运行时间节省比例。

然后只加一个有物理依据的维度：驾驶可用窗口，并从真实出行/接线需求给定时间和终点；若确有两处接续服务，再使用现有网络的max_moves=2并匹配所有对照的人员、时间与终端任务预算。若进一步允许多次重访，同一目的地的“到达后累计吞吐”可被后一次访问重复记作前次服务，需要按每次访问段核算。

对一次移动，建议增加一个**同预算的起始移点对照**：MILP仍联合选目标地点和功率，但若移动只允许在释放时刻出发；与允许延后移点比较，区分初次选址价值和“先在site0激励、再赶上远端窗口”的时间价值。固定site0、同域平方、同曲线空间反事实继续保留。下一批验收应预声明可达的梯度排序变化、完整AC评分、物理失败和校准误拒，而不预设移动必须占优。
