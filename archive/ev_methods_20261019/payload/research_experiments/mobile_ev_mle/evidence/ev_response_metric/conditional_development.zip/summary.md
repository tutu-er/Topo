# 已固定动作的条件未来积分诊断

4份独立开发历史，每份32条条件未来；真实训练末底层状态仅用于离线机制分析。
固定原验证损失和训练R/X，所有动作共享每条未来路径；未来计量噪声去除。

## 994101

去重动作 5，拟合失败 0/160。

|策略|原单路径clean M|条件M均值|积分标准误|完整路径|
|---|---:|---:|---:|---:|
|square|150.999|166.589|1.86234|32/32|
|nearest|164.56|168.81|2.44196|32/32|
|gradac|152.876|167.543|1.15923|32/32|
|contrast_joint|153.735|166.316|1.42536|32/32|
|contrast_box|162.68|168.758|2.29961|32/32|
|contrast_load|150.999|166.589|1.86234|32/32|

|动作对(左减右)|原clean差|条件差均值|积分标准误|D排序：单路径/均值|
|---|---:|---:|---:|---|
|nearest − square,contrast_load|13.5615|2.22178|3.13477|True/True|
|gradac − square,contrast_load|1.87758|0.954713|2.09593|True/True|
|gradac − nearest|-11.6839|-1.26706|1.64893|True/True|
|contrast_joint − square,contrast_load|2.73649|-0.273045|1.06671|True/False|
|contrast_joint − nearest|-10.825|-2.49482|2.96566|True/True|
|contrast_joint − gradac|0.858908|-1.22776|1.61824|False/True|
|contrast_box − square,contrast_load|11.6815|2.16943|3.02919|True/True|
|contrast_box − nearest|-1.87999|-0.0523448|0.237295|True/True|
|contrast_box − gradac|9.80392|1.21472|1.48728|True/True|
|contrast_box − contrast_joint|8.94501|2.44248|2.85363|True/True|

## 994102

去重动作 5，拟合失败 0/160。

|策略|原单路径clean M|条件M均值|积分标准误|完整路径|
|---|---:|---:|---:|---:|
|square|672.402|646.582|6.78104|32/32|
|nearest|687.272|650.16|8.54808|32/32|
|gradac|666.783|644.493|6.03177|32/32|
|contrast_joint|687.394|650.613|8.7149|32/32|
|contrast_box|691.62|649.224|8.129|32/32|
|contrast_load|672.402|646.582|6.78104|32/32|

|动作对(左减右)|原clean差|条件差均值|积分标准误|D排序：单路径/均值|
|---|---:|---:|---:|---|
|nearest − square,contrast_load|14.8708|3.57777|7.90636|True/True|
|gradac − square,contrast_load|-5.61907|-2.08914|6.01374|False/False|
|gradac − nearest|-20.4899|-5.6669|4.31404|True/True|
|contrast_joint − square,contrast_load|14.9926|4.03072|8.26634|True/True|
|contrast_joint − nearest|0.121722|0.452953|0.544613|True/True|
|contrast_joint − gradac|20.6116|6.11986|4.44988|True/True|
|contrast_box − square,contrast_load|19.2188|2.64135|7.89927|True/True|
|contrast_box − nearest|4.34799|-0.936419|0.959272|False/True|
|contrast_box − gradac|24.8379|4.73049|3.7916|True/True|
|contrast_box − contrast_joint|4.22626|-1.38937|1.01716|False/True|

## 994103

去重动作 5，拟合失败 0/160。

|策略|原单路径clean M|条件M均值|积分标准误|完整路径|
|---|---:|---:|---:|---:|
|square|-0.446206|-2.95198|0.812475|32/32|
|nearest|-6.37035|1.39325|0.760628|32/32|
|gradac|-7.92619|-0.0713389|0.557336|32/32|
|contrast_joint|-6.98897|1.64644|0.770666|32/32|
|contrast_box|-7.15337|1.23982|0.734346|32/32|
|contrast_load|-7.15337|1.23982|0.734346|32/32|

|动作对(左减右)|原clean差|条件差均值|积分标准误|D排序：单路径/均值|
|---|---:|---:|---:|---|
|nearest − square|-5.92414|4.34523|1.01405|False/True|
|gradac − square|-7.47998|2.88064|0.76628|False/True|
|gradac − nearest|-1.55583|-1.46459|0.486298|True/True|
|contrast_joint − square|-6.54276|4.59842|1.04588|False/True|
|contrast_joint − nearest|-0.618617|0.253194|0.0594668|False/True|
|contrast_joint − gradac|0.937216|1.71778|0.486006|True/True|
|contrast_box,contrast_load − square|-6.70717|4.1918|1.01343|False/True|
|contrast_box,contrast_load − nearest|-0.783022|-0.153431|0.0872238|True/True|
|contrast_box,contrast_load − gradac|0.772812|1.31116|0.440164|True/True|
|contrast_box,contrast_load − contrast_joint|-0.164405|-0.406626|0.0817363|True/True|

## 994104

去重动作 2，拟合失败 0/64。

|策略|原单路径clean M|条件M均值|积分标准误|完整路径|
|---|---:|---:|---:|---:|
|square|793.497|742.821|7.4397|32/32|
|nearest|793.497|742.821|7.4397|32/32|
|gradac|793.497|742.821|7.4397|32/32|
|contrast_joint|749.523|714.16|4.50787|32/32|
|contrast_box|793.497|742.821|7.4397|32/32|
|contrast_load|793.497|742.821|7.4397|32/32|

|动作对(左减右)|原clean差|条件差均值|积分标准误|D排序：单路径/均值|
|---|---:|---:|---:|---|
|contrast_joint − square,nearest,gradac,contrast_box,contrast_load|-43.9738|-28.6605|7.53376|True/True|

32路径是数值积分，不增加独立历史样本量。条件包含真实底层状态，
与部署时仅按带误差计量进行预测不同。结果不进入当前策略、正式校准或独立评价。
