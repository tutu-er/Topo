# Evidence restore and statistical replay

This archive preserves the frozen source snapshot, postprocessing, exact used
input windows and statistics. All large original raw records remain in the
execution directory. raw_sha256.json lists every original byte SHA and size.
Compact files support statistical replay and do not replace those originals.
Four preregistered development cluster-0 files (n6/n8 x none/DER) are retained
without alteration for independent physical AC audit. Other full raw records
were audited locally; audit.json records that completed numerical audit.

Commands (Python environment versions are in provenance/environment.json):

    python package_evidence.py verify EVIDENCE.zip
    python package_evidence.py restore EVIDENCE.zip NEW_EMPTY_DIRECTORY
    python NEW_EMPTY_DIRECTORY/postprocessing/package_evidence.py replay NEW_EMPTY_DIRECTORY --source-root NEW_EMPTY_DIRECTORY/source

Restore verifies all byte hashes, extracts source_snapshot.zip into source/,
and installs the saved postprocessing analysis.py at its original module path.
Replay regenerates calibration thresholds from calibration compact files,
then all phase tables, date-cluster bootstrap intervals, paired tests, R/X,
forecast error, cost and score-ranking summaries. It does not refit, plan,
simulate or call AC. Future truth inside evidence is labelled evaluation only.

For physical audit, load the four raw_fixtures/development files and call the
saved full_pipeline.analysis.audit_record with a g_precision.analysis.Audit.
This performs forward AC replay only. Dense optimization states and observed
meters omitted from other compact files cannot be reconstructed from compact
statistics. Obtain their original files from the local execution directory
and verify raw_sha256.json before any additional physical replay.

The original 60MB OPSD CSV is not duplicated. inputs/prepared.json.gz contains
the exact selected raw windows; official README/datapackage and data inventory
retain attribution, source/version and the original CSV checksum.
