# Complete-tree clade F1 supplement

F1 compares all nontrivial rooted clades of the unique minimum-SSE tree with the true full reduced tree. Root and leaf supports are implicit. A missing true candidate can still receive a partial structural score. Failed routes, numerical ties and unknown truth receive no invented F1.

F1 evaluates the point argmin even when the calibrated retained set contains several candidates. It is a structural score, not a topology probability or a retained-set coverage measure.

Evaluation postJNT (full condition denominator retained):

|Method|Point correct / total|True tree absent|Fit/route failures|F1 scored / total|Mean F1|Date-cluster 95% interval|
|---|---:|---:|---:|---:|---:|---:|
|OBS|43/64|15|5|59/64|0.8858|0.7877–0.9771|
|CC|43/64|16|5|59/64|0.8922|0.7992–0.9796|
|HL|44/64|13|6|58/64|0.9085|0.8249–0.9840|
|RAND|45/64|16|3|61/64|0.9009|0.8159–0.9787|
|P-SQ/F±|39/64|14|9|55/64|0.8777|0.7709–0.9799|
|G-SQ/F±|43/64|13|6|58/64|0.8975|0.8124–0.9815|
|G-AQ/F±|43/64|15|5|59/64|0.8925|0.8021–0.9771|
|P-SQ|42/64|15|7|57/64|0.8778|0.7539–0.9833|
|G-SQ|48/64|15|1|63/64|0.9041|0.8204–0.9821|
|G-AQ|41/64|15|7|57/64|0.8924|0.8053–0.9776|

All phases, routes and n/source strata, full missing denominators, and paired same-domain P-SQ→G differences are saved in clade_metrics.json. Bootstrap resamples complete calendar-date clusters. Intervals describe the scored cases; all-condition bounds also show what the missing scores could change. Chronological windows and repeated buildings do not by themselves guarantee exchangeability.

Forward AC, fitting and planning calls: 0. Main frozen policy, thresholds and primary statistics were unchanged. Consistency issues: 0.
