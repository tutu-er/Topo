"""S1 read-only review: open development records only; never fit or plan."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip
from hashlib import sha256
import json
from pathlib import Path
import sys

STAGE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(STAGE))
from research_experiments.mobile_ev_mle.full_pipeline import analysis


def mean(values):
    values = [float(v) for v in values if isinstance(v, (int, float))]
    return sum(values) / len(values) if values else None


def distribution(values):
    values = [float(v) for v in values if isinstance(v, (int, float))]
    return dict(n=len(values), mean=mean(values), min=min(values) if values else None,
                max=max(values) if values else None)


def decision_summary(rows):
    return dict(n_conditions=len(rows), n_date_clusters=len({r["cluster"] for r in rows}),
        truth_present=sum(r["decision"]["truth_present"] for r in rows),
        truth_present_date_clusters=len({r["cluster"] for r in rows if r["decision"]["truth_present"]}),
        candidate_miss=sum(not r["decision"]["truth_present"] for r in rows),
        candidate_miss_date_clusters=len({r["cluster"] for r in rows if not r["decision"]["truth_present"]}),
        available=sum(r["decision"]["available"] for r in rows),
        point_correct=sum(r["decision"]["point_error"] is False for r in rows),
        point_wrong=sum(r["decision"]["point_error"] is True for r in rows),
        wrong_with_true_present=sum(r["decision"]["point_error"] is True and r["decision"]["truth_present"] for r in rows),
        wrong_with_true_absent=sum(r["decision"]["point_error"] is True and not r["decision"]["truth_present"] for r in rows),
        no_unique_point_label=sum(r["decision"]["predicted"] is None for r in rows),
        numerical_ties=sum(r["decision"]["numerical_tie"] for r in rows),
        unresolved_at_zero_threshold=sum(r["decision"]["unresolved"] for r in rows),
        fit_failure=sum(r["decision"]["fit_failure"] for r in rows),
        fit_failure_date_clusters=len({r["cluster"] for r in rows if r["decision"]["fit_failure"]}),
        physical_failure=sum(r["decision"]["physical_failure"] for r in rows),
        optimization_failure=sum(r["decision"]["optimization_failure"] for r in rows),
        candidate_count=distribution(r["decision"]["candidate_count"] for r in rows),
        conditional_true_margin_half_SSE=distribution(r["decision"]["true_margin_half_SSE"] for r in rows))


def forecast_summary(details):
    forecasts = [d["forecast"] for d in details]
    sources = [d["true_candidate_source_error"] for d in details if d["true_candidate_source_error"]]
    all_sources = [v for d in details for v in d["forecast"].get("source", {}).values()]
    return dict(n_conditions=len(details), n_date_clusters=len({d["spec"]["cluster_index"] for d in details}),
        forecast_available=sum(f.get("available", False) for f in forecasts),
        forecast_missing=sum(not f.get("available", False) for f in forecasts),
        P_RMSE_kW=distribution(f.get("load", {}).get("p", {}).get("rmse_kw") for f in forecasts),
        Q_RMSE_kvar=distribution(f.get("load", {}).get("q", {}).get("rmse_kw") for f in forecasts),
        true_topology_source_P_RMSE_kW=distribution(v.get("source_p", {}).get("rmse_kw") for v in sources),
        true_topology_source_Q_RMSE_kvar=distribution(v.get("source_q", {}).get("rmse_kw") for v in sources),
        true_topology_source_available_date_clusters=len({d["spec"]["cluster_index"] for d in details if d["true_candidate_source_error"]}),
        all_candidate_source_P_RMSE_kW=distribution(v.get("source_p", {}).get("rmse_kw") for v in all_sources),
        all_candidate_source_Q_RMSE_kvar=distribution(v.get("source_q", {}).get("rmse_kw") for v in all_sources),
        source_scope="true-topology errors conditional on candidate inclusion; all-candidate errors are diagnostic and include deliberately compensating wrong models")


def main():
    output = STAGE / "outputs/full_pipeline_v1"
    paths = sorted((output / "development").glob("*.json.gz"))
    details, rows = [], []
    expected = 24
    for path in paths:
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            record = json.load(stream)
        spec, config = record["spec"], record["config"]
        if spec["phase"] != "development":
            raise ValueError("review is authorized to read development records only")
        expected = config["development_clusters"] * len(config["terminal_counts"]) * len(config["source_modes"])
        history_view = analysis.route_view(record, "OBS", "history")
        history_decision = analysis.decide(history_view, 0.)
        forecast = analysis.forecast_errors(record)
        true_name = history_view.get("true_name")
        detail = dict(spec=spec, raw_path=str(path), raw_sha256=sha256(path.read_bytes()).hexdigest(),
            raw_bytes=path.stat().st_size, status=record.get("status"),
            source_unchanged=record.get("source_unchanged"), freeze_identity=record.get("freeze_identity"),
            failures=record.get("failures", {}), planning_failures=record.get("planning", {}).get("failures", {}),
            provenance_start_utc=record.get("provenance", {}).get("raw", {}).get("start_utc"),
            provenance_end_utc=record.get("provenance", {}).get("raw", {}).get("end_utc"),
            history=history_decision, history_RX=analysis.rx_error(record, history_view),
            forecast=forecast, true_candidate_source_error=forecast.get("source", {}).get(true_name),
            seconds=record.get("seconds"), costs=record.get("planning", {}).get("cost", {}),
            methods={})
        rows.append(dict(cluster=spec["cluster_index"], n=spec["n"], source_mode=spec["source_mode"],
                         method="HISTORY", route="history", decision=history_decision))
        for method in analysis.METHODS:
            detail["methods"][method] = {}
            for route in ("preFIX", "preJNT", "postJNT"):
                view = analysis.route_view(record, method, route)
                decision = analysis.decide(view, 0.)
                detail["methods"][method][route] = decision
                rows.append(dict(cluster=spec["cluster_index"], n=spec["n"], source_mode=spec["source_mode"],
                                 method=method, route=route, decision=decision))
        details.append(detail)
    tables = {}
    strata = [("all", None, None)] + [(f"n{n}_{mode}", n, mode) for n in (6, 8) for mode in ("none", "DER")]
    for label, n, mode in strata:
        subset = [r for r in rows if n is None or (r["n"] == n and r["source_mode"] == mode)]
        selected_details = [d for d in details if n is None or (d["spec"]["n"] == n and d["spec"]["source_mode"] == mode)]
        table = {"HISTORY": {"history": decision_summary([r for r in subset if r["method"] == "HISTORY"])}}
        for method in analysis.METHODS:
            table[method] = {route: decision_summary([r for r in subset if r["method"] == method and r["route"] == route])
                             for route in ("preFIX", "preJNT", "postJNT")}
        rx = [d["history_RX"] for d in selected_details]
        tables[label] = dict(decisions=table, forecast=forecast_summary(selected_details),
            history_RX=dict(n_conditions=len(rx), available=sum(r.get("available", False) for r in rx),
                n_date_clusters=len({d["spec"]["cluster_index"] for d in selected_details}),
                available_date_clusters=len({d["spec"]["cluster_index"] for d in selected_details if d["history_RX"].get("available", False)}),
                successful_true_fit=sum(r.get("available", False) and r.get("fit_success", False) for r in rx),
                R_mean_absolute_relative=distribution(r.get("r", {}).get("mean_absolute_relative") for r in rx),
                X_mean_absolute_relative=distribution(r.get("x", {}).get("mean_absolute_relative") for r in rx),
                scope="conditional on true topology present and a saved state; not recovery error on missing candidates"),
            costs={key: distribution(d["costs"].get(key) for d in selected_details)
                   for key in sorted({k for d in selected_details for k in d["costs"]})})
    result = dict(scope="S1 frozen method/cost development acceptance only; no policy/threshold tuning from these results",
        generated_utc=datetime.now(timezone.utc).isoformat(), source_phase="development_only",
        threshold=0., threshold_meaning="point-SSE ranking diagnostic, not calibrated confidence",
        expected_condition_records=expected, saved_condition_records=len(details),
        complete=len(details) == expected, expected_date_clusters=6,
        saved_date_clusters=len({d["spec"]["cluster_index"] for d in details}),
        status_counts=dict(Counter(d["status"] for d in details)),
        source_unchanged_all=all(d["source_unchanged"] is True for d in details),
        freeze_identities=sorted({d["freeze_identity"] for d in details}),
        cal_or_eval_records_read=0, fitting_calls=0, planning_calls=0, forward_AC_calls=0,
        tables=tables, details=details)
    target = STAGE / "outputs/full_pipeline_tools/development_review.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(target)
    print(json.dumps(dict(saved=len(details), expected=expected, dates=result["saved_date_clusters"], complete=result["complete"])))
    for label, values in tables.items():
        print(label, "HISTORY", values["decisions"]["HISTORY"]["history"])
        print(label, "FORECAST", values["forecast"])
        print(label, "RX", values["history_RX"])
        for method in analysis.METHODS:
            print(label, method, {route: {key: row[key] for key in
                ("truth_present", "point_correct", "point_wrong", "fit_failure", "physical_failure", "candidate_miss")}
                for route, row in values["decisions"][method].items()})


if __name__ == "__main__":
    main()
