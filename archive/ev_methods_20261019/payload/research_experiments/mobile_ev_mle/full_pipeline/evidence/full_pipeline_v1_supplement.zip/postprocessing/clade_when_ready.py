"""Run the predefined structural-score supplement after the primary audit."""
from datetime import datetime,timezone
from pathlib import Path
import json,os,sys,time,traceback
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
for name in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):
    os.environ[name]='1'
from research_experiments.mobile_ev_mle.full_pipeline import io
import final_clade_metrics
OUT=ROOT/'outputs/full_pipeline_v1'
def save(status,**kw):
    io.write(OUT/'clade_postprocess_controller.json',dict(status=status,pid=os.getpid(),
        updated_utc=datetime.now(timezone.utc).isoformat(),**kw))
if __name__=='__main__':
    try:
        save('waiting_for_primary_audit')
        for _ in range(720):
            if (OUT/'audit.json').exists() and (OUT/'summary.json').exists():break
            time.sleep(30)
        else:raise TimeoutError('six-hour supplement limit')
        if not io.read(OUT/'audit.json')['passed']:raise RuntimeError('primary audit has retained issues')
        save('running_structural_metrics')
        result=final_clade_metrics.finish(OUT)
        save('complete',conditions=len(result['condition_inventory']),
            consistency_issues=len(result['consistency_issues']),tool_sha256=io.digest(Path(final_clade_metrics.__file__)))
    except Exception as exc:
        save('blocked',exception=repr(exc),traceback=traceback.format_exc());raise
