"""Finish only this frozen batch; no fitting, planning or policy changes."""
from datetime import datetime,timezone
from pathlib import Path
import os,sys,time,traceback

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(1,str(ROOT/'rnj_wzzt_core'))
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
from research_experiments.mobile_ev_mle.full_pipeline import analysis,io
import package_evidence

OUT=ROOT/'outputs/full_pipeline_v1'
RECEIPT=OUT/'postprocess_controller.json'
EXPECTED='eae436295601f57f758d4dcc304152b1ca24c12ca9d3c40110fcc24c1b513fe5'

def save(status,**values):
    row=dict(status=status,pid=os.getpid(),updated_utc=datetime.now(timezone.utc).isoformat(),
        output=str(OUT),expected_policy_identity=EXPECTED,**values)
    io.write(RECEIPT,row);print(status,values,flush=True)

def main():
    save('waiting_for_current_frozen_batch')
    previous=None
    for _ in range(720):
        state=io.read(OUT/'controller.json')
        if state.get('freeze_identity')!=EXPECTED:raise RuntimeError('controller policy changed')
        status=state['status']
        if status=='statistical_complete':break
        if status in ('controller_failed','interrupted'):raise RuntimeError('controller stopped: '+status)
        current=(state.get('active_phase'),state.get('counts',{}).get('computed'))
        if current!=previous:print('computed',current,flush=True);previous=current
        time.sleep(30)
    else:raise TimeoutError('six-hour watcher limit; preserve current controller')
    save('full_AC_and_statistical_audit')
    summary,audit=analysis.finish(OUT)
    if not audit['passed']:
        save('audit_issues_retained',issues=len(audit['issues']))
        return 2
    save('packaging_and_independent_statistical_replay',AC_replay=audit['forward_AC_replay_calls'])
    destination=ROOT/'outputs/full_pipeline_delivery_v1'
    packed=package_evidence.package(OUT,destination,source_root=ROOT,max_mib=20.,verify_statistics=True)
    save('complete',package=packed,analysis_sha256=io.digest(Path(analysis.__file__)),
        policy_identity=summary['policy_identity'],audit_passed=True)
    return 0

if __name__=='__main__':
    try:sys.exit(main())
    except Exception as exc:
        save('blocked',exception=repr(exc),traceback=traceback.format_exc())
        raise
