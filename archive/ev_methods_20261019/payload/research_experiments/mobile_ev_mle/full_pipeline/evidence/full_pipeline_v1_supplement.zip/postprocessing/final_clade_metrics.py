"""Supplementary full-tree clade F1 from frozen saved point decisions.

Formal evaluation reads are gated on controller statistical_complete and the
existing thresholds/audit/summary artifacts.  Self-tests use fixtures and/or
development records only.  This tool never fits, plans, simulates, or calls AC.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np

STAGE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(STAGE))
from research_experiments.mobile_ev_mle.full_pipeline import analysis

PAIRS = (("P-SQ", "G-SQ"), ("P-SQ", "G-AQ"),
         ("P-SQ/F±", "G-SQ/F±"), ("P-SQ/F±", "G-AQ/F±"))


def read(path):
    path = Path(path)
    with (gzip.open if path.suffix == ".gz" else open)(path, "rt", encoding="utf-8") as stream:
        return json.load(stream)


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2,
        sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def assert_ready(output):
    """This guard executes before any calibration/evaluation raw is opened."""
    output = Path(output)
    controller_path = output / "controller.json"
    if not controller_path.exists():
        raise RuntimeError("controller.json absent; evaluation metrics remain disabled")
    controller = read(controller_path)
    if controller.get("status") != "statistical_complete":
        raise RuntimeError("evaluation metrics wait for controller statistical_complete")
    required = ("thresholds.json", "audit.json", "summary.json", "freeze.json")
    missing = [name for name in required if not (output / name).exists()]
    if missing:
        raise RuntimeError("evaluation metrics wait for existing artifacts: " + ", ".join(missing))
    return controller


def point_row(record, method, route, thresholds=None):
    spec = record["spec"]
    row = dict(phase=spec["phase"], cluster_index=int(spec["cluster_index"]),
        n=int(spec["n"]), source_mode=spec["source_mode"], method=method, route=route,
        record_available=True, predicted=None, point_error=None, point_correct=False,
        truth_known=False, truth_present=False, candidate_miss=None,
        fit_failure=True, physical_failure=False, numerical_tie=False,
        f1=None, precision=None, recall=None, metrics=None, unscored_reason=None)
    try:
        view = analysis.route_view(record, method, route)
        key = analysis.source_blind_key(method, spec["n"], route)
        threshold = (thresholds or {}).get("source_blind_applied", {}).get(key, 0.)
        decision = analysis.decide(view, threshold)
        row.update(predicted=decision["predicted"], point_error=decision["point_error"],
            point_correct=decision["point_error"] is False,
            truth_known=decision["truth_known"], truth_present=decision["truth_present"],
            candidate_miss=not decision["truth_present"] if decision["truth_known"] else None,
            fit_failure=decision["fit_failure"], physical_failure=decision["physical_failure"],
            numerical_tie=decision["numerical_tie"], retained=decision["retained"],
            retained_set_unresolved=decision["unresolved"], failed_candidates=decision["failed_candidates"],
            decision_failure=decision["failure"])
        if not decision["available"]:
            row["unscored_reason"] = "required fit/physical route unavailable"
        elif decision["predicted"] is None:
            row["unscored_reason"] = "no unique argmin (numerical tie)"
        elif not decision["truth_known"]:
            row["unscored_reason"] = "true full tree unavailable"
        else:
            predicted = view["structures"][decision["predicted"]]["supports"]
            truth = record["truth_evaluation_only"]["supports"]
            metrics = analysis.clade_metrics(predicted, truth, spec["n"])
            row.update(metrics=metrics, f1=float(metrics["f1"]),
                       precision=float(metrics["precision"]), recall=float(metrics["recall"]))
            if decision["point_error"] is not None and metrics["exact"] != (not decision["point_error"]):
                row["consistency_issue"] = "clade exact-match disagrees with saved point-label comparison"
    except Exception as exc:
        row["unscored_reason"] = "saved-record parsing/metric exception: " + repr(exc)
    return row


def missing_rows(spec, methods, reason):
    return [dict(**spec, method=method, route=route, record_available=False,
        predicted=None, point_error=None, point_correct=False, truth_known=False,
        truth_present=False, candidate_miss=None, fit_failure=True, physical_failure=False,
        numerical_tie=False, f1=None, precision=None, recall=None, metrics=None,
        unscored_reason=reason) for method in methods for route in analysis.ROUTES]


def clustered_interval(rows, field, *, replicates, seed, confidence=.95):
    """Resample date-cluster sums/counts, keeping all paired conditions intact."""
    keys = sorted({row["cluster_index"] for row in rows})
    sums, counts = [], []
    for key in keys:
        values = [row[field] for row in rows if row["cluster_index"] == key and row.get(field) is not None]
        sums.append(sum(values)); counts.append(len(values))
    total = sum(counts)
    result = dict(estimate=sum(sums) / total if total else None, lower=None, upper=None,
        n_date_clusters=len(keys), n_date_clusters_with_scores=sum(count > 0 for count in counts),
        n_scored_conditions=total, confidence=confidence, requested_replicates=replicates,
        valid_replicates=0, seed=int(seed), unit="calendar date window cluster",
        scope="conditional mean of scored point decisions; percentile cluster bootstrap, no exchangeability/field coverage guarantee")
    if not keys or not total or replicates < 1:
        return result
    rng = np.random.default_rng(seed)
    draws = rng.integers(0, len(keys), size=(replicates, len(keys)))
    denominator = np.asarray(counts)[draws].sum(axis=1)
    numerator = np.asarray(sums)[draws].sum(axis=1)
    values = numerator[denominator > 0] / denominator[denominator > 0]
    tail = (1 - confidence) / 2
    lower, upper = np.quantile(values, [tail, 1 - tail])
    result.update(lower=float(lower), upper=float(upper), valid_replicates=len(values))
    return result


def cell(rows, *, replicates, seed):
    count = len(rows)
    scored = [row for row in rows if row.get("f1") is not None]
    total_f1 = sum(row["f1"] for row in scored)
    return dict(n_all_conditions=count, n_date_clusters=len({r["cluster_index"] for r in rows}),
        n_saved_conditions=sum(r["record_available"] for r in rows),
        point_correct=sum(r["point_error"] is False for r in rows),
        point_wrong=sum(r["point_error"] is True for r in rows),
        no_unique_point_label=sum(r["predicted"] is None for r in rows),
        pool_missing_true_tree=sum(r["candidate_miss"] is True for r in rows),
        pool_coverage_known=sum(r["candidate_miss"] is not None for r in rows),
        fit_failure=sum(r["fit_failure"] for r in rows),
        physical_failure=sum(r["physical_failure"] for r in rows),
        numerical_tie=sum(r["numerical_tie"] for r in rows),
        scored_f1_conditions=len(scored), unscored_f1_conditions=count - len(scored),
        unscored_reasons=dict(Counter(r["unscored_reason"] for r in rows if r["unscored_reason"])),
        mean_f1=total_f1 / len(scored) if scored else None,
        mean_precision=sum(r["precision"] for r in scored) / len(scored) if scored else None,
        mean_recall=sum(r["recall"] for r in scored) / len(scored) if scored else None,
        all_condition_mean_F1_range_without_imputing_failures=[total_f1 / count, (total_f1 + count - len(scored)) / count] if count else [None, None],
        f1_interval=clustered_interval(rows, "f1", replicates=replicates, seed=seed))


def paired(rows, left, right, route, *, replicates, seed):
    def subset(method):
        return {(r["cluster_index"], r["n"], r["source_mode"]): r for r in rows if r["method"] == method and r["route"] == route}
    base, new = subset(left), subset(right)
    pairs = []
    for key in sorted(set(base) | set(new)):
        a, b = base.get(key), new.get(key)
        av = None if a is None else a["f1"]
        bv = None if b is None else b["f1"]
        pairs.append(dict(cluster_index=key[0], n=key[1], source_mode=key[2],
            baseline_f1=av, new_f1=bv, delta=bv - av if av is not None and bv is not None else None,
            baseline_scored=av is not None, new_scored=bv is not None))
    available = [p for p in pairs if p["delta"] is not None]
    sum_delta = sum(p["delta"] for p in available)
    N, missing = len(pairs), len(pairs) - len(available)
    return dict(baseline=left, new=right, route=route, n_all_condition_pairs=N,
        n_date_clusters=len({p["cluster_index"] for p in pairs}), n_jointly_scored_pairs=len(available),
        baseline_only_scored=sum(p["baseline_scored"] and not p["new_scored"] for p in pairs),
        new_only_scored=sum(p["new_scored"] and not p["baseline_scored"] for p in pairs),
        neither_scored=sum(not p["baseline_scored"] and not p["new_scored"] for p in pairs),
        new_higher=sum(p["delta"] > 1e-12 for p in available),
        new_lower=sum(p["delta"] < -1e-12 for p in available),
        ties=sum(abs(p["delta"]) <= 1e-12 for p in available),
        mean_delta_jointly_scored=sum_delta / len(available) if available else None,
        all_pair_mean_delta_range_without_imputing_missing=[(sum_delta - missing) / N, (sum_delta + missing) / N] if N else [None, None],
        paired_date_cluster_interval=clustered_interval(pairs, "delta", replicates=replicates, seed=seed),
        pairs=pairs)


def phase_summary(rows, methods, *, replicates, seed):
    groups = [("all", None, None)] + [(f"n{n}_{source}", n, source) for n in sorted({r["n"] for r in rows})
                                    for source in sorted({r["source_mode"] for r in rows})]
    result = {}
    for label, n, source in groups:
        selected = [r for r in rows if n is None or (r["n"] == n and r["source_mode"] == source)]
        result[label] = dict(cells={method: {route: cell([r for r in selected if r["method"] == method and r["route"] == route],
            replicates=replicates, seed=seed) for route in analysis.ROUTES} for method in methods},
            paired_F1_differences={f"{a}__to__{b}": {route: paired(selected, a, b, route,
                replicates=replicates, seed=seed) for route in analysis.ROUTES}
                for a, b in PAIRS if a in methods and b in methods})
    return result


def report(result):
    methods = result["methods"]
    lines = ["# Complete-tree clade F1 supplement", "",
        "F1 compares all nontrivial rooted clades of the unique minimum-SSE tree with the true full reduced tree. "
        "Root and leaf supports are implicit. A missing true candidate can still receive a partial structural score. "
        "Failed routes, numerical ties and unknown truth receive no invented F1.", "",
        "F1 evaluates the point argmin even when the calibrated retained set contains several candidates. "
        "It is a structural score, not a topology probability or a retained-set coverage measure.", "",
        "Evaluation postJNT (full condition denominator retained):", "",
        "|Method|Point correct / total|True tree absent|Fit/route failures|F1 scored / total|Mean F1|Date-cluster 95% interval|",
        "|---|---:|---:|---:|---:|---:|---:|"]
    def fmt(value):
        return "unavailable" if value is None else f"{value:.4f}"
    evaluation = result["phases"]["evaluation"]["all"]["cells"]
    for method in methods:
        row = evaluation[method]["postJNT"]; ci = row["f1_interval"]; N = row["n_all_conditions"]
        lines.append(f"|{method}|{row['point_correct']}/{N}|{row['pool_missing_true_tree']}|{row['fit_failure']}|"
            f"{row['scored_f1_conditions']}/{N}|{fmt(row['mean_f1'])}|{fmt(ci['lower'])}–{fmt(ci['upper'])}|")
    lines.extend(["", "All phases, routes and n/source strata, full missing denominators, and paired same-domain P-SQ→G differences "
        "are saved in clade_metrics.json. Bootstrap resamples complete calendar-date clusters. "
        "Intervals describe the scored cases; all-condition bounds also show what the missing scores could change. "
        "Chronological windows and repeated buildings do not by themselves guarantee exchangeability.", "",
        f"Forward AC, fitting and planning calls: 0. Main frozen policy, thresholds and primary statistics were unchanged. "
        f"Consistency issues: {len(result['consistency_issues'])}.", ""])
    return "\n".join(lines)


def finish(output):
    output = Path(output).resolve()
    assert_ready(output)  # Required before even globbing evaluation raw files.
    frozen, thresholds = read(output / "freeze.json"), read(output / "thresholds.json")
    config = frozen["config"]
    methods = tuple(config.get("methods", analysis.METHODS))
    replicates, seed = int(config.get("statistical_bootstrap", 2000)), int(config.get("statistical_seed", 20409999))
    phases, inventories, all_rows = {}, [], []
    for phase in ("development", "calibration", "evaluation"):
        rows = []
        for index in range(int(config[phase + "_clusters"])):
            for n in config["terminal_counts"]:
                for source in config["source_modes"]:
                    spec = dict(phase=phase, cluster_index=index, n=n, source_mode=source)
                    path = output / phase / f"history_{index:03d}_n{n}_{source}.json.gz"
                    item = dict(**spec, path=str(path), exists=path.exists())
                    try:
                        record = read(path)
                        if any(record["spec"][key] != value for key, value in spec.items()):
                            raise ValueError("saved phase/condition differs from expected frozen slot")
                        item.update(raw_sha256=digest(path), raw_bytes=path.stat().st_size,
                                    status=record.get("status"))
                        for method in methods:
                            rows.extend(point_row(record, method, route, thresholds) for route in analysis.ROUTES)
                    except Exception as exc:
                        item["read_failure"] = repr(exc)
                        rows.extend(missing_rows(spec, methods, repr(exc)))
                    inventories.append(item)
        phases[phase] = phase_summary(rows, methods, replicates=replicates, seed=seed)
        all_rows.extend(rows)
    result = dict(schema="full_pipeline_full_tree_clade_F1_v1", generated_utc=datetime.now(timezone.utc).isoformat(),
        methods=list(methods), routes=list(analysis.ROUTES), phases=phases, point_rows=all_rows,
        condition_inventory=inventories,
        consistency_issues=[r for r in all_rows if r.get("consistency_issue")],
        source=dict(controller_sha256=digest(output / "controller.json"),
            thresholds_sha256=digest(output / "thresholds.json"), audit_sha256=digest(output / "audit.json"),
            primary_summary_sha256=digest(output / "summary.json"), freeze_sha256=digest(output / "freeze.json"),
            analysis_sha256=digest(Path(analysis.__file__)), tool_sha256=digest(__file__)),
        bootstrap_replicates=replicates, bootstrap_seed=seed,
        fitting_calls=0, planning_calls=0, forward_AC_calls=0, primary_policy_changed=False,
        scope="supplementary point-tree structural comparison; all failures and unknown-score denominators retained")
    write(output / "clade_metrics.json", result)
    (output / "clade_results.md").write_text(report(result), encoding="utf-8")
    return result


def fixture_self_test():
    record = dict(spec=dict(phase="development", cluster_index=0, n=6, source_mode="none"),
        candidate_structures=[dict(name="partial", n=6, supports=[[0, 1]])],
        truth_evaluation_only=dict(supports=[[0, 1], [0, 1, 2]]),
        planning=dict(history=dict(candidates={"partial": dict(success=True, usable=True, loss=1.)})))
    row = point_row(record, "OBS", "history")
    assert row["candidate_miss"] and row["point_error"]
    assert abs(row["f1"] - 2 / 3) < 1e-12 and row["precision"] == 1. and row["recall"] == .5
    failed = json.loads(json.dumps(record)); failed["planning"]["history"]["candidates"]["partial"]["success"] = False
    assert point_row(failed, "OBS", "history")["f1"] is None
    unknown = json.loads(json.dumps(record)); unknown.pop("truth_evaluation_only")
    assert point_row(unknown, "OBS", "history")["f1"] is None
    tied = json.loads(json.dumps(record))
    tied["candidate_structures"].append(dict(name="second", n=6, supports=[[2, 3]]))
    tied["planning"]["history"]["candidates"]["second"] = dict(success=True, usable=True, loss=1.)
    assert point_row(tied, "OBS", "history")["f1"] is None
    bootstrap = clustered_interval([dict(cluster_index=0, f1=1.), dict(cluster_index=1, f1=.5)],
        "f1", replicates=100, seed=1)
    assert bootstrap["estimate"] == .75 and bootstrap["valid_replicates"] == 100
    a, b = dict(row, method="P-SQ"), dict(row, method="G-SQ", f1=1.)
    pair = paired([a, b], "P-SQ", "G-SQ", "history", replicates=100, seed=1)
    assert abs(pair["mean_delta_jointly_scored"] - 1 / 3) < 1e-12
    print(json.dumps(dict(fixture_self_test="passed", fitting_calls=0, planning_calls=0, forward_AC_calls=0)))


def development_self_test(output):
    # Deliberately no final-readiness requirement: this mode never opens other phases.
    paths = sorted((Path(output) / "development").glob("*.json.gz"))
    rows = []
    for path in paths:
        record = read(path)
        if record["spec"]["phase"] != "development":
            raise ValueError("development self-test cannot open calibration/evaluation records")
        rows.extend(point_row(record, method, route) for method in analysis.METHODS for route in analysis.ROUTES)
    assert not any(row.get("consistency_issue") for row in rows)
    print(json.dumps(dict(development_records=len(paths), point_rows=len(rows),
        scored_F1_rows=sum(row["f1"] is not None for row in rows),
        partial_F1_with_true_tree_absent=sum(row["candidate_miss"] is True and row["f1"] is not None for row in rows),
        consistency_issues=0, calibration_records_read=0, evaluation_records_read=0,
        fitting_calls=0, planning_calls=0, forward_AC_calls=0)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=STAGE / "outputs/full_pipeline_v1")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--development-self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        fixture_self_test()
    elif args.development_self_test:
        development_self_test(args.output)
    else:
        result = finish(args.output)
        print(json.dumps(dict(phase_count=len(result["phases"]), conditions=len(result["condition_inventory"]),
            point_rows=len(result["point_rows"]), consistency_issues=len(result["consistency_issues"]))))


if __name__ == "__main__":
    main()
