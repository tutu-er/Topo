"""Fast frozen evaluation readback; no bootstrap, fitting, planning or AC."""
from collections import Counter
import gzip
import json
from pathlib import Path
import sys

STAGE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(STAGE))
from research_experiments.mobile_ev_mle.full_pipeline import analysis


def read(path):
    with (gzip.open if str(path).endswith(".gz") else open)(path, "rt", encoding="utf-8") as stream:
        return json.load(stream)


def distribution(values):
    values = [float(v) for v in values if isinstance(v, (int, float))]
    return dict(n=len(values), mean=sum(values) / len(values) if values else None,
        min=min(values) if values else None, max=max(values) if values else None)


def sign(value):
    return None if value is None else 1 if value > 1e-7 else -1 if value < -1e-7 else 0


def main():
    output = STAGE / "outputs/full_pipeline_v1"
    if read(output / "controller.json").get("status") != "statistical_complete":
        raise RuntimeError("evaluation remains sealed")
    thresholds = read(output / "thresholds.json")
    methods = analysis.METHODS
    rows, details = [], []
    for path in sorted((output / "evaluation").glob("*.json.gz")):
        record = read(path)
        if record["spec"]["phase"] != "evaluation":
            raise ValueError("expected evaluation raw")
        spec = record["spec"]
        detail = dict(spec=spec, rx={}, ranking=analysis.score_ranking(record),
            forecast=analysis.forecast_errors(record), solver={}, moves={})
        history = analysis.route_view(record, "P-SQ", "history")
        detail["true_name_in_history"] = history["true_name"]
        detail["true_source_forecast"] = detail["forecast"].get("source", {}).get(history["true_name"])
        for method in methods:
            detail["rx"][method] = {}
            for route in analysis.ROUTES:
                view = analysis.route_view(record, method, route)
                key = analysis.source_blind_key(method, spec["n"], route)
                decision = analysis.decide(view, thresholds["source_blind_applied"].get(key))
                rows.append(dict(spec=spec, cluster_index=spec["cluster_index"], n=spec["n"],
                    source_mode=spec["source_mode"], method=method, route=route, **decision))
                detail["rx"][method][route] = analysis.rx_error(record, view)
            detail["moves"][method] = record.get("planning", {}).get("plans", {}).get(method, {}).get("physicalcheck", {}).get("moves")
        for method in ("P-SQ", "G-SQ", "G-AQ"):
            family = record.get("planning", {}).get("families", {}).get(method, {})
            detail["solver"][method] = {domain: {k: value.get(k) for k in
                ("completed", "unfinished", "failures", "gap", "score", "objective_lower", "objective_upper")}
                for domain, value in family.items()}
        details.append(detail)
    tables = {method: {route: analysis.summarize_decisions([row for row in rows
        if row["method"] == method and row["route"] == route]) for route in analysis.ROUTES} for method in methods}
    rx = {method: {route: {key: distribution(d["rx"][method][route].get(key, {}).get("mean_absolute_relative")
        for d in details if d["rx"][method][route].get("available") and d["rx"][method][route].get("fit_success"))
        for key in ("r", "x")} for route in analysis.ROUTES} for method in methods}
    forecast = {}
    for label, n, source in [("all", None, None)] + [(f"n{n}_{s}", n, s) for n in (6, 8) for s in ("none", "DER")]:
        selected = [d for d in details if n is None or (d["spec"]["n"] == n and d["spec"]["source_mode"] == source)]
        forecast[label] = dict(n_conditions=len(selected), available=sum(d["forecast"].get("available", False) for d in selected),
            n_date_clusters=len({d["spec"]["cluster_index"] for d in selected}),
            load={k: distribution(d["forecast"].get("load", {}).get(k, {}).get("rmse_kw") for d in selected) for k in ("p", "q")},
            source={k: distribution((d["true_source_forecast"] or {}).get(k, {}).get("rmse_kw") for d in selected) for k in ("source_p", "source_q")},
            source_date_clusters=len({d["spec"]["cluster_index"] for d in selected if d["true_source_forecast"]}))
    ranking = {}
    for objective in ("G-SQ", "G-AQ"):
        selected = [d["ranking"][objective] for d in details if objective in d["ranking"]]
        delta = [d.get("own_minus_P_SQ", {}) for d in selected]
        actual_pairs = [d for d in delta if d.get("actual_true_margin_half_SSE") is not None]
        ranking[objective] = dict(conditions=len(selected),
            spearman_surrogate=distribution(d.get("spearman_surrogate_vs_actual") for d in selected),
            spearman_nominal=distribution(d.get("spearman_nominal_AC_vs_actual") for d in selected),
            delta={key: distribution(d.get(key) for d in delta) for key in
                ("surrogate", "nominal_AC", "actual_true_margin_half_SSE")},
            signs={key: dict(Counter(str(sign(d.get(key))) for d in delta)) for key in
                ("surrogate", "nominal_AC", "actual_true_margin_half_SSE")},
            actual_jointly_available_conditions=len(actual_pairs),
            nominal_vs_actual_signs=dict(Counter(
                "same" if sign(d.get("nominal_AC")) == sign(d["actual_true_margin_half_SSE"]) else
                "zero" if sign(d.get("nominal_AC")) == 0 or sign(d["actual_true_margin_half_SSE"]) == 0 else "opposite"
                for d in actual_pairs if d.get("nominal_AC") is not None)))
    same_domain = {right: analysis.paired_summary(rows, left, right, replicates=0)
        for left, right in (("P-SQ", "G-SQ"), ("P-SQ", "G-AQ"),
                            ("P-SQ/F±", "G-SQ/F±"), ("P-SQ/F±", "G-AQ/F±"))}
    spatial = {method: analysis.paired_summary(rows, method + "/F±", method, replicates=0)
               for method in ("P-SQ", "G-SQ", "G-AQ")}
    solver = {}
    for method in ("P-SQ", "G-SQ", "G-AQ"):
        selected = [d["solver"][method].get("mobile_bidir", {}) for d in details]
        solver[method] = dict(n=len(selected), completed=sum(d.get("completed") is True for d in selected),
            unfinished=sum(d.get("unfinished") is True for d in selected),
            raw_failure_conditions=sum(bool(d.get("failures")) for d in selected),
            moves=distribution(d["moves"].get(method) for d in details))
    result = dict(scope="frozen evaluation readback awaiting consistency with main summary; no new statistical tuning",
        n_conditions=len(details), n_date_clusters=len({d["spec"]["cluster_index"] for d in details}),
        tables=tables, rx=rx, forecast=forecast, ranking=ranking, paired_same_domain=same_domain,
        paired_spatial=spatial, solver=solver, details=details,
        fitting_calls=0, planning_calls=0, forward_AC_calls=0, bootstrap_calls=0)
    path = STAGE / "outputs/full_pipeline_tools/results_interpretation_fast.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")
    print(json.dumps(dict(n_conditions=len(details), n_dates=result["n_date_clusters"])))


if __name__ == "__main__":
    main()
