"""Independently validate restored statistics across Python float-sum versions.

This tools-only validator retains all exact differences. It never modifies the
archive or frozen source and makes no scientific fitting/planning/AC calls.
Integer, boolean, string and null values are compared exactly. Float tolerance
is absolute 1e-10 plus relative 1e-10 times the original value's magnitude.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import gzip
from hashlib import sha256
import importlib
import json
import math
from pathlib import Path
import sys
import time


ATOL = RTOL = 1e-10


def read(path):
    data = Path(path).read_bytes()
    return json.loads(gzip.decompress(data) if str(path).endswith('.gz') else data)


def sha(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def compare(original, actual, path, diffs, issues, counts):
    counts['compared_values'] += 1
    if isinstance(original, dict) and isinstance(actual, dict):
        if set(original) != set(actual):
            issues.append(dict(path=path, kind='keys', original=sorted(original), actual=sorted(actual)))
        for key in original.keys() & actual.keys():
            compare(original[key], actual[key], path + '.' + key, diffs, issues, counts)
    elif isinstance(original, list) and isinstance(actual, list):
        if len(original) != len(actual):
            issues.append(dict(path=path, kind='length', original=len(original), actual=len(actual)))
        for i, (a, b) in enumerate(zip(original, actual)):
            compare(a, b, path + f'[{i}]', diffs, issues, counts)
    elif isinstance(original, float) and isinstance(actual, float):
        counts['float_fields'] += 1
        if original == actual:
            return
        absolute = abs(actual - original)
        relative = absolute / abs(original) if original else None
        passed = math.isfinite(absolute) and absolute <= ATOL + RTOL * abs(original)
        row = dict(path=path, original=original, actual=actual,
            absolute_difference=absolute, relative_difference=relative, tolerance_passed=passed)
        diffs.append(row)
        if not passed:
            issues.append(row)
    else:
        counts['exact_nonfloat_fields'] += 1
        if type(original) is not type(actual) or original != actual:
            issues.append(dict(path=path, kind='exact_value_or_type', original=original, actual=actual))


def signature(supports):
    return tuple(sorted(tuple(sorted(map(int, x))) for x in supports))


def direct_record(record, method, route, thresholds):
    """Recount from saved losses/supports without any analysis decision helper."""
    actions = record.get('evaluation', {}).get('actions', {})
    matches = [a for a in actions.values() if method in a.get('methods', [])]
    action = matches[0] if len(matches) == 1 else actions.get(
        record.get('planning', {}).get('plans', {}).get(method, {}).get('action_key'))
    structures = (action or {}).get('candidate_union') if route == 'postJNT' else None
    if structures is None:
        structures = record.get('candidate_structures', record.get('passive_pre', {}).get('bank', []))
    if isinstance(structures, dict):
        structures = [dict(name=k, **v) for k, v in structures.items()]
    structures = {r['name']: r for r in structures}
    truth = signature(record['truth_evaluation_only']['supports'])
    true_names = [k for k, v in structures.items() if signature(v.get('full_supports', v['supports'])) == truth]
    assert len(true_names) <= 1
    true = true_names[0] if true_names else None
    failure = not structures
    physical = False
    if route == 'history':
        entries = record.get('planning', {}).get('history', {}).get('candidates', {})
    elif action is None:
        entries = {}; failure = True
    else:
        component = 'fixed' if route == 'preFIX' else 'joint'
        entries = {k: v.get(component, {}) for k, v in (action.get('pre_refit') or {}).get('comparisons', {}).items()}
        if route == 'postJNT':
            extra = {k: v.get('joint', {}) for k, v in (action.get('post_refit') or {}).get('comparisons', {}).items()}
            assert not (entries.keys() & extra.keys())
            entries.update(extra)
        physical = bool(action.get('physical_generation_failed') or
            action.get('physical', {}).get('voltage_domain_satisfied') is False or
            'actual_voltage_domain' in action.get('failures', {}))
        failure |= physical
    def good(entry):
        value = entry.get('loss')
        return bool(entry.get('success', False) and entry.get('usable', True) and
            isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value))
    failed = [k for k in structures if not good(entries.get(k, {}))]
    available = not failure and not failed
    predicted = None; ties = []; retained = sorted(structures)
    key = f'{method}|{record["spec"]["n"]}|{route}'
    threshold = thresholds['source_blind_applied'][key]
    value = threshold['value'] if threshold['finite'] else math.inf
    if available:
        losses = {k: float(entries[k]['loss']) for k in structures}
        best = min(losses.values()); eps = 1e-8 * (1 + abs(best))
        ties = sorted(k for k, v in losses.items() if v <= best + eps)
        predicted = ties[0] if len(ties) == 1 else None
        retained = sorted(k for k, v in losses.items() if (v - best) / 2 <= value + eps)
    unresolved = not available or len(retained) != 1
    return dict(candidate_missing=int(true is None), fit_failure=int(not available),
        available=int(available), conditional_available=int(available and true is not None),
        numerical_ties=int(available and len(ties) > 1),
        top1_wrong=int(predicted is not None and predicted != true),
        top1_evaluable=int(predicted is not None),
        conditional_top1_wrong=int(predicted is not None and true is not None and predicted != true),
        conditional_top1_evaluable=int(predicted is not None and true is not None),
        unique_correct=int(not unresolved and retained[0] == true),
        unique_wrong=int(not unresolved and retained[0] != true), unresolved=int(unresolved))


def independent_checks(records, summary, thresholds, frozen):
    issues = []; checks = 0; blind_checks = 0; identity_checks = 0
    count_fields = tuple(direct_record(records[0], summary['methods'][0], 'history', thresholds))
    tables = summary['phases']['evaluation']['tables']
    for method in summary['methods']:
        for route in ('history', 'preFIX', 'preJNT', 'postJNT'):
            rows = [direct_record(r, method, route, thresholds) for r in records]
            expected = tables[method][route]
            for field in count_fields:
                value = sum(row[field] for row in rows); checks += 1
                if value != expected[field]:
                    issues.append(dict(path=f'{method}.{route}.{field}', original=expected[field], actual=value))
    for key, cell in thresholds['source_blind_applied'].items():
        values = [r['value'] if r['finite'] else math.inf for r in cell['source_thresholds'].values()]
        maximum = max(values, default=math.inf); blind_checks += 1
        if cell['finite'] != math.isfinite(maximum) or (cell['finite'] and cell['value'] != maximum):
            issues.append(dict(path='source_blind_applied.' + key, kind='maximum_threshold'))
    for record in records:
        identity_checks += 1
        if record.get('freeze_identity') != frozen['identity'] or record.get('source_unchanged') is not True:
            issues.append(dict(path=str(record['spec']), kind='version_identity'))
    return dict(passed=not issues, independent_counter_checks=checks, independent_source_blind_checks=blind_checks,
        evaluation_version_identity_checks=identity_checks, issues=issues,
        scope='Independent support/loss recount, no analysis decision helper; no fitting or planning.')


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('bundle'); parser.add_argument('--output', required=True)
    args = parser.parse_args(); started = time.perf_counter(); bundle = Path(args.bundle).resolve(); source = bundle / 'source'
    sys.path[:0] = [str(source), str(source / 'rnj_wzzt_core')]
    analysis = importlib.import_module('research_experiments.mobile_ev_mle.full_pipeline.analysis')
    assert Path(analysis.__file__).resolve() == source / 'research_experiments/mobile_ev_mle/full_pipeline/analysis.py'
    thresholds = read(bundle / 'statistics/thresholds.json'); frozen = read(bundle / 'provenance/freeze.json')
    config = frozen['config']; methods = tuple(config['methods']); records = {}
    def load(phase):
        rows = [read(p) for p in sorted((bundle / 'compact' / phase).glob('*.json.gz'))]
        return sorted(rows, key=lambda r: (r['spec']['cluster_index'], r['spec']['n'], r['spec']['source_mode']))
    records['calibration'] = load('calibration')
    recal = analysis.calibration_thresholds(records['calibration'], methods=methods,
        alpha=config['alpha'], source_modes=config['source_modes'])
    diffs = []; issues = []; counts = defaultdict(int)
    for key, value in recal.items():
        compare(thresholds[key], value, 'calibration_rule.' + key, diffs, issues, counts)
    original = read(bundle / 'statistics/summary.json.gz')
    assert sha(analysis.__file__) == original['analysis_sha256']
    assert tuple(original['methods']) == methods
    assert type(original['statistical_bootstrap']) is int and type(original['statistical_seed']) is int
    B = original['statistical_bootstrap']; seed = original['statistical_seed']
    for phase in ('development', 'evaluation'):
        records[phase] = load(phase)
    for phase in ('development', 'calibration', 'evaluation'):
        actual = analysis.phase_summary(records[phase], thresholds, methods, bootstrap=B, seed=seed)
        compare(original['phases'][phase], actual, phase, diffs, issues, counts)
    spatial = analysis.small_spatial_ablation(records['evaluation'], thresholds, bootstrap=B, seed=seed)
    compare(original['spatial_ablation'], spatial, 'spatial_ablation', diffs, issues, counts)
    direct = independent_checks(records['evaluation'], original, thresholds, frozen)
    ci_diffs = [r for r in diffs if any(k in r['path'] for k in ('interval', '.ci', '.lower', '.upper', 'bootstrap'))]
    out = dict(schema='full_pipeline_restored_cross_python_validation_v1', passed=not issues and direct['passed'],
        executable=sys.executable, python=sys.version, source_root=str(source), analysis_sha256=sha(analysis.__file__),
        conditions={k: len(v) for k, v in records.items()}, independent_date_clusters={k: len({r['spec']['cluster_index'] for r in v}) for k, v in records.items()},
        tolerance=dict(absolute=ATOL, relative=RTOL, expression='abs(actual-original) <= 1e-10 + 1e-10*abs(original)',
            exact_types='integers, booleans, strings, null, lengths, keys, seeds, replicate count'),
        field_counts=dict(counts), exact_float_difference_count=len(diffs), exact_float_differences=diffs,
        max_absolute_difference=max((r['absolute_difference'] for r in diffs), default=0.),
        max_relative_difference=max((r['relative_difference'] or 0 for r in diffs), default=0.),
        outside_tolerance=issues, ci_exact_float_difference_count=len(ci_diffs), ci_exact_float_differences=ci_diffs,
        discrete_main_counter_changes=direct['issues'], independent_checks=direct,
        statistical_bootstrap=B, statistical_seed=seed, fitting_calls=0, planning_calls=0, forward_AC_calls=0,
        strict_313_failure_preserved='restore_replay.log',
        scope='Every regenerated calibration field, phase-summary field and spatial-ablation field compared. Floating differences are listed; this is tolerance replay, not exact replay.',
        seconds=time.perf_counter()-started)
    Path(args.output).write_text(json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in out.items() if k not in ('exact_float_differences', 'ci_exact_float_differences', 'field_counts')}, ensure_ascii=False, indent=2))
    return 0 if out['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
