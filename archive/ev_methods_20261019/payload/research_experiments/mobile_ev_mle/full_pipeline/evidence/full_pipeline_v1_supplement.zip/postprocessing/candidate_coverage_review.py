"""Read-only decomposition of saved whole-tree candidate coverage losses.

No AC, fit, planning, candidate addition or parameter update is performed.
Evaluation may be opened only after statistical_complete and frozen thresholds.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import gzip
import json
import math
from pathlib import Path
import sys

METHODS=('OBS','CC','HL','RAND','P-SQ','G-SQ','G-AQ','P-SQ/F±','G-SQ/F±','G-AQ/F±')


def read(path):
    path=Path(path);raw=path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def digest(path):return sha256(Path(path).read_bytes()).hexdigest()


def signature(supports,n):
    universe=set(range(n));result=set()
    for raw in supports:
        s=tuple(sorted(set(int(j) for j in raw)))
        if not s or not set(s)<=universe:raise ValueError('Invalid saved terminal clade')
        if 1<len(s)<n:result.add(s)
    sets=list(map(set,result))
    if any(a&b and not(a<=b or b<=a) for a in sets for b in sets):raise ValueError('Crossing saved clades')
    return tuple(sorted(result,key=lambda s:(-len(s),s)))


def metrics(candidate,truth,n):
    a,b=set(candidate),set(truth);hit=len(a&b)
    denominator=len(a)+len(b)
    # Structural F1 excludes leaf/root clades common to every candidate.
    implicit=n+1
    return dict(exact=a==b,nontrivial_clade_f1=2*hit/denominator if denominator else 1.,
        clade_symmetric_difference=len(a^b),predicted_clades=len(a),true_clades=len(b),matched_clades=hit,
        all_edge_clade_f1=2*(hit+implicit)/(denominator+2*implicit))


def structures(rows,n):
    if rows is None:return None
    out=[]
    for index,row in enumerate(rows):
        raw=row.get('full_supports',row.get('supports'))
        if raw is None:raise ValueError('Saved candidate is missing supports')
        out.append(dict(name=row.get('name','unnamed_%d'%index),key=signature(raw,n)))
    return out


def keys(rows):return None if rows is None else {r['key'] for r in rows}


def closest(rows,truth,n):
    if rows is None or truth is None:return None
    if not rows:return dict(candidate_count=0,available=False,best_f1=None,min_clade_difference=None)
    scored=[dict(name=r['name'],supports=[list(s) for s in r['key']],**metrics(r['key'],truth,n)) for r in rows]
    best=max(r['nontrivial_clade_f1'] for r in scored)
    return dict(candidate_count=len(rows),available=True,best_f1=best,
        min_clade_difference=min(r['clade_symmetric_difference'] for r in scored),
        best_candidates=[r for r in scored if abs(r['nontrivial_clade_f1']-best)<=1e-14])


def proposal(passive,n,truth,issues,label):
    if passive is None:return dict(available=False,retained=None,generated=None,retained_truth=None,
        generated_truth=None,closest_retained=None,closest_generated=None)
    bank=structures(passive.get('bank',[]),n);discarded=structures(passive.get('discarded',[]),n)
    generated=bank+discarded;distinct=keys(generated)
    expected=passive.get('generated_count')
    if expected is not None and expected!=len(distinct):
        issues.append(dict(label=label,issue='saved_generated_count_differs_from_bank_plus_discarded',
            expected=expected,reconstructed=len(distinct)))
    if len(keys(bank))!=len(bank):issues.append(dict(label=label,issue='duplicate_retained_structures'))
    return dict(available=True,retained=bank,generated=generated,
        retained_truth=None if truth is None else truth in keys(bank),
        generated_truth=None if truth is None else truth in distinct,
        generated_count=len(distinct),retained_count=len(bank),discarded_count=len(discarded),
        declared_max_candidates=passive.get('config',{}).get('max_candidates'),
        proposal_failures=passive.get('failures',[]),
        closest_retained=closest(bank,truth,n),closest_generated=closest(generated,truth,n))


def public_proposal(row):return {k:v for k,v in row.items() if k not in ('retained','generated')}


def entry_good(entry):
    return bool(entry and entry.get('success',False) and entry.get('usable',True)
        and isinstance(entry.get('loss'),(int,float)) and math.isfinite(entry['loss']))


def action_for(record,method):
    actions=record.get('evaluation',{}).get('actions',{})
    direct=record.get('planning',{}).get('plans',{}).get(method,{}).get('action_key')
    if direct in actions:return direct,actions[direct]
    found=[(k,a) for k,a in actions.items() if method in a.get('methods',[])]
    if len(found)>1:raise ValueError('Method belongs to multiple saved actions')
    return found[0] if found else (None,None)


def condition(record,path=None):
    spec=record['spec'];n=int(spec['n']);issues=[]
    truth_saved=record.get('truth_evaluation_only')
    truth=signature(truth_saved['supports'],n) if truth_saved and 'supports' in truth_saved else None
    raw=record.get('provenance',{}).get('raw',{})
    meta=dict(spec=spec,date_cluster=dict(phase=spec['phase'],cluster_index=spec['cluster_index'],
        start_utc=raw.get('start_utc'),history_end_utc=raw.get('history_end_utc'),end_utc=raw.get('end_utc')),
        n=n,source_mode=spec['source_mode'],record_status=record.get('status'),
        source_unchanged=record.get('source_unchanged'),truth_known=truth is not None,
        true_nontrivial_clades=None if truth is None else [list(s) for s in truth],
        path=str(path) if path else None,failures=record.get('failures',{}))
    pre=proposal(record.get('passive_pre',record.get('planning',{}).get('passive_pre')),n,truth,issues,'initial')
    initial=dict(**meta,proposal=public_proposal(pre),
        generator_not_proposed=pre['available'] and truth is not None and pre['generated_truth'] is False,
        generated_but_proposal_truncated=pre['generated_truth'] is True and pre['retained_truth'] is False,
        initial_retained_truth=pre['retained_truth'])
    posts=[]
    base_structures=structures(record.get('candidate_structures'),n)
    if base_structures is None:base_structures=pre['retained']
    for method in METHODS:
        key,action=action_for(record,method)
        post=proposal(action.get('post_passive') if action else None,n,truth,issues,'post:'+method)
        union_saved=action.get('candidate_union') if action else None
        union=structures(union_saved,n)
        union_source='saved_candidate_union'
        if action is not None and union is None:
            union=base_structures;union_source='initial_pool_fallback_after_missing_post_union'
        union_keys=keys(union)
        in_union=None if truth is None or union is None else truth in union_keys
        pre_keys=keys(pre['generated'])
        if truth is None:ever_generated=None
        elif (pre_keys is not None and truth in pre_keys) or post['generated_truth'] is True:ever_generated=True
        elif pre_keys is not None and post['available']:ever_generated=False
        else:ever_generated=None
        post_true_position=None
        if post['retained_truth']:
            post_true_position=next(i+1 for i,r in enumerate(post['retained']) if r['key']==truth)
        new=structures(action.get('new_candidates',[]) if action else [],n)
        cap=record.get('config',{}).get('post_max_new_candidates')
        union_dropped=bool(post['retained_truth'] is True and in_union is False)
        capped=bool(union_dropped and isinstance(cap,int) and len(new)>=cap)
        if union_dropped and not capped:issues.append(dict(label=method,issue='truth_in_post_bank_missing_from_union_before_declared_cap'))
        if pre['retained_truth'] is True and in_union is False:issues.append(dict(label=method,issue='initial_true_candidate_removed_from_union'))
        joint_entries={}
        if action:
            for section in ('pre_refit','post_refit'):
                for name,row in (action.get(section) or {}).get('comparisons',{}).items():
                    if name in joint_entries:issues.append(dict(label=method,issue='duplicate_joint_candidate_name',name=name))
                    joint_entries[name]=row.get('joint',{})
        failed_names=[] if union is None else [r['name'] for r in union if not entry_good(joint_entries.get(r['name']))]
        true_names=[] if union is None or truth is None else [r['name'] for r in union if r['key']==truth]
        true_failure=None if not true_names else any(not entry_good(joint_entries.get(name)) for name in true_names)
        physical=bool(action and (action.get('physical_generation_failed') or
            action.get('physical',{}).get('voltage_domain_satisfied') is False or
            'actual_voltage_domain' in action.get('failures',{})))
        evaluation_missing=action is None or 'pre_refit' not in action
        post_missing=action is not None and not post['available']
        flags=dict(generator_never_proposed_initial_or_post=ever_generated is False,
            ever_generated_but_not_retained_by_either_proposal=bool(ever_generated is True and
                pre['retained_truth'] is False and post['retained_truth'] is False),
            post_generated_but_proposal_truncated=bool(post['generated_truth'] is True and
                post['retained_truth'] is False and in_union is False),
            post_bank_true_but_union_cap_truncated=capped,
            truth_missing_from_final_union=in_union is False,
            truth_in_final_union=in_union is True,
            joint_candidate_failure=bool(failed_names),true_candidate_joint_failure=true_failure is True,
            covered_truth_but_any_joint_failure=in_union is True and bool(failed_names),
            physical_execution_failure=physical,action_or_refit_unavailable=evaluation_missing,
            post_proposal_unavailable=post_missing,
            covered_and_all_joint_fits_good=in_union is True and not failed_names and not physical and not evaluation_missing)
        posts.append(dict(**meta,method=method,action_key=key,initial_retained_truth=pre['retained_truth'],
            initial_generated_truth=pre['generated_truth'],post_proposal=public_proposal(post),
            truth_ever_generated=ever_generated,truth_in_final_union=in_union,
            union_source=union_source,union_count=None if union is None else len(union),
            new_candidate_count=len(new),declared_post_max_new_candidates=cap,
            true_post_bank_position_1_based=post_true_position,
            closest_final_union=closest(union,truth,n),true_union_names=true_names,
            joint_failed_candidate_names=failed_names,
            true_joint_fit_failed=true_failure,flags=flags,
            action_failures={} if action is None else action.get('failures',{})))
    return initial,posts,issues


def summarize(rows,*,initial=False):
    count=len(rows);statuses=Counter(r.get('record_status','unknown') for r in rows)
    flags=Counter()
    closest_values=[]
    for r in rows:
        if initial:
            f={k:r[k] for k in ('generator_not_proposed','generated_but_proposal_truncated')}
            f['initial_retained_truth']=r['initial_retained_truth'] is True
            f['proposal_unavailable']=not r['proposal']['available']
            c=r['proposal']['closest_retained']
        else:f=r['flags'];c=r['closest_final_union']
        flags.update(k for k,v in f.items() if v is True)
        if c and c['available']:closest_values.append(c['best_f1'])
    known=sum(r['truth_known'] for r in rows)
    coverage=flags['initial_retained_truth' if initial else 'truth_in_final_union']
    return dict(conditions=count,truth_known=known,truth_unknown=count-known,
        date_clusters=len({(r['date_cluster']['phase'],r['date_cluster']['cluster_index']) for r in rows}),
        record_status_counts=dict(statuses),nonexclusive_reason_counts=dict(flags),
        retained_truth_count=coverage,retained_truth_rate_over_known=coverage/known if known else None,
        closest_F1=dict(n_available=len(closest_values),n_unavailable=count-len(closest_values),
            mean=sum(closest_values)/len(closest_values) if closest_values else None),
        denominator_note='All saved conditions retained; reason counts overlap; network/source cases share date clusters')


def aggregate(initial,posts):
    pre_groups=defaultdict(list);post_groups=defaultdict(list)
    for r in initial:pre_groups['n%d/%s'%(r['n'],r['source_mode'])].append(r)
    for r in posts:post_groups[(r['method'],'n%d/%s'%(r['n'],r['source_mode']))].append(r)
    return dict(initial=dict(all=summarize(initial,initial=True),
        by_n_source={k:summarize(v,initial=True) for k,v in sorted(pre_groups.items())}),
        post={method:dict(all=summarize([r for r in posts if r['method']==method]),
            by_n_source={cell:summarize(rows) for (m,cell),rows in sorted(post_groups.items()) if m==method}) for method in METHODS})


def review(output,phase,receipt):
    output=Path(output);policy=read(output/'freeze.json')
    gates={}
    if phase=='evaluation':
        controller=read(output/'controller.json')
        if controller.get('status')!='statistical_complete':raise RuntimeError('Evaluation blocked until controller statistical_complete')
        if not (output/'thresholds.json').exists():raise RuntimeError('Evaluation blocked until frozen thresholds exist')
        thresholds=read(output/'thresholds.json')
        if thresholds.get('policy_identity')!=policy['identity']:raise RuntimeError('Threshold policy differs from scientific freeze')
        gates=dict(controller_status=controller['status'],threshold_identity=thresholds.get('identity'),
            thresholds_sha256=digest(output/'thresholds.json'))
    elif phase!='development':raise ValueError('Only development or gated evaluation is supported')
    # Evaluation glob/read occurs strictly after both gates above.
    paths=sorted((output/phase).glob('*.json.gz'));initial=[];posts=[];issues=[];files={}
    for path in paths:
        record=read(path)
        if record['spec']['phase']!=phase:raise RuntimeError('Phase directory contains a different phase')
        if record.get('freeze_identity')!=policy['identity'] or record.get('source_unchanged') is not True:
            issues.append(dict(path=str(path),issue='raw_freeze_or_source_integrity_failed'))
        pre,after,local=condition(record,path);initial.append(pre);posts.extend(after)
        issues.extend(dict(path=str(path),**x) for x in local);files[path.name]=digest(path)
    expected=policy['config'][phase+'_clusters']*len(policy['config']['terminal_counts'])*len(policy['config']['source_modes'])
    if phase=='evaluation' and len(paths)!=expected:issues.append(dict(issue='evaluation_condition_count_differs',expected=expected,actual=len(paths)))
    result=dict(schema='full_pipeline_candidate_coverage_review_v1',phase=phase,
        review_utc=datetime.now(timezone.utc).isoformat(),tool_sha256=digest(__file__),
        source_freeze_identity=policy['identity'],gates=gates,raw_file_sha256=files,
        expected_conditions=expected,computed_conditions=len(paths),methods=list(METHODS),
        passed_schema_checks=not issues,issues=issues,summary=aggregate(initial,posts),
        initial_conditions=initial,post_conditions=posts,
        information_boundary='Truth signatures used only after sealing, for saved-candidate comparison; no candidate or fit added',
        interpretation='Not proposed means absent from this finite proposal generator; it does not establish physical nonidentifiability',
        F1_definition='2 times matching nontrivial terminal clades divided by predicted+true clade counts; empty/empty=1',
        secondary_edge_F1='Adds the n leaf edges and common full/root edge; reported separately to avoid inflating structural F1',
        operations_executed=dict(AC=0,fit=0,planning=0,candidate_generation=0))
    receipt=Path(receipt);receipt.parent.mkdir(parents=True,exist_ok=True)
    receipt.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False),encoding='utf8')
    return result


def self_test():
    spec=dict(phase='development',cluster_index=0,n=4,source_mode='none')
    true=[[0,1],[2,3]];wrong=[[0,2],[1,3]]
    def p(bank,discarded):return dict(bank=bank,discarded=discarded,generated_count=len(bank)+len(discarded),config={'max_candidates':1})
    bank=[dict(name='wrong',supports=wrong)]
    truthrow=dict(name='true',supports=true)
    base=dict(spec=spec,config={'post_max_new_candidates':1},status='complete',source_unchanged=True,
        truth_evaluation_only={'supports':true},candidate_structures=bank,
        passive_pre=p(bank,[truthrow]),planning={'plans':{'OBS':{'action_key':'a'}}},
        evaluation={'actions':{'a':dict(methods=['OBS'],candidate_union=bank,new_candidates=bank,
            post_passive=p([truthrow],[]),pre_refit={'comparisons':{'wrong':{'joint':dict(success=True,usable=True,loss=1.)}}})}})
    initial,posts,issues=condition(base)
    obs=posts[0]
    assert initial['generated_but_proposal_truncated'] and not initial['generator_not_proposed']
    assert obs['flags']['post_bank_true_but_union_cap_truncated']
    assert not obs['flags']['generator_never_proposed_initial_or_post']
    assert obs['closest_final_union']['best_f1']==0.
    assert obs['post_proposal']['closest_retained']['best_f1']==1.
    assert not issues
    never=deepcopy(base);never['passive_pre']=p(bank,[])
    never['evaluation']['actions']['a']['post_passive']=p(bank,[])
    _,rows,_=condition(never)
    assert rows[0]['flags']['generator_never_proposed_initial_or_post']
    failed=deepcopy(base);action=failed['evaluation']['actions']['a']
    action['candidate_union']=[*bank,truthrow];action['new_candidates']=[truthrow]
    action['post_refit']={'comparisons':{'true':{'joint':dict(success=False,usable=True,loss=.2)}}}
    _,rows,_=condition(failed)
    assert rows[0]['flags']['true_candidate_joint_failure']
    assert rows[0]['flags']['covered_truth_but_any_joint_failure']
    assert not rows[0]['flags']['truth_missing_from_final_union']
    unknown=deepcopy(base);unknown.pop('truth_evaluation_only')
    i,rows,_=condition(unknown)
    assert not i['truth_known'] and rows[0]['truth_in_final_union'] is None
    assert summarize([i],initial=True)['truth_unknown']==1
    missing_post=deepcopy(never);missing_post['evaluation']['actions']['a'].pop('post_passive')
    _,rows,_=condition(missing_post)
    assert rows[0]['truth_ever_generated'] is None
    assert not rows[0]['flags']['generator_never_proposed_initial_or_post']
    assert metrics((),(),4)['nontrivial_clade_f1']==1.
    # Prove an unfinished controller stops before an evaluation glob/read.
    original=globals()['read'];opened=[]
    def guarded(path):
        opened.append(Path(path).name)
        if Path(path).name=='freeze.json':return {'identity':'fixture'}
        if Path(path).name=='controller.json':return {'status':'running'}
        raise AssertionError('Gate attempted to open an unexpected file')
    globals()['read']=guarded
    try:
        try:review(Path('fixture-output'),'evaluation',Path('fixture-receipt'))
        except RuntimeError as exc:assert 'statistical_complete' in str(exc)
        else:raise AssertionError('Unfinished controller did not block evaluation')
    finally:globals()['read']=original
    assert opened==['freeze.json','controller.json']
    print(json.dumps(dict(self_test='passed',fixtures=6,AC=0,fit=0,planning=0),sort_keys=True))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--phase',choices=['development','evaluation'],default='evaluation')
    parser.add_argument('--receipt',type=Path,default=Path(__file__).with_name('candidate_coverage_review.json'))
    parser.add_argument('--self-test',action='store_true')
    args=parser.parse_args()
    if args.self_test:self_test();return
    if args.output is None:parser.error('--output is required except with --self-test')
    result=review(args.output,args.phase,args.receipt)
    print(json.dumps(dict(phase=args.phase,conditions=result['computed_conditions'],
        schema_passed=result['passed_schema_checks'],receipt=str(args.receipt)),sort_keys=True))


if __name__=='__main__':main()
