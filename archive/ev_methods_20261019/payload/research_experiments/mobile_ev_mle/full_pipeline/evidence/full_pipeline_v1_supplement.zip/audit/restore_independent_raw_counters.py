"""Recount frozen full raw evaluation records against restored summary.

No statistical analysis decision helper, fitting, planning, or AC simulation is
called. The direct support/loss formulas are defined in restore_replay_compat.py.
The original receipt was produced by the equivalent in-session command; this
file preserves that command as a rerunnable CLI without changing its formulas.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', default=str(Path(__file__).resolve().parents[2]))
    parser.add_argument('--output')
    args = parser.parse_args(); stage = Path(args.stage).resolve(); started = time.perf_counter()
    module_path = stage / 'outputs/full_pipeline_tools/restore_replay_compat.py'
    spec = importlib.util.spec_from_file_location('restore_validator', module_path)
    validator = importlib.util.module_from_spec(spec); spec.loader.exec_module(validator)
    bundle = stage / 'outputs/full_pipeline_restore_v1'
    summary = validator.read(bundle / 'statistics/summary.json.gz')
    thresholds = validator.read(bundle / 'statistics/thresholds.json')
    frozen = validator.read(bundle / 'provenance/freeze.json')
    paths = sorted((stage / 'outputs/full_pipeline_v1/evaluation').glob('*.json.gz'))
    records = [validator.read(p) for p in paths]
    assert len(records) == 64
    out = validator.independent_checks(records, summary, thresholds, frozen)
    out.update(input='original full evaluation raw; compared to restored frozen summary/thresholds',
        n_conditions=len(records),
        n_independent_date_clusters=len({r['spec']['cluster_index'] for r in records}),
        fitting_calls=0, planning_calls=0, forward_AC_calls=0,
        seconds=time.perf_counter()-started)
    target = Path(args.output) if args.output else stage / 'outputs/full_pipeline_tools/restore_independent_raw_counters.json'
    target.write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(out, indent=2))
    return 0 if out['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
