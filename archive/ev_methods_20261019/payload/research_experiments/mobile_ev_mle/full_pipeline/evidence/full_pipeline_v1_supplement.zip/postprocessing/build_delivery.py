"""Assemble final delivery from frozen outputs; no science fit or planning."""
from __future__ import annotations
import argparse
import gzip
import hashlib
import json
import shutil
import zipfile
from pathlib import Path


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def table(header, rows):
    return '\n'.join(['|'+'|'.join(header)+'|', '|'+'|'.join(['---']*len(header))+'|'] +
                     ['|'+'|'.join(map(str, row))+'|' for row in rows])


def build(stage: Path):
    out=stage/'outputs/full_pipeline_v1'
    tools=stage/'outputs/full_pipeline_tools'
    dest=stage/'outputs/full_pipeline_delivery_ready'
    dest.mkdir(exist_ok=True)
    summary=read(out/'summary.json'); e=summary['phases']['evaluation']
    audit=read(out/'audit.json'); assert audit['passed']
    ctrl=read(out/'controller.json'); assert ctrl['status']=='statistical_complete'
    post=read(out/'postprocess_controller.json'); assert post['status']=='complete'
    assert read(tools/'restore_validation.json')['passed']
    clade=read(out/'clade_metrics.json'); assert not clade['consistency_issues']
    assert (e['n_condition_records'],e['n_independent_date_clusters'])==(64,16)
    cells=clade['phases']['evaluation']['all']['cells']
    methods=summary['methods']
    point=[]; sets=[]
    for m in methods:
        d=e['tables'][m]['postJNT']; c=cells[m]['postJNT']
        wrong=d['top1_wrong']; unavailable=64-d['available']; correct=64-wrong-unavailable
        assert (correct, wrong)==(c['point_correct'],c['point_wrong'])
        assert d['unique_correct']+d['unique_wrong']+d['unresolved']==64
        ci=c['f1_interval']
        point.append([m,correct,wrong,unavailable,d['candidate_missing'],
                      f"{c['mean_f1']:.4f} ({c['scored_f1_conditions']}/64)",
                      f"[{ci['lower']:.4f}, {ci['upper']:.4f}]"])
        sets.append([m,d['unique_correct'],d['unique_wrong'],d['unresolved'],
                     f"{d['false_reject']}/{d['truth_present']}"])
    solver=[]
    for m in ['P-SQ','G-SQ','G-AQ']:
        solver.append([m]+[f"{e['solver'][m+'|'+domain]['completed']}/64"
                      for domain in ['fixed_charge','fixed_bidir','mobile_charge','mobile_bidir']])
    report=(tools/'report.md').read_text(encoding='utf-8')
    report=report.replace('<!-- POINT_TABLE -->', table(
        ['方法','点正确 /64','点错误 /64','不可用 /64','池中漏真 /64','平均F1 (可评分分母)','F1日期簇95%区间'],point))
    report=report.replace('<!-- SET_TABLE -->', table(
        ['方法','唯一正确 /64','唯一错误 /64','未决 /64','真候选被排除 /在池'],sets))
    report=report.replace('<!-- SOLVER_TABLE -->',table(
        ['目标','F+固定纯充','F±固定双向','M+移动纯充','M±移动双向'],solver))
    assert '<!--' not in report
    (dest/'report.md').write_text(report,encoding='utf-8',newline='\n')
    evidence=dest/'evidence'; evidence.mkdir(exist_ok=True)
    primary=stage/'outputs/full_pipeline_delivery_v1/full_pipeline_v1_evidence.zip'
    receipt=read(primary.parent/'package_receipt.json')
    assert sha(primary.read_bytes())==receipt['archive_sha256']
    shutil.copyfile(primary,evidence/primary.name)
    shutil.copyfile(primary.parent/'package_receipt.json',evidence/'package_receipt.json')
    required={
        'statistics/clade_metrics.json.gz':out/'clade_metrics.json',
        'statistics/clade_results.md':out/'clade_results.md',
        'statistics/candidate_coverage_review.json.gz':tools/'candidate_coverage_review.json',
        'statistics/candidate_coverage_review_development.json.gz':tools/'candidate_coverage_review_development.json',
        'statistics/development_review.json.gz':tools/'development_review.json',
        'statistics/solver_review.json.gz':tools/'solver_review.json',
        'statistics/results_interpretation.md':tools/'results_interpretation.md',
        'statistics/solver_final_review.md':tools/'solver_final_review.md',
        'statistics/solver_final_review.json':tools/'solver_final_review.json',
        'audit/physical_parameter_review.md':tools/'physical_parameter_review.md',
        'audit/calibration_freeze_receipt.json':out/'calibration_freeze_receipt.json',
        'audit/restore_validation.json':tools/'restore_validation.json',
        'audit/delivery_tests.log':tools/'delivery_tests.log',
        'audit/postprocess_controller.json':out/'postprocess_controller.json',
        'audit/clade_postprocess_controller.json':out/'clade_postprocess_controller.json',
    }
    for name in ['package_evidence.py','final_clade_metrics.py','candidate_coverage_review.py',
                 'development_review.py','results_interpretation.py','build_delivery.py',
                 'finish_when_ready.py','clade_when_ready.py']:
        required['postprocessing/'+name]=tools/name
    for name in ['restore_replay_compat.py','restore_replay_compat.json','restore_replay_compat.log',
                 'restore_replay_311.log','restore_replay.log','restore_validation.md',
                 'restore_independent_raw_counters.json','restore_independent_raw_counters.py',
                 'restore_physical_audit.json','restore_archive_verification.log']:
        if (tools/name).is_file(): required['audit/'+name]=tools/name
    payload={}
    for name,path in required.items():
        data=path.read_bytes()
        if name.endswith('.json.gz') and path.suffix=='.json':data=gzip.compress(data,mtime=0)
        payload[name]=data
    manifest={'schema':'full_pipeline_supplement_v1','primary_archive_sha256':receipt['archive_sha256'],
              'scope':'postprocessing only; no fit, planning, policy or calibration modification',
              'files':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(payload.items())}}
    manifest_bytes=json.dumps(manifest,sort_keys=True,ensure_ascii=False,indent=2).encode('utf-8')
    archive=evidence/'full_pipeline_v1_supplement.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in sorted(payload.items()):z.writestr(name,data)
        z.writestr('manifest.json',manifest_bytes)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        check=read_zip_json(z,'manifest.json')
        assert len(check['files'])==len(required)
        for name,row in check['files'].items():
            data=z.read(name);assert sha(data)==row['sha256'] and len(data)==row['bytes']
            assert '..' not in Path(name).parts and not Path(name).is_absolute()
            if name.endswith('.json.gz'):json.loads(gzip.decompress(data))
    supplement={'passed':True,'files':len(payload),'archive_bytes':archive.stat().st_size,
                'archive_sha256':sha(archive.read_bytes()),'manifest_sha256':sha(manifest_bytes)}
    (evidence/'supplement_receipt.json').write_text(json.dumps(supplement,indent=2),encoding='utf-8')
    shutil.copyfile(tools/'restore_validation.json',evidence/'restore_validation.json')
    shutil.copyfile(out/'audit.json',evidence/'audit.json')
    shutil.copyfile(out/'calibration_freeze_receipt.json',evidence/'calibration_freeze_receipt.json')
    validation={'passed':True,'evaluation_conditions':64,'evaluation_date_clusters':16,
                'table_consistency_checks':len(methods),'primary_package':receipt,'supplement':supplement,
                'science_fit_calls':0,'science_planning_calls':0,
                'report_sha256':sha((dest/'report.md').read_bytes())}
    (evidence/'delivery_validation.json').write_text(json.dumps(validation,indent=2),encoding='utf-8')
    print(json.dumps(validation,ensure_ascii=False))


def read_zip_json(z,name):return json.loads(z.read(name))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',type=Path);a=p.parse_args();build(a.stage)
